import { press } from '../data/content.js'
import Reveal from '../components/Reveal.jsx'

export default function TrustedBy() {
  const loop = [...press, ...press]

  return (
    <section className="trusted">
      <Reveal className="wrap" duration={0.6}>
        <p className="trusted__label">As featured in</p>
      </Reveal>

      <div className="trusted__track">
        <div className="trusted__row">
          {loop.map((name, i) => (
            <span key={i} className="trusted__item">{name}</span>
          ))}
        </div>
      </div>

      <style>{`
        .trusted { padding: 56px 0 72px; }
        .trusted__label {
          text-align: center;
          font-size: 0.85rem;
          color: var(--ink-mute);
          margin-bottom: 32px;
        }
        .trusted__track {
          overflow: hidden;
          mask-image: linear-gradient(90deg, transparent, black 12%, black 88%, transparent);
          -webkit-mask-image: linear-gradient(90deg, transparent, black 12%, black 88%, transparent);
        }
        .trusted__row {
          display: flex;
          gap: 72px;
          width: max-content;
          animation: marquee 28s linear infinite;
        }
        .trusted__item {
          font-family: var(--serif);
          font-style: italic;
          font-size: 1.4rem;
          color: var(--ink-mute);
          white-space: nowrap;
        }
        @keyframes marquee {
          from { transform: translateX(0); }
          to { transform: translateX(-50%); }
        }
      `}</style>
    </section>
  )
}
