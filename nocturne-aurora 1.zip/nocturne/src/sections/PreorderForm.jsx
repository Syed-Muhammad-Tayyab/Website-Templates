import { useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import Reveal from '../components/Reveal.jsx'

const FINISHES = ['Graphite', 'Bone']

export default function PreorderForm() {
  const [form, setForm] = useState({ name: '', email: '', finish: 'Graphite' })
  const [errors, setErrors] = useState({})
  const [submitted, setSubmitted] = useState(false)

  const update = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }))

  const validate = () => {
    const next = {}
    if (!form.name.trim()) next.name = 'Tell us your name.'
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) next.email = 'Enter a valid email.'
    setErrors(next)
    return Object.keys(next).length === 0
  }

  const onSubmit = (e) => {
    e.preventDefault()
    if (!validate()) return
    setSubmitted(true)
  }

  return (
    <section className="preorder section">
      <div className="wrap preorder__grid">
        <Reveal className="preorder__intro">
          <p className="eyebrow">Reserve</p>
          <h2>Hold your place in the next production run.</h2>
          <p>
            A refundable $25 deposit reserves your unit and locks today's
            price. We'll email you before your unit ships.
          </p>

          <div className="preorder__contact">
            <div>
              <span className="preorder__label">Email</span>
              <a href="mailto:hello@nocturne.sleep">hello@nocturne.sleep</a>
            </div>
            <div>
              <span className="preorder__label">Showroom</span>
              <span>Rua das Flores 214, Porto Novo</span>
            </div>
          </div>
        </Reveal>

        <Reveal direction="left" delay={0.1} className="preorder__form-wrap glass">
          <AnimatePresence mode="wait">
            {submitted ? (
              <motion.div
                key="success"
                className="preorder__success"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.5 }}
              >
                <span className="preorder__success-dot" />
                <h3>You're on the list, {form.name.split(' ')[0]}.</h3>
                <p>We've reserved a {form.finish} Aurora for you and will email {form.email} with shipping updates.</p>
              </motion.div>
            ) : (
              <motion.form
                key="form"
                onSubmit={onSubmit}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.4 }}
                noValidate
              >
                <label className="field">
                  <span>Name</span>
                  <input type="text" value={form.name} onChange={update('name')} placeholder="Your full name" />
                  {errors.name && <em>{errors.name}</em>}
                </label>

                <label className="field">
                  <span>Email</span>
                  <input type="email" value={form.email} onChange={update('email')} placeholder="you@email.com" />
                  {errors.email && <em>{errors.email}</em>}
                </label>

                <div className="field">
                  <span>Finish</span>
                  <div className="preorder__swatches">
                    {FINISHES.map((f) => (
                      <button
                        type="button"
                        key={f}
                        className={`preorder__swatch ${form.finish === f ? 'is-selected' : ''}`}
                        onClick={() => setForm((s) => ({ ...s, finish: f }))}
                      >
                        <span className={`preorder__swatch-dot swatch-${f.toLowerCase()}`} />
                        {f}
                      </button>
                    ))}
                  </div>
                </div>

                <button type="submit" className="btn btn-primary btn-block">
                  Reserve with $25 deposit
                </button>
              </motion.form>
            )}
          </AnimatePresence>
        </Reveal>
      </div>

      <style>{`
        .preorder__grid {
          display: grid;
          grid-template-columns: 0.9fr 1.1fr;
          gap: 56px;
        }
        .preorder__intro h2 {
          font-size: clamp(1.8rem, 3.2vw, 2.5rem);
          margin: 14px 0 20px;
          max-width: 420px;
        }
        .preorder__intro p { max-width: 420px; line-height: 1.6; margin-bottom: 40px; }
        .preorder__contact { display: flex; flex-direction: column; gap: 18px; }
        .preorder__contact div { display: flex; flex-direction: column; gap: 4px; }
        .preorder__label { font-size: 0.8rem; color: var(--ink-mute); }
        .preorder__contact a { font-family: var(--serif); font-size: 1.1rem; }
        .preorder__form-wrap { padding: 40px; }
        .field {
          display: flex;
          flex-direction: column;
          gap: 8px;
          margin-bottom: 22px;
          font-size: 0.875rem;
          color: var(--ink-mute);
        }
        .field input {
          font-family: var(--sans);
          background: rgba(237,235,245,0.04);
          border: 1px solid var(--line-strong);
          border-radius: 10px;
          padding: 13px 16px;
          color: var(--ink);
          font-size: 0.95rem;
          transition: border-color 0.3s ease;
        }
        .field input:focus { border-color: var(--ember-dim); outline: none; }
        .field em { color: #e88a6d; font-style: normal; font-size: 0.8rem; }
        .preorder__swatches { display: flex; gap: 12px; }
        .preorder__swatch {
          display: flex; align-items: center; gap: 8px;
          padding: 10px 16px;
          border: 1px solid var(--line-strong);
          border-radius: 100px;
          color: var(--ink-dim);
          font-size: 0.875rem;
          transition: border-color 0.3s ease, color 0.3s ease;
        }
        .preorder__swatch.is-selected { border-color: var(--ember); color: var(--ink); }
        .preorder__swatch-dot { width: 12px; height: 12px; border-radius: 50%; }
        .swatch-graphite { background: #3a3d4a; }
        .swatch-bone { background: #d8d3c4; }
        .preorder__success { text-align: center; padding: 24px 0; }
        .preorder__success-dot {
          display: inline-block;
          width: 10px; height: 10px;
          border-radius: 50%;
          background: var(--ember);
          box-shadow: 0 0 20px 4px var(--ember-glow);
          margin-bottom: 20px;
        }
        .preorder__success h3 { font-size: 1.4rem; margin-bottom: 12px; }
        .preorder__success p { max-width: 340px; margin: 0 auto; line-height: 1.6; }
        @media (max-width: 860px) {
          .preorder__grid { grid-template-columns: 1fr; }
        }
      `}</style>
    </section>
  )
}
