import { timeline } from '../data/content.js'
import Reveal from '../components/Reveal.jsx'

export default function Timeline() {
  return (
    <section className="timeline section">
      <div className="wrap timeline__grid">
        <div className="timeline__sticky">
          <Reveal>
            <p className="eyebrow">Since 2019</p>
            <h2>A sleep lab that became a workshop.</h2>
          </Reveal>
        </div>

        <div className="timeline__list">
          {timeline.map((t, i) => (
            <Reveal key={t.year} delay={i * 0.05} className="timeline__item">
              <span className="timeline__year">{t.year}</span>
              <div>
                <h3>{t.title}</h3>
                <p>{t.body}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>

      <style>{`
        .timeline__grid {
          display: grid;
          grid-template-columns: 0.8fr 1.2fr;
          gap: 64px;
        }
        .timeline__sticky {
          position: sticky;
          top: 140px;
          align-self: start;
        }
        .timeline__sticky h2 {
          font-size: clamp(1.8rem, 3vw, 2.4rem);
          margin-top: 14px;
          max-width: 340px;
        }
        .timeline__item {
          display: grid;
          grid-template-columns: 90px 1fr;
          gap: 20px;
          padding: 32px 0;
          border-bottom: 1px solid var(--line);
        }
        .timeline__item:last-child { border-bottom: none; }
        .timeline__year {
          font-family: var(--serif);
          color: var(--ember);
          font-size: 1.1rem;
        }
        .timeline__item h3 { font-size: 1.4rem; margin-bottom: 10px; }
        .timeline__item p { line-height: 1.6; max-width: 460px; }
        @media (max-width: 860px) {
          .timeline__grid { grid-template-columns: 1fr; }
          .timeline__sticky { position: static; margin-bottom: 8px; }
        }
      `}</style>
    </section>
  )
}
