import { motion } from 'framer-motion'
import Reveal from '../components/Reveal.jsx'

export default function ScienceCurve() {
  return (
    <section className="science section">
      <div className="wrap science__grid">
        <Reveal className="science__text">
          <p className="eyebrow">The science</p>
          <h2>Your body runs on a curve. Most bedrooms fight it.</h2>
          <p>
            Core temperature, melatonin, and cortisol each follow a
            predictable rhythm across 24 hours. Overhead lighting, phone
            screens, and fixed-temperature rooms flatten that curve. Aurora
            reads it and shapes the room to match it instead.
          </p>
        </Reveal>

        <Reveal direction="right" className="science__chart-wrap">
          <svg viewBox="0 0 480 220" className="science__chart">
            <line x1="0" y1="180" x2="480" y2="180" stroke="var(--line)" strokeWidth="1" />
            <motion.path
              d="M0,120 C60,60 100,40 150,55 C210,72 230,150 290,165 C340,176 380,150 420,110 C450,80 470,60 480,50"
              fill="none"
              stroke="var(--ember)"
              strokeWidth="2.5"
              strokeLinecap="round"
              initial={{ pathLength: 0 }}
              whileInView={{ pathLength: 1 }}
              viewport={{ once: true, amount: 0.6 }}
              transition={{ duration: 2, ease: [0.16, 1, 0.3, 1] }}
            />
            <motion.path
              d="M0,150 C80,150 120,90 170,95 C230,101 260,60 310,60 C360,60 400,110 480,140"
              fill="none"
              stroke="var(--lavender)"
              strokeWidth="1.5"
              strokeDasharray="4 5"
              strokeLinecap="round"
              initial={{ pathLength: 0, opacity: 0 }}
              whileInView={{ pathLength: 1, opacity: 0.7 }}
              viewport={{ once: true, amount: 0.6 }}
              transition={{ duration: 2.2, delay: 0.3, ease: [0.16, 1, 0.3, 1] }}
            />
          </svg>
          <div className="science__legend">
            <span><i style={{ background: 'var(--ember)' }} /> Melatonin, with Aurora</span>
            <span><i style={{ background: 'var(--lavender)' }} /> Melatonin, typical bedroom</span>
          </div>
        </Reveal>
      </div>

      <style>{`
        .science__grid {
          display: grid;
          grid-template-columns: 1fr 1.1fr;
          gap: 56px;
          align-items: center;
        }
        .science__text h2 {
          font-size: clamp(1.8rem, 3.4vw, 2.6rem);
          margin: 16px 0 20px;
          max-width: 440px;
        }
        .science__text p { font-size: 1.05rem; line-height: 1.65; max-width: 440px; }
        .science__chart-wrap { padding: 28px; }
        .science__chart { width: 100%; height: auto; }
        .science__legend {
          display: flex;
          flex-direction: column;
          gap: 8px;
          margin-top: 18px;
          font-size: 0.85rem;
          color: var(--ink-mute);
        }
        .science__legend span { display: flex; align-items: center; gap: 8px; }
        .science__legend i { width: 14px; height: 2px; display: inline-block; }
        @media (max-width: 860px) {
          .science__grid { grid-template-columns: 1fr; }
        }
      `}</style>
    </section>
  )
}
