import Reveal from '../components/Reveal.jsx'

const SPECS = [
  ['Dimensions', '148 x 148 x 210 mm'],
  ['Weight', '1.4 kg'],
  ['Light output', '256 LEDs, 1800K–6500K, 0–1200 lumens'],
  ['Audio', '5-driver array, 20Hz–20kHz'],
  ['Sensing', '60GHz mmWave radar, 2m range'],
  ['Connectivity', 'Wi-Fi 6, Bluetooth 5.3, Thread'],
  ['Battery', '40 hours, USB-C, 90 min full charge'],
  ['Finish', 'Cast aluminium, blown glass, silicone base'],
]

export default function SpecSheet() {
  return (
    <section className="specs section">
      <div className="wrap">
        <Reveal className="section-head">
          <p className="eyebrow">Specification</p>
          <h2>Every measurement, considered.</h2>
        </Reveal>

        <div className="specs__table">
          {SPECS.map(([label, value], i) => (
            <Reveal key={label} delay={i * 0.03} duration={0.5} className="specs__row">
              <span className="specs__label">{label}</span>
              <span className="specs__value">{value}</span>
            </Reveal>
          ))}
        </div>
      </div>

      <style>{`
        .specs__table { border-top: 1px solid var(--line); }
        .specs__row {
          display: grid;
          grid-template-columns: 200px 1fr;
          gap: 24px;
          padding: 22px 4px;
          border-bottom: 1px solid var(--line);
        }
        .specs__label { color: var(--ink-mute); font-size: 0.9375rem; }
        .specs__value { font-family: var(--serif); font-size: 1.1rem; }
        @media (max-width: 640px) {
          .specs__row { grid-template-columns: 1fr; gap: 6px; }
        }
      `}</style>
    </section>
  )
}
