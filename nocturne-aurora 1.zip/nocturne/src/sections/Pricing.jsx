import { plans } from '../data/content.js'
import Reveal, { RevealGroup, RevealItem } from '../components/Reveal.jsx'
import MagneticButton from '../components/MagneticButton.jsx'

export default function Pricing() {
  return (
    <section className="pricing section">
      <div className="wrap">
        <Reveal className="section-head" amount={0.4}>
          <p className="eyebrow">Plans</p>
          <h2>Choose how you bring Aurora home.</h2>
        </Reveal>

        <RevealGroup className="pricing__grid" stagger={0.1}>
          {plans.map((p) => (
            <RevealItem key={p.name}>
              <div className={`pricing__card glass ${p.featured ? 'is-featured' : ''}`}>
                {p.featured && <span className="pricing__badge">Most reserved</span>}
                <h3>{p.name}</h3>
                <p className="pricing__tagline">{p.tagline}</p>
                <div className="pricing__price">
                  <span className="pricing__amount">{p.price}</span>
                  <span className="pricing__period">{p.period}</span>
                </div>
                <ul className="pricing__features">
                  {p.features.map((f) => (
                    <li key={f}>{f}</li>
                  ))}
                </ul>
                <MagneticButton
                  to="/contact"
                  className={`btn btn-block ${p.featured ? 'btn-primary' : 'btn-ghost'}`}
                >
                  {p.name === 'Studio' ? 'Talk to sales' : 'Reserve now'}
                </MagneticButton>
              </div>
            </RevealItem>
          ))}
        </RevealGroup>
      </div>

      <style>{`
        .pricing__grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 24px;
          align-items: stretch;
        }
        .pricing__card {
          padding: 40px 32px;
          display: flex;
          flex-direction: column;
          height: 100%;
          position: relative;
        }
        .pricing__card.is-featured {
          border-color: var(--ember-dim);
          background: linear-gradient(180deg, rgba(242,166,90,0.08), rgba(237,235,245,0.02));
        }
        .pricing__badge {
          position: absolute;
          top: -13px;
          left: 32px;
          background: var(--ember);
          color: #1a1207;
          font-size: 0.75rem;
          font-weight: 500;
          padding: 5px 14px;
          border-radius: 100px;
        }
        .pricing__card h3 { font-size: 1.5rem; margin-bottom: 10px; }
        .pricing__tagline { font-size: 0.9375rem; line-height: 1.55; min-height: 44px; }
        .pricing__price { margin: 24px 0; display: flex; align-items: baseline; gap: 8px; }
        .pricing__amount { font-family: var(--serif); font-size: 2.2rem; }
        .pricing__period { color: var(--ink-mute); font-size: 0.875rem; }
        .pricing__features {
          list-style: none;
          padding: 0;
          margin: 0 0 32px;
          display: flex;
          flex-direction: column;
          gap: 12px;
          flex: 1;
        }
        .pricing__features li {
          font-size: 0.9rem;
          color: var(--ink-dim);
          padding-left: 20px;
          position: relative;
        }
        .pricing__features li::before {
          content: '';
          position: absolute;
          left: 0; top: 8px;
          width: 6px; height: 6px;
          border-radius: 50%;
          background: var(--ember);
        }
        @media (max-width: 900px) {
          .pricing__grid { grid-template-columns: 1fr; }
        }
      `}</style>
    </section>
  )
}
