import { lazy, Suspense, useRef, useState } from 'react'
import { motion, useScroll, useTransform } from 'framer-motion'
import TextReveal from '../components/TextReveal.jsx'
import MagneticButton from '../components/MagneticButton.jsx'
import ErrorBoundary from '../components/ErrorBoundary.jsx'
import OrbFallback from '../components/OrbFallback.jsx'

const Orb3D = lazy(() => import('../components/Orb3D.jsx'))

export default function Hero() {
  const ref = useRef(null)
  const [tilt, setTilt] = useState({ x: 0, y: 0 })

  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ['start start', 'end start'],
  })

  const textY = useTransform(scrollYProgress, [0, 1], [0, -80])
  const orbY = useTransform(scrollYProgress, [0, 1], [0, 60])
  const fade = useTransform(scrollYProgress, [0, 0.7], [1, 0])
  const bgY = useTransform(scrollYProgress, [0, 1], ['0%', '20%'])

  return (
    <section className="hero" ref={ref}>
      <motion.div
        className="hero__field"
        style={{
          y: bgY,
          transform: `translate3d(${tilt.x * -12}px, ${tilt.y * -12}px, 0)`,
        }}
      />

      <div className="wrap hero__grid">
        <motion.div className="hero__copy" style={{ y: textY, opacity: fade }}>
          <motion.p
            className="eyebrow"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.6 }}
          >
            Nocturne Instruments — Aurora
          </motion.p>

          <TextReveal
            as="h1"
            className="hero__headline"
            text="An instrument for the eight hours you don't watch."
            delay={0.1}
          />

          <motion.p
            className="hero__sub"
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7, duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
          >
            Aurora reads your breath, light, and the room around you, then
            shapes each through the night so you fall asleep sooner and wake
            between cycles, not inside one.
          </motion.p>

          <motion.div
            className="hero__ctas"
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.85, duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
          >
            <MagneticButton to="/contact" className="btn btn-primary">
              Reserve Aurora — $429
            </MagneticButton>
            <MagneticButton to="/product" className="btn btn-ghost">
              See how it works
            </MagneticButton>
          </motion.div>
        </motion.div>

        <motion.div
          className="hero__visual"
          style={{ y: orbY }}
          initial={{ opacity: 0, scale: 0.85 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.3, duration: 1.1, ease: [0.16, 1, 0.3, 1] }}
        >
          <Suspense fallback={<OrbFallback />}>
            <ErrorBoundary fallback={<OrbFallback />}>
              <Orb3D onPointerMove={setTilt} />
            </ErrorBoundary>
          </Suspense>
        </motion.div>
      </div>

      <motion.div
        className="hero__scroll"
        style={{ opacity: fade }}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.4, duration: 0.8 }}
      >
        <span className="hero__scroll-line" />
        Scroll
      </motion.div>

      <style>{`
        .hero {
          position: relative;
          min-height: 100svh;
          display: flex;
          align-items: center;
          padding-top: 96px;
          overflow: hidden;
        }
        .hero__field {
          position: absolute;
          inset: -10%;
          background:
            radial-gradient(46% 40% at 78% 32%, rgba(242,166,90,0.14), transparent 60%),
            radial-gradient(38% 32% at 15% 75%, rgba(143,147,232,0.1), transparent 60%);
          pointer-events: none;
        }
        .hero__grid {
          display: grid;
          grid-template-columns: 1.05fr 0.95fr;
          align-items: center;
          gap: 24px;
          width: 100%;
          position: relative;
          z-index: 2;
        }
        .hero__copy { max-width: 560px; }
        .hero__headline {
          font-size: clamp(2.5rem, 5.2vw, 4.4rem);
          margin-bottom: 28px;
        }
        .hero__sub {
          font-size: 1.125rem;
          line-height: 1.65;
          max-width: 460px;
          margin-bottom: 40px;
        }
        .hero__ctas { display: flex; gap: 16px; flex-wrap: wrap; }
        .hero__visual {
          height: clamp(340px, 46vw, 620px);
          position: relative;
        }
        .hero__scroll {
          position: absolute;
          bottom: 40px;
          left: var(--edge);
          display: flex;
          align-items: center;
          gap: 12px;
          font-size: 0.8rem;
          color: var(--ink-mute);
          letter-spacing: 0.02em;
          z-index: 2;
        }
        .hero__scroll-line {
          width: 1px;
          height: 36px;
          background: linear-gradient(var(--ink-mute), transparent);
          position: relative;
          overflow: hidden;
        }
        .hero__scroll-line::after {
          content: '';
          position: absolute;
          left: 0; top: -100%;
          width: 100%; height: 100%;
          background: var(--ember);
          animation: scrollLine 2.2s ease-in-out infinite;
        }
        @keyframes scrollLine {
          0% { top: -100%; }
          60% { top: 100%; }
          100% { top: 100%; }
        }
        @media (max-width: 940px) {
          .hero__grid { grid-template-columns: 1fr; }
          .hero__visual { order: -1; height: 320px; }
          .hero { padding-top: 120px; }
        }
      `}</style>
    </section>
  )
}
