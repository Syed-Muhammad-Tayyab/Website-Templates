import { useRef } from 'react'
import { motion } from 'framer-motion'
import { testimonials } from '../data/content.js'
import Reveal from '../components/Reveal.jsx'

export default function Testimonials() {
  const trackRef = useRef(null)

  return (
    <section className="testi section">
      <div className="wrap section-head">
        <Reveal>
          <p className="eyebrow">Owners</p>
          <h2>People notice within a week.</h2>
        </Reveal>
      </div>

      <div className="testi__viewport wrap">
        <motion.div ref={trackRef} className="testi__track" drag="x" dragConstraints={{ left: -900, right: 0 }} dragElastic={0.08}>
          {testimonials.map((t, i) => (
            <motion.figure
              key={t.name}
              className="testi__card glass"
              initial={{ opacity: 0, y: 30, rotate: i % 2 === 0 ? -1.5 : 1.5 }}
              whileInView={{ opacity: 1, y: 0, rotate: 0 }}
              viewport={{ once: true, amount: 0.4 }}
              transition={{ duration: 0.7, delay: i * 0.06, ease: [0.16, 1, 0.3, 1] }}
            >
              <blockquote>&ldquo;{t.quote}&rdquo;</blockquote>
              <figcaption>
                <span className="testi__name">{t.name}</span>
                <span className="testi__role">{t.role}</span>
              </figcaption>
            </motion.figure>
          ))}
        </motion.div>
      </div>
      <p className="testi__hint wrap">Drag to browse</p>

      <style>{`
        .testi__viewport { overflow: hidden; cursor: grab; }
        .testi__track {
          display: flex;
          gap: 24px;
          width: max-content;
        }
        .testi__card {
          width: min(78vw, 380px);
          padding: 36px 32px;
          flex-shrink: 0;
        }
        .testi__card blockquote {
          margin: 0 0 28px;
          font-family: var(--serif);
          font-size: 1.35rem;
          line-height: 1.5;
          color: var(--ink);
          font-style: italic;
        }
        .testi__card figcaption { display: flex; flex-direction: column; gap: 2px; }
        .testi__name { font-size: 0.95rem; color: var(--ink); }
        .testi__role { font-size: 0.825rem; color: var(--ink-mute); }
        .testi__hint {
          margin-top: 20px;
          font-size: 0.8rem;
          color: var(--ink-mute);
        }
      `}</style>
    </section>
  )
}
