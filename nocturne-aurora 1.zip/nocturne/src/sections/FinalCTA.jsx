import { motion } from 'framer-motion'
import TextReveal from '../components/TextReveal.jsx'
import MagneticButton from '../components/MagneticButton.jsx'

export default function FinalCTA() {
  return (
    <section className="finalcta">
      <div className="wrap finalcta__inner">
        <TextReveal as="h2" text="Sleep like it's an instrument you tune, not a problem you fix." />
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5, duration: 0.7 }}
          className="finalcta__ctas"
        >
          <MagneticButton to="/contact" className="btn btn-primary">Reserve Aurora — $429</MagneticButton>
          <MagneticButton to="/technology" className="btn btn-ghost">Read the research</MagneticButton>
        </motion.div>
      </div>

      <style>{`
        .finalcta {
          padding: var(--section-pad) 0;
          text-align: center;
          background: radial-gradient(60% 100% at 50% 0%, rgba(242,166,90,0.08), transparent 70%);
        }
        .finalcta__inner h2 {
          font-size: clamp(2rem, 4.4vw, 3.4rem);
          max-width: 820px;
          margin: 0 auto 40px;
        }
        .finalcta__ctas { display: flex; justify-content: center; gap: 16px; flex-wrap: wrap; }
      `}</style>
    </section>
  )
}
