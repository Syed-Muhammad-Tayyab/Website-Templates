import { useRef } from 'react'
import { motion, useScroll, useTransform } from 'framer-motion'
import { materials } from '../data/content.js'

export default function HorizontalScroll() {
  const ref = useRef(null)
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start start', 'end end'] })
  const x = useTransform(scrollYProgress, [0, 1], ['1%', '-72%'])

  return (
    <section className="hscroll" ref={ref}>
      <div className="hscroll__sticky">
        <div className="hscroll__head wrap">
          <p className="eyebrow">Materials</p>
          <h2>Built like an instrument, not a gadget.</h2>
        </div>

        <motion.div className="hscroll__track" style={{ x }}>
          {materials.map((m, i) => (
            <article key={m.title} className="hscroll__card glass">
              <span className="hscroll__index">{String(i + 1).padStart(2, '0')}</span>
              <h3>{m.title}</h3>
              <p>{m.body}</p>
            </article>
          ))}
        </motion.div>
      </div>

      <style>{`
        .hscroll { height: 260vh; position: relative; }
        .hscroll__sticky {
          position: sticky;
          top: 0;
          height: 100svh;
          display: flex;
          flex-direction: column;
          justify-content: center;
          gap: 48px;
          overflow: hidden;
        }
        .hscroll__head h2 {
          font-size: clamp(1.8rem, 3.4vw, 2.6rem);
          max-width: 620px;
          margin-top: 14px;
        }
        .hscroll__track {
          display: flex;
          gap: 28px;
          padding-left: var(--edge);
          width: max-content;
        }
        .hscroll__card {
          width: min(78vw, 400px);
          padding: 40px 32px;
          flex-shrink: 0;
        }
        .hscroll__index {
          font-family: var(--serif);
          font-size: 0.95rem;
          color: var(--ember);
        }
        .hscroll__card h3 {
          font-size: 1.5rem;
          margin: 20px 0 14px;
        }
        .hscroll__card p { line-height: 1.6; }
      `}</style>
    </section>
  )
}
