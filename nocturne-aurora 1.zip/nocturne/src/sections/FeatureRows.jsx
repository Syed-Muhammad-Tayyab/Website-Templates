import { motion } from 'framer-motion'
import { features } from '../data/content.js'
import Reveal from '../components/Reveal.jsx'

const GLOWS = ['#f2a65a', '#8f93e8', '#e8845a', '#6ea6e8']

function FeatureVisual({ index }) {
  return (
    <div className="frow__visual glass">
      <motion.div
        className="frow__orb"
        style={{ background: `radial-gradient(circle at 35% 30%, ${GLOWS[index % GLOWS.length]}, transparent 70%)` }}
        animate={{ scale: [1, 1.06, 1], rotate: [0, 8, 0] }}
        transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut' }}
      />
      <span className="frow__ring" />
    </div>
  )
}

export default function FeatureRows() {
  return (
    <section className="frows section">
      {features.map((f, i) => (
        <div key={f.title} className="wrap frow" data-reverse={i % 2 === 1}>
          <Reveal direction={i % 2 === 0 ? 'left' : 'right'} className="frow__text">
            <span className="frow__num">{String(i + 1).padStart(2, '0')}</span>
            <h3>{f.title}</h3>
            <p>{f.body}</p>
          </Reveal>
          <Reveal direction={i % 2 === 0 ? 'right' : 'left'} delay={0.1} scale className="frow__visualwrap">
            <FeatureVisual index={i} />
          </Reveal>
        </div>
      ))}

      <style>{`
        .frow {
          display: grid;
          grid-template-columns: 0.9fr 1.1fr;
          align-items: center;
          gap: 56px;
          padding: 64px 0;
          border-bottom: 1px solid var(--line);
        }
        .frow:last-child { border-bottom: none; }
        .frow[data-reverse="true"] .frow__text { order: 2; }
        .frow[data-reverse="true"] .frow__visualwrap { order: 1; }
        .frow__num {
          font-family: var(--serif);
          color: var(--ember);
          font-size: 1rem;
        }
        .frow__text h3 { font-size: 2rem; margin: 14px 0 16px; }
        .frow__text p { font-size: 1.05rem; line-height: 1.65; max-width: 420px; }
        .frow__visualwrap { display: flex; justify-content: center; }
        .frow__visual {
          width: 100%;
          max-width: 380px;
          aspect-ratio: 1.2;
          position: relative;
          display: flex;
          align-items: center;
          justify-content: center;
          overflow: hidden;
        }
        .frow__orb {
          width: 60%;
          height: 60%;
          border-radius: 50%;
          filter: blur(2px);
        }
        .frow__ring {
          position: absolute;
          width: 82%;
          height: 82%;
          border: 1px solid var(--line-strong);
          border-radius: 50%;
        }
        @media (max-width: 860px) {
          .frow, .frow[data-reverse="true"] .frow__text, .frow[data-reverse="true"] .frow__visualwrap {
            grid-template-columns: 1fr;
            order: initial;
          }
          .frow { grid-template-columns: 1fr; text-align: center; }
          .frow__text p { margin: 0 auto; }
        }
      `}</style>
    </section>
  )
}
