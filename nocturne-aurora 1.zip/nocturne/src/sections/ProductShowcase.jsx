import { Link } from 'react-router-dom'
import Reveal, { RevealGroup, RevealItem } from '../components/Reveal.jsx'
import TiltCard from '../components/TiltCard.jsx'
import { features } from '../data/content.js'

export default function ProductShowcase() {
  return (
    <section className="showcase section">
      <div className="wrap showcase__head">
        <Reveal className="section-head">
          <p className="eyebrow">Inside Aurora</p>
          <h2>Four systems, working through the night in silence.</h2>
          <p>
            Everything Aurora does happens without a screen to check or an
            app to open. Light, sound, air, and sensing, tuned as one
            instrument.
          </p>
        </Reveal>
        <Reveal direction="left" delay={0.1}>
          <Link to="/product" className="btn btn-ghost">Full specifications</Link>
        </Reveal>
      </div>

      <RevealGroup className="showcase__grid" stagger={0.1}>
        {features.map((f) => (
          <RevealItem key={f.title}>
            <TiltCard className="showcase__card glass" max={7}>
              <h3>{f.title}</h3>
              <p>{f.body}</p>
            </TiltCard>
          </RevealItem>
        ))}
      </RevealGroup>

      <style>{`
        .showcase__head {
          display: flex;
          justify-content: space-between;
          align-items: flex-end;
          gap: 32px;
          margin-bottom: 56px;
        }
        .showcase__head .section-head { margin-bottom: 0; }
        .showcase__grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 24px;
          max-width: var(--container);
          margin: 0 auto;
          padding: 0 var(--edge);
        }
        .showcase__card { padding: 40px; min-height: 220px; }
        .showcase__card h3 { font-size: 1.3rem; margin-bottom: 14px; }
        .showcase__card p { line-height: 1.6; }
        @media (max-width: 860px) {
          .showcase__head { flex-direction: column; align-items: flex-start; }
          .showcase__grid { grid-template-columns: 1fr; }
        }
      `}</style>
    </section>
  )
}
