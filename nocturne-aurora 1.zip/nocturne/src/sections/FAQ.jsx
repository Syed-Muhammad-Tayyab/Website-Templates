import { useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { faqs } from '../data/content.js'
import Reveal from '../components/Reveal.jsx'

function Item({ item, isOpen, onToggle }) {
  return (
    <div className="faq__item">
      <button className="faq__q" onClick={onToggle} aria-expanded={isOpen}>
        <span>{item.q}</span>
        <span className={`faq__icon ${isOpen ? 'is-open' : ''}`}>
          <span />
          <span />
        </span>
      </button>
      <AnimatePresence initial={false}>
        {isOpen && (
          <motion.div
            className="faq__a-wrap"
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
          >
            <p className="faq__a">{item.a}</p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

export default function FAQ() {
  const [open, setOpen] = useState(0)

  return (
    <section className="faq section">
      <div className="wrap faq__grid">
        <Reveal className="faq__head">
          <p className="eyebrow">Questions</p>
          <h2>Before you reserve one.</h2>
        </Reveal>

        <div className="faq__list">
          {faqs.map((item, i) => (
            <Item key={item.q} item={item} isOpen={open === i} onToggle={() => setOpen(open === i ? -1 : i)} />
          ))}
        </div>
      </div>

      <style>{`
        .faq__grid {
          display: grid;
          grid-template-columns: 0.7fr 1.3fr;
          gap: 56px;
        }
        .faq__head h2 { font-size: clamp(1.8rem, 3vw, 2.3rem); margin-top: 14px; }
        .faq__list { border-top: 1px solid var(--line); }
        .faq__item { border-bottom: 1px solid var(--line); }
        .faq__q {
          width: 100%;
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 26px 0;
          text-align: left;
          font-family: var(--serif);
          font-size: 1.15rem;
          color: var(--ink);
          gap: 24px;
        }
        .faq__icon {
          position: relative;
          width: 18px; height: 18px;
          flex-shrink: 0;
        }
        .faq__icon span {
          position: absolute;
          background: var(--ink-mute);
          transition: transform 0.35s var(--ease), background 0.3s ease;
        }
        .faq__icon span:first-child { top: 8px; left: 0; width: 18px; height: 1px; }
        .faq__icon span:last-child { top: 0; left: 8px; width: 1px; height: 18px; }
        .faq__icon.is-open span { background: var(--ember); }
        .faq__icon.is-open span:last-child { transform: scaleY(0); }
        .faq__a-wrap { overflow: hidden; }
        .faq__a { padding-bottom: 26px; max-width: 620px; line-height: 1.65; }
        @media (max-width: 860px) {
          .faq__grid { grid-template-columns: 1fr; gap: 24px; }
        }
      `}</style>
    </section>
  )
}
