import { useEffect, useRef, useState } from 'react'
import { motion, useInView } from 'framer-motion'
import { stats } from '../data/content.js'

function Counter({ value, suffix }) {
  const ref = useRef(null)
  const inView = useInView(ref, { once: true, amount: 0.6 })
  const [display, setDisplay] = useState(0)

  useEffect(() => {
    if (!inView) return
    let start = null
    const duration = 1400
    const step = (ts) => {
      if (!start) start = ts
      const progress = Math.min((ts - start) / duration, 1)
      const eased = 1 - Math.pow(1 - progress, 3)
      setDisplay(Math.round(eased * value))
      if (progress < 1) requestAnimationFrame(step)
    }
    requestAnimationFrame(step)
  }, [inView, value])

  return (
    <span ref={ref} className="stat__value">
      {display}
      <span className="stat__suffix">{suffix}</span>
    </span>
  )
}

export default function Stats() {
  return (
    <section className="stats section">
      <div className="wrap stats__grid">
        {stats.map((s, i) => (
          <motion.div
            key={s.label}
            className="stat"
            initial={{ opacity: 0, y: 28 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.5 }}
            transition={{ duration: 0.6, delay: i * 0.08, ease: [0.16, 1, 0.3, 1] }}
          >
            <Counter value={s.value} suffix={s.suffix} />
            <p>{s.label}</p>
          </motion.div>
        ))}
      </div>

      <style>{`
        .stats__grid {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 32px;
        }
        .stat {
          padding: 32px 8px 0;
          border-top: 1px solid var(--line);
        }
        .stat__value {
          display: block;
          font-family: var(--serif);
          font-size: clamp(2.4rem, 4vw, 3.4rem);
          color: var(--ink);
          margin-bottom: 14px;
        }
        .stat__suffix { color: var(--ember); font-size: 0.6em; margin-left: 2px; }
        .stat p { font-size: 0.9375rem; line-height: 1.5; max-width: 220px; }
        @media (max-width: 860px) {
          .stats__grid { grid-template-columns: repeat(2, 1fr); }
        }
      `}</style>
    </section>
  )
}
