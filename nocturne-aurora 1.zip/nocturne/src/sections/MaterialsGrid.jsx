import { materials } from '../data/content.js'
import Reveal, { RevealGroup, RevealItem } from '../components/Reveal.jsx'
import TiltCard from '../components/TiltCard.jsx'

export default function MaterialsGrid() {
  return (
    <section className="matgrid section">
      <div className="wrap">
        <Reveal className="section-head">
          <p className="eyebrow">Craft</p>
          <h2>Four materials, each chosen for one job.</h2>
        </Reveal>

        <RevealGroup className="matgrid__grid" stagger={0.08}>
          {materials.map((m) => (
            <RevealItem key={m.title}>
              <TiltCard className="matgrid__card glass" max={6}>
                <h3>{m.title}</h3>
                <p>{m.body}</p>
              </TiltCard>
            </RevealItem>
          ))}
        </RevealGroup>
      </div>

      <style>{`
        .matgrid__grid {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 20px;
        }
        .matgrid__card { padding: 32px 26px; min-height: 200px; }
        .matgrid__card h3 { font-size: 1.1rem; margin-bottom: 12px; }
        .matgrid__card p { font-size: 0.9375rem; line-height: 1.55; }
        @media (max-width: 960px) {
          .matgrid__grid { grid-template-columns: repeat(2, 1fr); }
        }
      `}</style>
    </section>
  )
}
