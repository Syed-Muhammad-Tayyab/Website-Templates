import { useRef, useState } from 'react'
import { motion, useMotionValueEvent, useScroll, useTransform } from 'framer-motion'
import { phases } from '../data/content.js'
import Reveal from '../components/Reveal.jsx'

const PHASE_GRADIENTS = [
  'radial-gradient(60% 60% at 50% 40%, #2a2440 0%, #0b0e1a 70%)',
  'radial-gradient(60% 60% at 50% 40%, #241d38 0%, #0b0e1a 70%)',
  'radial-gradient(60% 60% at 50% 40%, #10101f 0%, #050608 70%)',
  'radial-gradient(60% 60% at 50% 40%, #3a2a1c 0%, #0b0e1a 70%)',
]

export default function StickyStory() {
  const ref = useRef(null)
  const [active, setActive] = useState(0)

  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ['start start', 'end end'],
  })

  useMotionValueEvent(scrollYProgress, 'change', (v) => {
    const idx = Math.min(phases.length - 1, Math.floor(v * phases.length))
    setActive(idx)
  })

  const dialRotate = useTransform(scrollYProgress, [0, 1], [0, 320])

  return (
    <section className="story" ref={ref} style={{ height: `${phases.length * 100}vh` }}>
      <div className="story__sticky">
        <motion.div
          className="story__bg"
          animate={{ background: PHASE_GRADIENTS[active] }}
          transition={{ duration: 1.1, ease: 'easeInOut' }}
        />

        <div className="wrap story__grid">
          <div className="story__visual">
            <div className="story__dial-wrap">
              <motion.svg viewBox="0 0 200 200" className="story__dial" style={{ rotate: dialRotate }}>
                <circle cx="100" cy="100" r="92" fill="none" stroke="var(--line-strong)" strokeWidth="1" />
                {phases.map((p, i) => {
                  const angle = (i / phases.length) * 2 * Math.PI - Math.PI / 2
                  const cx = 100 + Math.cos(angle) * 92
                  const cy = 100 + Math.sin(angle) * 92
                  return <circle key={p.n} cx={cx} cy={cy} r={i === active ? 5 : 3} fill={i === active ? 'var(--ember)' : 'var(--ink-mute)'} />
                })}
              </motion.svg>
              <div className="story__dial-center">
                <span className="story__dial-num">{phases[active].n}</span>
                <span className="story__dial-time">{phases[active].time}</span>
              </div>
            </div>
          </div>

          <div className="story__text">
            <p className="eyebrow">A night with Aurora</p>
            {phases.map((p, i) => (
              <div key={p.n} className="story__phase" data-active={i === active}>
                <span className="story__phase-n">{p.n}</span>
                <h3>{p.title}</h3>
                <p>{p.body}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      <style>{`
        .story { position: relative; }
        .story__sticky {
          position: sticky;
          top: 0;
          height: 100svh;
          display: flex;
          align-items: center;
          overflow: hidden;
        }
        .story__bg { position: absolute; inset: 0; z-index: 0; }
        .story__grid {
          position: relative;
          z-index: 1;
          display: grid;
          grid-template-columns: 0.85fr 1.15fr;
          gap: 64px;
          align-items: center;
          width: 100%;
        }
        .story__visual { display: flex; justify-content: center; }
        .story__dial-wrap { position: relative; width: min(320px, 70vw); aspect-ratio: 1; }
        .story__dial { width: 100%; height: 100%; }
        .story__dial-center {
          position: absolute; inset: 0;
          display: flex; flex-direction: column;
          align-items: center; justify-content: center;
          gap: 6px;
        }
        .story__dial-num {
          font-family: var(--serif);
          font-size: 2.6rem;
          color: var(--ember);
        }
        .story__dial-time {
          font-size: 0.85rem;
          color: var(--ink-mute);
          letter-spacing: 0.04em;
        }
        .story__phase {
          padding: 22px 0;
          opacity: 0.28;
          transition: opacity 0.5s ease;
          border-bottom: 1px solid var(--line);
          display: grid;
          grid-template-columns: 44px 1fr;
          gap: 4px 16px;
        }
        .story__phase:last-child { border-bottom: none; }
        .story__phase[data-active="true"] { opacity: 1; }
        .story__phase-n {
          font-family: var(--serif);
          color: var(--ink-mute);
          font-size: 0.95rem;
          padding-top: 4px;
        }
        .story__phase h3 { font-size: 1.6rem; margin-bottom: 6px; }
        .story__phase p { max-width: 460px; line-height: 1.6; }
        @media (max-width: 860px) {
          .story__grid { grid-template-columns: 1fr; text-align: center; }
          .story__phase { grid-template-columns: 1fr; text-align: left; }
          .story__visual { order: -1; }
        }
      `}</style>
    </section>
  )
}
