import TextReveal from './TextReveal.jsx'
import { motion } from 'framer-motion'

export default function PageHero({ eyebrow, title, sub, children }) {
  return (
    <section className="pagehero">
      <div className="wrap pagehero__inner">
        <motion.p
          className="eyebrow"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          {eyebrow}
        </motion.p>
        <TextReveal as="h1" text={title} className="pagehero__title" />
        {sub && (
          <motion.p
            className="pagehero__sub"
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.7 }}
          >
            {sub}
          </motion.p>
        )}
        {children}
      </div>

      <style>{`
        .pagehero {
          padding: 168px 0 72px;
          position: relative;
        }
        .pagehero::before {
          content: '';
          position: absolute;
          inset: 0;
          background: radial-gradient(50% 60% at 85% 0%, rgba(242,166,90,0.09), transparent 65%);
          pointer-events: none;
        }
        .pagehero__inner { position: relative; }
        .pagehero__title {
          font-size: clamp(2.2rem, 5vw, 3.8rem);
          max-width: 760px;
          margin: 22px 0 26px;
        }
        .pagehero__sub {
          font-size: 1.0625rem;
          line-height: 1.65;
          max-width: 520px;
          color: var(--ink-dim);
        }
      `}</style>
    </section>
  )
}
