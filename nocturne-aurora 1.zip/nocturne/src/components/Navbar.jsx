import { useEffect, useState } from 'react'
import { Link, NavLink } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'

const LINKS = [
  { to: '/', label: 'Home' },
  { to: '/product', label: 'Aurora' },
  { to: '/technology', label: 'Technology' },
  { to: '/contact', label: 'Pre-order' },
]

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [open, setOpen] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  useEffect(() => {
    document.body.style.overflow = open ? 'hidden' : ''
  }, [open])

  return (
    <header className={`nav ${scrolled ? 'nav--scrolled' : ''}`}>
      <div className="wrap nav__row">
        <Link to="/" className="nav__mark" onClick={() => setOpen(false)}>
          <span className="nav__dot" />
          Nocturne
        </Link>

        <nav className="nav__links">
          {LINKS.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              className={({ isActive }) => `nav__link ${isActive ? 'is-active' : ''}`}
            >
              {l.label}
            </NavLink>
          ))}
        </nav>

        <Link to="/contact" className="btn btn-ghost nav__cta">
          Reserve Aurora
        </Link>

        <button
          className={`nav__burger ${open ? 'is-open' : ''}`}
          aria-label="Toggle menu"
          aria-expanded={open}
          onClick={() => setOpen((v) => !v)}
        >
          <span />
          <span />
        </button>
      </div>

      <AnimatePresence>
        {open && (
          <motion.div
            className="nav__mobile"
            initial={{ opacity: 0, y: -12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
          >
            {LINKS.map((l, i) => (
              <motion.div
                key={l.to}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.05 * i, duration: 0.4 }}
              >
                <NavLink to={l.to} onClick={() => setOpen(false)} className="nav__mobile-link">
                  {l.label}
                </NavLink>
              </motion.div>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      <style>{`
        .nav {
          position: fixed;
          top: 0; left: 0; right: 0;
          z-index: 50;
          padding: 22px 0;
          transition: padding 0.4s var(--ease), background 0.4s ease, border-color 0.4s ease;
          border-bottom: 1px solid transparent;
        }
        .nav--scrolled {
          padding: 14px 0;
          background: rgba(11, 14, 26, 0.72);
          backdrop-filter: blur(14px);
          border-color: var(--line);
        }
        .nav__row {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 24px;
        }
        .nav__mark {
          font-family: var(--serif);
          font-size: 1.25rem;
          display: flex;
          align-items: center;
          gap: 10px;
          letter-spacing: -0.01em;
        }
        .nav__dot {
          width: 8px; height: 8px;
          border-radius: 50%;
          background: var(--ember);
          box-shadow: 0 0 14px 2px var(--ember-glow);
        }
        .nav__links {
          display: flex;
          gap: 36px;
          margin-right: auto;
          margin-left: 64px;
        }
        .nav__link {
          font-size: 0.9rem;
          color: var(--ink-dim);
          position: relative;
          padding: 4px 0;
          transition: color 0.3s ease;
        }
        .nav__link:hover, .nav__link.is-active { color: var(--ink); }
        .nav__link.is-active::after {
          content: '';
          position: absolute;
          left: 0; right: 0; bottom: -6px;
          height: 1px;
          background: var(--ember);
        }
        .nav__cta { padding: 11px 22px; font-size: 0.875rem; }
        .nav__burger {
          display: none;
          width: 32px; height: 22px;
          position: relative;
        }
        .nav__burger span {
          position: absolute; left: 0; right: 0;
          height: 1px; background: var(--ink);
          transition: transform 0.35s var(--ease), opacity 0.3s ease, top 0.35s var(--ease);
        }
        .nav__burger span:first-child { top: 4px; }
        .nav__burger span:last-child { top: 16px; }
        .nav__burger.is-open span:first-child { top: 10px; transform: rotate(45deg); }
        .nav__burger.is-open span:last-child { top: 10px; transform: rotate(-45deg); }

        .nav__mobile {
          display: none;
        }

        @media (max-width: 860px) {
          .nav__links, .nav__cta { display: none; }
          .nav__burger { display: block; }
          .nav__mobile {
            display: flex;
            flex-direction: column;
            gap: 4px;
            padding: 12px var(--edge) 28px;
            background: rgba(11, 14, 26, 0.98);
            border-bottom: 1px solid var(--line);
          }
          .nav__mobile-link {
            display: block;
            padding: 14px 4px;
            font-family: var(--serif);
            font-size: 1.75rem;
            border-bottom: 1px solid var(--line);
            color: var(--ink);
          }
        }
      `}</style>
    </header>
  )
}
