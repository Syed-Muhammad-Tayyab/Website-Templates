import { useEffect, useState } from 'react'
import { motion, useMotionValue, useSpring } from 'framer-motion'

export default function CursorGlow() {
  const [active, setActive] = useState(false)
  const x = useMotionValue(-200)
  const y = useMotionValue(-200)
  const sx = useSpring(x, { stiffness: 120, damping: 22, mass: 0.6 })
  const sy = useSpring(y, { stiffness: 120, damping: 22, mass: 0.6 })

  useEffect(() => {
    const isFine = window.matchMedia('(pointer: fine)').matches
    if (!isFine) return
    const move = (e) => {
      x.set(e.clientX)
      y.set(e.clientY)
      if (!active) setActive(true)
    }
    window.addEventListener('mousemove', move)
    return () => window.removeEventListener('mousemove', move)
  }, [x, y, active])

  if (!active) return null

  return (
    <motion.div
      aria-hidden="true"
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        width: 420,
        height: 420,
        borderRadius: '50%',
        pointerEvents: 'none',
        zIndex: 1,
        translateX: sx,
        translateY: sy,
        x: '-50%',
        y: '-50%',
        background:
          'radial-gradient(circle, rgba(242,166,90,0.06) 0%, rgba(242,166,90,0) 70%)',
      }}
    />
  )
}
