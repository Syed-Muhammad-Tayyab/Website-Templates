import { Suspense, useRef } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { Float, MeshDistortMaterial, Sparkles } from '@react-three/drei'

function Core({ mouse }) {
  const mesh = useRef()
  const light = useRef()

  useFrame((state) => {
    const t = state.clock.getElapsedTime()
    if (mesh.current) {
      mesh.current.rotation.y = t * 0.12 + mouse.current.x * 0.4
      mesh.current.rotation.x = mouse.current.y * 0.25
    }
    if (light.current) {
      light.current.position.x = Math.sin(t * 0.3) * 3
    }
  })

  return (
    <Float speed={1.4} rotationIntensity={0.35} floatIntensity={0.9}>
      <mesh ref={mesh}>
        <icosahedronGeometry args={[1.4, 12]} />
        <MeshDistortMaterial
          color="#f2a65a"
          emissive="#8f4a1a"
          emissiveIntensity={0.35}
          roughness={0.15}
          metalness={0.3}
          distort={0.32}
          speed={1.6}
        />
      </mesh>
      <mesh scale={1.55}>
        <icosahedronGeometry args={[1.4, 6]} />
        <meshBasicMaterial color="#f2a65a" transparent opacity={0.045} wireframe />
      </mesh>
    </Float>
  )
}

export default function Orb3D({ onPointerMove }) {
  const mouse = useRef({ x: 0, y: 0 })

  const handleMove = (e) => {
    const x = (e.clientX / window.innerWidth) * 2 - 1
    const y = (e.clientY / window.innerHeight) * 2 - 1
    mouse.current = { x, y }
    onPointerMove && onPointerMove({ x, y })
  }

  return (
    <div className="orb3d" onPointerMove={handleMove}>
      <Canvas
        camera={{ position: [0, 0, 5.2], fov: 42 }}
        dpr={[1, 1.6]}
        gl={{ antialias: true, alpha: true }}
      >
        <ambientLight intensity={0.4} />
        <pointLight position={[3, 2, 4]} intensity={40} color="#f2a65a" />
        <pointLight position={[-4, -2, -2]} intensity={12} color="#8f93e8" />
        <pointLight position={[0, -3, 2]} intensity={8} color="#ffffff" />
        <Suspense fallback={null}>
          <Core mouse={mouse} />
          <Sparkles count={40} scale={5} size={2} speed={0.25} color="#f2a65a" opacity={0.5} />
        </Suspense>
      </Canvas>
      <style>{`
        .orb3d {
          width: 100%;
          height: 100%;
          touch-action: none;
        }
      `}</style>
    </div>
  )
}
