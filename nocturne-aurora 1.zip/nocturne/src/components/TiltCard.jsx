import { useRef } from 'react'
import { motion, useMotionValue, useSpring, useTransform } from 'framer-motion'

export default function TiltCard({ children, className = '', max = 10 }) {
  const ref = useRef(null)
  const rx = useMotionValue(0)
  const ry = useMotionValue(0)
  const srx = useSpring(rx, { stiffness: 180, damping: 16 })
  const sry = useSpring(ry, { stiffness: 180, damping: 16 })

  const glareX = useTransform(sry, [-max, max], ['0%', '100%'])
  const glareY = useTransform(srx, [max, -max], ['0%', '100%'])

  const handleMove = (e) => {
    const rect = ref.current.getBoundingClientRect()
    const px = (e.clientX - rect.left) / rect.width
    const py = (e.clientY - rect.top) / rect.height
    ry.set((px - 0.5) * max * 2)
    rx.set((py - 0.5) * -max * 2)
  }

  const reset = () => {
    rx.set(0)
    ry.set(0)
  }

  return (
    <motion.div
      ref={ref}
      className={`tilt ${className}`}
      onMouseMove={handleMove}
      onMouseLeave={reset}
      style={{ rotateX: srx, rotateY: sry, transformPerspective: 900 }}
    >
      <div className="tilt__content">{children}</div>
      <motion.div
        className="tilt__glare"
        style={{
          background: useTransform(
            [glareX, glareY],
            ([gx, gy]) => `radial-gradient(circle at ${gx} ${gy}, rgba(242,166,90,0.14), transparent 60%)`
          ),
        }}
      />
      <style>{`
        .tilt {
          position: relative;
          transform-style: preserve-3d;
        }
        .tilt__content { position: relative; z-index: 1; transform: translateZ(20px); }
        .tilt__glare {
          position: absolute;
          inset: 0;
          border-radius: inherit;
          pointer-events: none;
        }
      `}</style>
    </motion.div>
  )
}
