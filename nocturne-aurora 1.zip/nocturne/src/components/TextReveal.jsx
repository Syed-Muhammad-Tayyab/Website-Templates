import { motion } from 'framer-motion'

/**
 * Splits text into words and reveals each with a clipped upward
 * slide. Used sparingly — headlines only.
 */
export default function TextReveal({ text, as: Tag = 'h1', className = '', delay = 0 }) {
  const words = text.split(' ')

  return (
    <Tag className={className} aria-label={text}>
      {words.map((word, i) => (
        <span key={i} className="tr__mask" aria-hidden="true">
          <motion.span
            className="tr__word"
            initial={{ y: '110%' }}
            whileInView={{ y: '0%' }}
            viewport={{ once: true, amount: 0.9 }}
            transition={{
              duration: 0.9,
              delay: delay + i * 0.05,
              ease: [0.16, 1, 0.3, 1],
            }}
          >
            {word}
            {i < words.length - 1 ? '\u00A0' : ''}
          </motion.span>
        </span>
      ))}
      <style>{`
        .tr__mask {
          display: inline-block;
          overflow: hidden;
          vertical-align: top;
        }
        .tr__word {
          display: inline-block;
          will-change: transform;
        }
      `}</style>
    </Tag>
  )
}
