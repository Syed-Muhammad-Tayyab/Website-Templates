export default function OrbFallback() {
  return (
    <div className="orbfallback">
      <div className="orbfallback__glow" />
      <style>{`
        .orbfallback {
          width: 100%;
          height: 100%;
          display: flex;
          align-items: center;
          justify-content: center;
        }
        .orbfallback__glow {
          width: 46%;
          aspect-ratio: 1;
          border-radius: 50%;
          background: radial-gradient(circle at 35% 30%, var(--ember), transparent 70%);
          filter: blur(6px);
          opacity: 0.5;
          animation: orbPulse 2.6s ease-in-out infinite;
        }
        @keyframes orbPulse {
          0%, 100% { transform: scale(1); opacity: 0.4; }
          50% { transform: scale(1.06); opacity: 0.6; }
        }
      `}</style>
    </div>
  )
}
