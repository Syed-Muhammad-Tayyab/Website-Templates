import { Link } from 'react-router-dom'

export default function Footer() {
  return (
    <footer className="footer">
      <div className="wrap footer__top">
        <div className="footer__brand">
          <Link to="/" className="footer__mark">
            <span className="nav__dot" />
            Nocturne
          </Link>
          <p>
            Instruments for the hours you don't remember. Designed and assembled
            in small batches in Porto Novo.
          </p>
        </div>

        <div className="footer__cols">
          <div>
            <h4>Product</h4>
            <Link to="/product">Aurora</Link>
            <Link to="/product">Specifications</Link>
            <Link to="/contact">Pricing</Link>
          </div>
          <div>
            <h4>Company</h4>
            <Link to="/technology">Technology</Link>
            <Link to="/technology">Our story</Link>
            <Link to="/contact">Contact</Link>
          </div>
          <div>
            <h4>Follow</h4>
            <a href="#">Journal</a>
            <a href="#">Instagram</a>
            <a href="#">Newsletter</a>
          </div>
        </div>
      </div>

      <div className="wrap footer__bottom">
        <span>&copy; {new Date().getFullYear()} Nocturne Instruments Ltd.</span>
        <span>Made for people who take sleep seriously.</span>
      </div>

      <style>{`
        .footer {
          background: #080a13;
          border-top: 1px solid var(--line);
          padding-top: var(--section-pad);
        }
        .footer__top {
          display: grid;
          grid-template-columns: 1.2fr 1fr;
          gap: 64px;
          padding-bottom: 72px;
        }
        .footer__mark {
          font-family: var(--serif);
          font-size: 1.4rem;
          display: flex;
          align-items: center;
          gap: 10px;
          margin-bottom: 20px;
        }
        .footer__brand p {
          max-width: 340px;
          font-size: 0.95rem;
          line-height: 1.6;
        }
        .footer__cols {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 24px;
        }
        .footer__cols h4 {
          font-family: var(--sans);
          font-size: 0.8rem;
          color: var(--ink-mute);
          font-weight: 500;
          margin-bottom: 18px;
        }
        .footer__cols a {
          display: block;
          color: var(--ink-dim);
          font-size: 0.925rem;
          padding: 6px 0;
          transition: color 0.25s ease;
          width: fit-content;
        }
        .footer__cols a:hover { color: var(--ember); }
        .footer__bottom {
          display: flex;
          justify-content: space-between;
          padding: 26px var(--edge);
          border-top: 1px solid var(--line);
          font-size: 0.8125rem;
          color: var(--ink-mute);
        }
        @media (max-width: 720px) {
          .footer__top { grid-template-columns: 1fr; }
          .footer__cols { grid-template-columns: repeat(3, 1fr); gap: 16px; }
          .footer__bottom { flex-direction: column; gap: 8px; }
        }
      `}</style>
    </footer>
  )
}
