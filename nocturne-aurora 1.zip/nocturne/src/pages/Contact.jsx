import PageHero from '../components/PageHero.jsx'
import Pricing from '../sections/Pricing.jsx'
import PreorderForm from '../sections/PreorderForm.jsx'
import FAQ from '../sections/FAQ.jsx'

export default function Contact() {
  return (
    <>
      <PageHero
        eyebrow="Reserve Aurora"
        title="Twelve thousand nightstands so far. Yours could be next."
        sub="Production runs are limited to keep every unit hand-finished. Reserve now to join the next batch shipping in 6–8 weeks."
      />
      <Pricing />
      <PreorderForm />
      <FAQ />
    </>
  )
}
