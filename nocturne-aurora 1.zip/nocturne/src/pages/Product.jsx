import { lazy, Suspense } from 'react'
import PageHero from '../components/PageHero.jsx'
import OrbFallback from '../components/OrbFallback.jsx'
import ErrorBoundary from '../components/ErrorBoundary.jsx'
import FeatureRows from '../sections/FeatureRows.jsx'
import SpecSheet from '../sections/SpecSheet.jsx'
import MaterialsGrid from '../sections/MaterialsGrid.jsx'
import FinalCTA from '../sections/FinalCTA.jsx'
import { motion } from 'framer-motion'

const Orb3D = lazy(() => import('../components/Orb3D.jsx'))

export default function Product() {
  return (
    <>
      <PageHero
        eyebrow="Aurora — the instrument"
        title="One object, four systems, working while you don't."
        sub="Aurora replaces the lamp, the speaker, the fan, and the sleep tracker on your nightstand with a single instrument tuned to your night."
      >
        <motion.div
          className="product__orb"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.5, duration: 1 }}
        >
          <Suspense fallback={<OrbFallback />}>
            <ErrorBoundary fallback={<OrbFallback />}>
              <Orb3D />
            </ErrorBoundary>
          </Suspense>
        </motion.div>
      </PageHero>

      <FeatureRows />
      <SpecSheet />
      <MaterialsGrid />
      <FinalCTA />

      <style>{`
        .product__orb {
          height: clamp(260px, 34vw, 420px);
          margin-top: 48px;
          border-radius: 24px;
          overflow: hidden;
        }
      `}</style>
    </>
  )
}
