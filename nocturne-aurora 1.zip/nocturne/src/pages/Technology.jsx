import PageHero from '../components/PageHero.jsx'
import ScienceCurve from '../sections/ScienceCurve.jsx'
import Timeline from '../sections/Timeline.jsx'
import FinalCTA from '../sections/FinalCTA.jsx'

export default function Technology() {
  return (
    <>
      <PageHero
        eyebrow="Technology & story"
        title="We started with the science, not the shape."
        sub="Nocturne was founded by two chronobiologists who thought sleep technology had gotten the order backwards — chasing gadgets before understanding rhythm."
      />
      <ScienceCurve />
      <Timeline />
      <FinalCTA />
    </>
  )
}
