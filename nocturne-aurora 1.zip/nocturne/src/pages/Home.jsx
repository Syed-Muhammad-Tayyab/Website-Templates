import Hero from '../sections/Hero.jsx'
import TrustedBy from '../sections/TrustedBy.jsx'
import ProductShowcase from '../sections/ProductShowcase.jsx'
import StickyStory from '../sections/StickyStory.jsx'
import HorizontalScroll from '../sections/HorizontalScroll.jsx'
import Stats from '../sections/Stats.jsx'
import Testimonials from '../sections/Testimonials.jsx'
import FinalCTA from '../sections/FinalCTA.jsx'

export default function Home() {
  return (
    <>
      <Hero />
      <TrustedBy />
      <ProductShowcase />
      <StickyStory />
      <HorizontalScroll />
      <Stats />
      <Testimonials />
      <FinalCTA />
    </>
  )
}
