export const press = [
  'Kinfolk',
  'Wired',
  'Dwell',
  'Fast Company',
  'The Sleep Journal',
  'Monocle',
]

export const stats = [
  { value: 92, suffix: '%', label: 'of owners fall asleep faster within two weeks' },
  { value: 14, suffix: 'min', label: 'average reduction in time to sleep onset' },
  { value: 3, suffix: '', label: 'sensors reading light, sound, and breath' },
  { value: 40, suffix: 'hr', label: 'battery life on a single charge' },
]

export const phases = [
  {
    n: '01',
    title: 'Dusk',
    time: '9:00 PM',
    body: 'Aurora dims in step with your circadian curve, shifting from daylight white to a low amber that stops suppressing melatonin.',
  },
  {
    n: '02',
    title: 'Descent',
    time: '10:30 PM',
    body: 'A breath-paced soundscape slows from 16 to 6 cycles a minute, and the room drops half a degree to match your falling core temperature.',
  },
  {
    n: '03',
    title: 'Deep',
    time: '1:00 AM',
    body: 'Aurora goes quiet and dark, monitoring only. If it hears fragmented breathing, it adjusts airflow before you ever wake.',
  },
  {
    n: '04',
    title: 'Dawn',
    time: '6:40 AM',
    body: 'Light rises 40 minutes before your alarm, timed to your lightest sleep phase, so you wake between cycles instead of inside one.',
  },
]

export const features = [
  {
    title: 'Adaptive light engine',
    body: '256 individually addressable LEDs tuned across the full circadian spectrum, from 6500K daylight to 1800K ember.',
  },
  {
    title: 'Breath-paced audio',
    body: 'A five-driver array plays generative soundscapes that slow in tempo as your own breathing slows, measured in real time.',
  },
  {
    title: 'Silent airflow',
    body: 'A magnetic-levitation fan moves air at under 18 decibels, adjusting humidity and temperature through the night.',
  },
  {
    title: 'Presence sensing',
    body: 'Millimeter-wave radar reads breathing and movement without a wearable, camera, or microphone recording audio.',
  },
]

export const materials = [
  { title: 'Cast aluminium shell', body: 'Machined and hand-finished in a single piece, available in Graphite or Bone.' },
  { title: 'Blown glass diffuser', body: 'Each dome is mouth-blown, so light disperses without a single visible point source.' },
  { title: 'Woven base', body: 'A grip-cast silicone ring keeps Aurora silent and stationary on any nightstand.' },
  { title: 'Recycled internals', body: '61% recycled aluminium and zero disposable batteries across the unit.' },
]

export const testimonials = [
  {
    quote: "I stopped checking my phone at 2 a.m. because Aurora already knows what I need before I do.",
    name: 'Wren Okafor',
    role: 'Product Designer, Lagos',
  },
  {
    quote: "The light alone changed my evenings. I didn't expect a lamp to be the reason I sleep better.",
    name: 'Mateus Alencar',
    role: 'Architect, São Paulo',
  },
  {
    quote: "Waking up inside the light instead of to an alarm sound is the difference between groggy and ready.",
    name: 'Priya Nathan',
    role: 'ICU Nurse, Toronto',
  },
  {
    quote: 'Quiet, warm, and it never once tried to be a smart speaker. Just does one thing extremely well.',
    name: 'Owen Castellano',
    role: 'Writer, Lisbon',
  },
]

export const plans = [
  {
    name: 'Aurora',
    price: '$429',
    period: 'one time',
    tagline: 'The complete instrument, ready on your nightstand.',
    features: ['Adaptive light engine', 'Breath-paced soundscapes', 'Presence sensing', '2-year warranty'],
    featured: false,
  },
  {
    name: 'Aurora + Care',
    price: '$429',
    period: '+ $9/mo',
    tagline: 'Aurora, plus season-tuned programs and priority support.',
    features: ['Everything in Aurora', 'Quarterly sound & light programs', 'Sleep coach check-ins', 'Lifetime warranty'],
    featured: true,
  },
  {
    name: 'Studio',
    price: 'Custom',
    period: 'for teams',
    tagline: 'For boutique hotels and wellness studios furnishing multiple rooms.',
    features: ['Volume pricing', 'Fleet management app', 'White-glove install', 'Dedicated account lead'],
    featured: false,
  },
]

export const faqs = [
  {
    q: 'Does Aurora require an app to work?',
    a: 'No. Aurora works fully on-device out of the box. The companion app is optional, useful mainly for adjusting programs or viewing trends over time.',
  },
  {
    q: 'How does it sense sleep without a wearable?',
    a: 'A millimeter-wave radar module reads breathing rate and micro-movement from up to two metres away. It never records audio or video, and no data leaves the device unless you opt in to sync.',
  },
  {
    q: 'Will the light or sound wake a partner?',
    a: 'Light is directional and dims below the threshold of REM disruption; sound can be routed to a single side using the companion app if you sleep with a partner on a different schedule.',
  },
  {
    q: 'What is the warranty?',
    a: 'Two years standard, extended to lifetime for Aurora + Care members. Every unit is inspected by hand before it ships from Porto Novo.',
  },
  {
    q: 'When does it ship?',
    a: 'Reservations placed today ship within 6–8 weeks in the order received. A refundable deposit holds your place in the production run.',
  },
]

export const timeline = [
  { year: '2019', title: 'A sleep lab, not a startup', body: 'Founded by two chronobiologists frustrated that sleep tech meant wearables and apps, not instruments.' },
  { year: '2021', title: 'First prototype', body: 'Forty hand-built units tested in volunteer homes across three time zones for eighteen months.' },
  { year: '2023', title: 'The materials pass', body: 'Three redesigns later, the cast-aluminium shell and blown-glass diffuser reach production tolerance.' },
  { year: '2025', title: 'Aurora ships', body: 'The first production run leaves Porto Novo. Twelve thousand instruments now sit on twelve thousand nightstands.' },
]
