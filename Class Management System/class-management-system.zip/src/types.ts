export type UserRole = 'main_admin' | 'teacher' | 'student';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  status: 'active' | 'inactive';
  profileImage?: string;
  phone?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface UserPermission {
  id: string;
  userId: string;
  subjectId?: string | null; // specific subject scope or null for all
  section: 'announcements' | 'subjects' | 'notes' | 'attendance' | 'students' | 'admin';
  canRead: boolean;
  canCreate: boolean;
  canEdit: boolean;
  canDelete: boolean;
}

export interface Subject {
  id: string;
  name: string;
  code: string;
  thumbnail?: string;
  description: string;
  filePath?: string;
  department?: string;
  teacherIds: string[];
  createdAt: string;
}

export interface ClassRecord {
  id: string;
  subjectId: string;
  date: string;
  topicCovered: string;
  notes: string;
  teacherId: string;
  teacherName?: string;
  createdAt: string;
}

export interface Note {
  id: string;
  subjectId: string;
  subjectName?: string;
  title: string;
  content: string;
  filePath?: string;
  fileName?: string;
  fileSize?: string;
  fileMimeType?: string;
  createdBy: string;
  createdByName?: string;
  createdAt: string;
}

export interface Announcement {
  id: string;
  title: string;
  description: string;
  thumbnail?: string;
  imagePath?: string;
  filePath?: string;
  fileName?: string;
  fileMimeType?: string;
  postedBy: string;
  postedByName?: string;
  createdAt: string;
  priority?: 'normal' | 'important' | 'urgent';
}

export interface AttendanceRecord {
  id: string;
  studentId: string;
  studentName?: string;
  studentRollNo?: string;
  subjectId: string;
  subjectName?: string;
  date: string;
  status: 'present' | 'absent' | 'late' | 'excused';
  markedBy: string;
  markedByName?: string;
  createdAt: string;
}

export interface Student {
  id: string;
  userId?: string;
  name: string;
  rollNo: string;
  email: string;
  phone?: string;
  classId: string;
  section?: string;
  guardianName?: string;
  guardianPhone?: string;
  address?: string;
  bloodGroup?: string;
  dob?: string;
  profileImage?: string;
  enrolledSubjectIds: string[];
  createdAt: string;
}

export interface AuditLog {
  id: string;
  userId: string;
  userName: string;
  userRole: string;
  action: string;
  entityType: string;
  entityId?: string;
  details?: string;
  ipAddress?: string;
  timestamp: string;
}

export interface SystemSettings {
  schoolName: string;
  schoolTagline: string;
  academicTerm: string;
  allowStudentRegistration: boolean;
  theme: 'light' | 'dark' | 'system';
  customAnnouncementBanner?: string;
}

export interface SchemaTableDefinition {
  name: string;
  description: string;
  columns: {
    name: string;
    type: string;
    primaryKey?: boolean;
    foreignKey?: string;
    nullable?: boolean;
    description: string;
  }[];
  rowCount: number;
}
