import React, { useState } from 'react';
import {
  FileText,
  Plus,
  Search,
  Filter,
  Trash2,
  Edit2,
  Download,
  Eye,
  Calendar,
  X,
  Upload,
} from 'lucide-react';
import type { Note, Subject, User } from '../types.js';
import { api } from '../lib/api.js';

interface NotesViewProps {
  notes: Note[];
  subjects: Subject[];
  currentUser: User;
  onRefresh: () => void;
  onShowToast: (msg: string, type?: 'success' | 'error') => void;
}

export const NotesView: React.FC<NotesViewProps> = ({
  notes,
  subjects,
  currentUser,
  onRefresh,
  onShowToast,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSubjectId, setSelectedSubjectId] = useState<string>('all');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingNote, setEditingNote] = useState<Note | null>(null);
  const [readingNote, setReadingNote] = useState<Note | null>(null);

  // Form State
  const [subjectId, setSubjectId] = useState(subjects[0]?.id || '');
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [saving, setSaving] = useState(false);

  const canUpload = currentUser.role === 'main_admin' || currentUser.role === 'teacher';

  const filtered = notes.filter((n) => {
    const matchesSearch =
      n.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      n.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
      n.subjectName?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesSubject = selectedSubjectId === 'all' || n.subjectId === selectedSubjectId;
    return matchesSearch && matchesSubject;
  });

  const openCreateModal = () => {
    setEditingNote(null);
    setSubjectId(subjects[0]?.id || '');
    setTitle('');
    setContent('');
    setSelectedFile(null);
    setIsModalOpen(true);
  };

  const openEditModal = (note: Note) => {
    setEditingNote(note);
    setSubjectId(note.subjectId);
    setTitle(note.title);
    setContent(note.content);
    setSelectedFile(null);
    setIsModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !subjectId) {
      onShowToast('Please provide a title and select a subject.', 'error');
      return;
    }

    try {
      setSaving(true);
      let filePath = editingNote?.filePath || '';
      let fileName = editingNote?.fileName || '';
      let fileSize = editingNote?.fileSize || '';
      let fileMimeType = editingNote?.fileMimeType || '';

      if (selectedFile) {
        const uploadRes = await api.uploadFile(selectedFile);
        filePath = uploadRes.url;
        fileName = uploadRes.fileName;
        fileSize = uploadRes.fileSize;
        fileMimeType = uploadRes.mimeType;
      }

      if (editingNote) {
        await api.updateNote(editingNote.id, {
          subjectId,
          title,
          content,
          filePath: filePath || undefined,
          fileName: fileName || undefined,
          fileSize: fileSize || undefined,
          fileMimeType: fileMimeType || undefined,
        });
        onShowToast('Study note updated.');
      } else {
        await api.createNote({
          subjectId,
          title,
          content,
          filePath: filePath || undefined,
          fileName: fileName || undefined,
          fileSize: fileSize || undefined,
          fileMimeType: fileMimeType || undefined,
        });
        onShowToast('Study note uploaded successfully.');
      }

      setIsModalOpen(false);
      onRefresh();
    } catch (err: any) {
      onShowToast(err.message || 'Failed to save note.', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('Are you sure you want to delete this note?')) return;
    try {
      await api.deleteNote(id);
      onShowToast('Note deleted.');
      onRefresh();
    } catch (err: any) {
      onShowToast(err.message || 'Failed to delete note.', 'error');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <FileText className="w-5 h-5 text-indigo-600" />
            <span>Academic Notes & Materials</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Course lecture summaries, homework cheat-sheets, and supplementary reading files.
          </p>
        </div>

        {canUpload && (
          <button
            id="btn-upload-note"
            onClick={openCreateModal}
            className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-white shadow-xs transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Upload New Note</span>
          </button>
        )}
      </div>

      {/* Filter Bar */}
      <div className="flex flex-col sm:flex-row items-center gap-3 bg-white p-3 rounded-xl border border-slate-200">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search notes by title, topic, or keywords..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-1.5 text-xs rounded-lg border border-slate-200 focus:outline-hidden focus:border-indigo-500"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <Filter className="w-3.5 h-3.5 text-slate-400" />
          <select
            value={selectedSubjectId}
            onChange={(e) => setSelectedSubjectId(e.target.value)}
            className="text-xs py-1.5 px-3 rounded-lg border border-slate-200 bg-white focus:outline-hidden focus:border-indigo-500 text-slate-700"
          >
            <option value="all">All Subjects</option>
            {subjects.map((s) => (
              <option key={s.id} value={s.id}>
                {s.code}: {s.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Notes Grid */}
      {filtered.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center">
          <FileText className="w-10 h-10 text-slate-300 mx-auto mb-3" />
          <h3 className="text-sm font-bold text-slate-800">No Notes Found</h3>
          <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
            {canUpload
              ? 'Click "Upload New Note" to publish course materials.'
              : 'No notes available for this subject or filter.'}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((note) => {
            const canModify =
              currentUser.role === 'main_admin' || note.createdBy === currentUser.id;

            return (
              <div
                key={note.id}
                className="bg-white rounded-2xl border border-slate-200 hover:border-slate-300 p-5 flex flex-col justify-between transition-all hover:shadow-xs"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold tracking-wide uppercase bg-indigo-50 text-indigo-700 border border-indigo-100">
                      {note.subjectName || 'Course Note'}
                    </span>

                    {canModify && (
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => openEditModal(note)}
                          className="p-1 text-slate-400 hover:text-indigo-600 rounded transition-colors"
                          title="Edit note"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDelete(note.id)}
                          className="p-1 text-slate-400 hover:text-rose-600 rounded transition-colors"
                          title="Delete note"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    )}
                  </div>

                  <h3 className="text-xs font-bold text-slate-900 leading-snug">
                    {note.title}
                  </h3>
                  <p className="text-xs text-slate-600 mt-2 line-clamp-3 leading-relaxed whitespace-pre-line">
                    {note.content}
                  </p>
                </div>

                {/* Footer with Attachment & Author */}
                <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                  <div>
                    <p className="font-semibold text-slate-700">
                      {note.createdByName || 'Faculty'}
                    </p>
                    <span className="text-[10px] text-slate-400">
                      {new Date(note.createdAt).toLocaleDateString()}
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => setReadingNote(note)}
                      className="inline-flex items-center gap-1 px-2 py-1 rounded-md text-[11px] font-medium bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors"
                    >
                      <Eye className="w-3 h-3" />
                      <span>Read</span>
                    </button>
                    {note.filePath && (
                      <a
                        href={note.filePath}
                        download={note.fileName || 'NoteFile'}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center gap-1 px-2 py-1 rounded-md text-[11px] font-medium bg-indigo-50 hover:bg-indigo-100 text-indigo-700 transition-colors"
                      >
                        <Download className="w-3 h-3" />
                        <span>File</span>
                      </a>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Upload/Edit Note Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 w-full max-w-lg overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900">
                {editingNote ? 'Edit Study Note' : 'Upload Course Materials & Notes'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-md"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-5 space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Target Course / Subject *
                </label>
                <select
                  required
                  value={subjectId}
                  onChange={(e) => setSubjectId(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 bg-white focus:outline-hidden focus:border-indigo-500"
                >
                  {subjects.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.code}: {s.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Note Title *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Chapter 4: Matrix Transformations & Eigenvectors"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Note Content & Formulas (Markdown Supported)
                </label>
                <textarea
                  rows={6}
                  placeholder="Write clear lecture notes, key theorems, derivations, and study highlights..."
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:border-indigo-500 font-mono text-xs"
                ></textarea>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Attach Supplementary File (PDF, DOCX, XLSX)
                </label>
                <div className="border border-dashed border-slate-200 rounded-lg p-3 text-center hover:bg-slate-50 transition-colors">
                  <input
                    type="file"
                    id="note-file-input"
                    className="hidden"
                    onChange={(e) => {
                      if (e.target.files?.[0]) setSelectedFile(e.target.files[0]);
                    }}
                  />
                  <label htmlFor="note-file-input" className="cursor-pointer flex flex-col items-center">
                    <Upload className="w-5 h-5 text-slate-400 mb-1" />
                    <span className="text-slate-600 font-medium">
                      {selectedFile ? selectedFile.name : 'Click to select or drag document'}
                    </span>
                  </label>
                </div>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-3.5 py-2 rounded-lg font-medium text-slate-600 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="px-4 py-2 rounded-lg font-semibold bg-slate-900 hover:bg-slate-800 text-white transition-colors"
                >
                  {saving ? 'Saving...' : editingNote ? 'Save Note' : 'Upload Note'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Note Reader Modal */}
      {readingNote && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 w-full max-w-2xl max-h-[85vh] flex flex-col overflow-hidden">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between">
              <div>
                <span className="text-[10px] font-bold text-indigo-600 uppercase">
                  {readingNote.subjectName}
                </span>
                <h3 className="text-sm font-bold text-slate-900">{readingNote.title}</h3>
              </div>
              <button
                onClick={() => setReadingNote(null)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-md"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-6 overflow-y-auto flex-1 text-xs whitespace-pre-line leading-relaxed text-slate-700">
              {readingNote.content}
            </div>

            <div className="p-4 border-t border-slate-100 flex items-center justify-between bg-slate-50 text-xs">
              <span className="text-slate-500">
                Uploaded by <strong className="text-slate-700">{readingNote.createdByName || 'Faculty'}</strong>
              </span>

              <div className="flex items-center gap-2">
                {readingNote.filePath && (
                  <a
                    href={readingNote.filePath}
                    download={readingNote.fileName}
                    target="_blank"
                    rel="noreferrer"
                    className="px-3 py-1.5 rounded-lg font-semibold bg-indigo-600 hover:bg-indigo-500 text-white inline-flex items-center gap-1.5"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download Attachment</span>
                  </a>
                )}
                <button
                  onClick={() => setReadingNote(null)}
                  className="px-3.5 py-1.5 rounded-lg font-medium text-slate-700 hover:bg-slate-200/70"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
