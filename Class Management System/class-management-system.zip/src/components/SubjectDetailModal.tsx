import React, { useState, useEffect } from 'react';
import {
  X,
  BookOpen,
  Users,
  FileText,
  Calendar,
  Plus,
  Trash2,
  Download,
  Eye,
  CheckCircle2,
} from 'lucide-react';
import type { Subject, User, Note, ClassRecord } from '../types.js';
import { api } from '../lib/api.js';

interface SubjectDetailModalProps {
  subject: Subject;
  currentUser: User;
  onClose: () => void;
  onShowToast: (msg: string, type?: 'success' | 'error') => void;
}

export const SubjectDetailModal: React.FC<SubjectDetailModalProps> = ({
  subject,
  currentUser,
  onClose,
  onShowToast,
}) => {
  const [activeTab, setActiveTab] = useState<'notes' | 'teachers' | 'records'>('notes');
  const [subjectData, setSubjectData] = useState<{
    teachers: User[];
    notes: Note[];
    classRecords: ClassRecord[];
  } | null>(null);
  const [loading, setLoading] = useState(true);

  // New Class Record Form State
  const [isAddingRecord, setIsAddingRecord] = useState(false);
  const [recordDate, setRecordDate] = useState(new Date().toISOString().split('T')[0]);
  const [topicCovered, setTopicCovered] = useState('');
  const [recordNotes, setRecordNotes] = useState('');
  const [savingRecord, setSavingRecord] = useState(false);

  // Selected note for preview
  const [selectedNote, setSelectedNote] = useState<Note | null>(null);

  const isTeacherForSubject = subject.teacherIds?.includes(currentUser.id);
  const canEditAcademicRecord = currentUser.role === 'main_admin' || isTeacherForSubject;

  const loadData = async () => {
    try {
      setLoading(true);
      const res = await api.getSubject(subject.id);
      setSubjectData({
        teachers: res.teachers || [],
        notes: res.notes || [],
        classRecords: res.classRecords || [],
      });
    } catch (err: any) {
      onShowToast(err.message || 'Error loading subject details.', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [subject.id]);

  const handleAddClassRecord = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!topicCovered.trim()) {
      onShowToast('Please enter the topic covered.', 'error');
      return;
    }

    try {
      setSavingRecord(true);
      await api.createClassRecord(subject.id, {
        date: recordDate,
        topicCovered,
        notes: recordNotes,
      });
      onShowToast('Class academic session recorded successfully.');
      setIsAddingRecord(false);
      setTopicCovered('');
      setRecordNotes('');
      loadData();
    } catch (err: any) {
      onShowToast(err.message || 'Failed to record class session.', 'error');
    } finally {
      setSavingRecord(false);
    }
  };

  const handleDeleteRecord = async (id: string) => {
    if (!window.confirm('Delete this academic class log?')) return;
    try {
      await api.deleteClassRecord(id);
      onShowToast('Class record removed.');
      loadData();
    } catch (err: any) {
      onShowToast(err.message || 'Failed to delete record.', 'error');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Modal Header */}
        <div className="p-6 border-b border-slate-100 flex items-start justify-between bg-slate-50/50">
          <div className="flex items-start gap-4">
            {subject.thumbnail ? (
              <img
                src={subject.thumbnail}
                alt={subject.name}
                className="w-16 h-16 rounded-xl object-cover border border-slate-200 shrink-0"
              />
            ) : (
              <div className="w-16 h-16 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold text-xl shrink-0">
                {subject.code.slice(0, 3)}
              </div>
            )}
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="px-2 py-0.5 rounded text-[11px] font-bold tracking-wide uppercase bg-indigo-100 text-indigo-700">
                  {subject.code}
                </span>
                <span className="text-xs text-slate-500 font-medium">
                  {subject.department || 'Academic Department'}
                </span>
              </div>
              <h2 className="text-lg font-bold text-slate-900 leading-tight">
                {subject.name}
              </h2>
              <p className="text-xs text-slate-600 mt-1 max-w-xl line-clamp-2">
                {subject.description}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 px-6 border-b border-slate-200 bg-white">
          <button
            onClick={() => setActiveTab('notes')}
            className={`py-3 px-4 text-xs font-semibold border-b-2 transition-colors flex items-center gap-2 ${
              activeTab === 'notes'
                ? 'border-indigo-600 text-indigo-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Study Notes ({subjectData?.notes.length || 0})</span>
          </button>

          <button
            onClick={() => setActiveTab('teachers')}
            className={`py-3 px-4 text-xs font-semibold border-b-2 transition-colors flex items-center gap-2 ${
              activeTab === 'teachers'
                ? 'border-indigo-600 text-indigo-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>Faculty Instructors ({subjectData?.teachers.length || 0})</span>
          </button>

          <button
            onClick={() => setActiveTab('records')}
            className={`py-3 px-4 text-xs font-semibold border-b-2 transition-colors flex items-center gap-2 ${
              activeTab === 'records'
                ? 'border-indigo-600 text-indigo-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Calendar className="w-3.5 h-3.5" />
            <span>Class Academic Record ({subjectData?.classRecords.length || 0})</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto flex-1 text-xs">
          {loading ? (
            <div className="py-16 text-center text-slate-400">Loading course curriculum...</div>
          ) : (
            <>
              {/* TAB 1: NOTES */}
              {activeTab === 'notes' && (
                <div className="space-y-4">
                  {subjectData?.notes.length === 0 ? (
                    <div className="p-8 text-center border border-dashed border-slate-200 rounded-xl">
                      <FileText className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                      <p className="text-slate-600 font-medium">No notes uploaded for this course yet.</p>
                      <p className="text-slate-400 mt-0.5">Faculty members can upload lectures under the Notes tab.</p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {subjectData?.notes.map((note) => (
                        <div
                          key={note.id}
                          className="p-4 rounded-xl border border-slate-200 bg-white hover:border-slate-300 transition-all flex flex-col justify-between"
                        >
                          <div>
                            <div className="flex items-center justify-between mb-1.5">
                              <span className="text-[11px] text-slate-400">
                                {new Date(note.createdAt).toLocaleDateString()}
                              </span>
                              {note.fileName && (
                                <span className="text-[10px] bg-slate-100 text-slate-700 font-semibold px-2 py-0.5 rounded">
                                  {note.fileSize || 'Attachment'}
                                </span>
                              )}
                            </div>
                            <h4 className="font-bold text-slate-900 text-xs">{note.title}</h4>
                            <p className="text-slate-600 mt-1 line-clamp-2 leading-relaxed">
                              {note.content}
                            </p>
                          </div>

                          <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between">
                            <span className="text-[10px] text-slate-400">
                              By: {note.createdByName || 'Instructor'}
                            </span>
                            <div className="flex items-center gap-2">
                              <button
                                onClick={() => setSelectedNote(note)}
                                className="inline-flex items-center gap-1 text-[11px] font-semibold text-indigo-600 hover:underline"
                              >
                                <Eye className="w-3 h-3" />
                                <span>Read</span>
                              </button>
                              {note.filePath && (
                                <a
                                  href={note.filePath}
                                  download={note.fileName}
                                  target="_blank"
                                  rel="noreferrer"
                                  className="inline-flex items-center gap-1 text-[11px] font-semibold text-slate-700 hover:text-slate-900"
                                >
                                  <Download className="w-3 h-3" />
                                  <span>Download</span>
                                </a>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* TAB 2: TEACHERS */}
              {activeTab === 'teachers' && (
                <div className="space-y-4">
                  {subjectData?.teachers.length === 0 ? (
                    <div className="p-8 text-center border border-dashed border-slate-200 rounded-xl text-slate-500">
                      No instructors assigned to this subject yet.
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {subjectData?.teachers.map((teacher) => (
                        <div
                          key={teacher.id}
                          className="p-4 rounded-xl border border-slate-200 bg-white flex items-center gap-3.5 shadow-2xs"
                        >
                          {teacher.profileImage ? (
                            <img
                              src={teacher.profileImage}
                              alt={teacher.name}
                              referrerPolicy="no-referrer"
                              className="w-12 h-12 rounded-full object-cover border border-slate-200"
                            />
                          ) : (
                            <div className="w-12 h-12 rounded-full bg-slate-800 text-white font-bold flex items-center justify-center text-sm">
                              {teacher.name.charAt(0)}
                            </div>
                          )}
                          <div>
                            <h4 className="font-bold text-slate-900 text-xs">{teacher.name}</h4>
                            <p className="text-[11px] text-slate-500 mt-0.5">{teacher.email}</p>
                            {teacher.phone && (
                              <p className="text-[11px] text-slate-400 mt-0.5">{teacher.phone}</p>
                            )}
                            <span className="inline-block mt-1 px-2 py-0.5 rounded text-[10px] font-semibold bg-indigo-50 text-indigo-700">
                              Assigned Faculty
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* TAB 3: CLASS ACADEMIC RECORDS (What was taught and when) */}
              {activeTab === 'records' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-bold text-slate-900 text-xs">
                        Class & Attendance Academic Ledger
                      </h4>
                      <p className="text-[11px] text-slate-500">
                        Historical log of lesson topics delivered and instructional notes.
                      </p>
                    </div>

                    {canEditAcademicRecord && (
                      <button
                        onClick={() => setIsAddingRecord(!isAddingRecord)}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-white shadow-xs transition-colors"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Log Session</span>
                      </button>
                    )}
                  </div>

                  {/* Add Class Record Form */}
                  {isAddingRecord && (
                    <form
                      onSubmit={handleAddClassRecord}
                      className="p-4 rounded-xl border border-indigo-200 bg-indigo-50/40 space-y-3"
                    >
                      <h5 className="font-bold text-slate-900 text-xs">
                        Record New Lecture / Class Session
                      </h5>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label className="block font-semibold text-slate-700 mb-1">
                            Session Date *
                          </label>
                          <input
                            type="date"
                            required
                            value={recordDate}
                            onChange={(e) => setRecordDate(e.target.value)}
                            className="w-full px-3 py-1.5 rounded-lg border border-slate-200 bg-white focus:outline-hidden focus:border-indigo-500"
                          />
                        </div>
                        <div>
                          <label className="block font-semibold text-slate-700 mb-1">
                            Topic Covered *
                          </label>
                          <input
                            type="text"
                            required
                            placeholder="e.g. Stokes Theorem & Surface Integrals"
                            value={topicCovered}
                            onChange={(e) => setTopicCovered(e.target.value)}
                            className="w-full px-3 py-1.5 rounded-lg border border-slate-200 bg-white focus:outline-hidden focus:border-indigo-500"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block font-semibold text-slate-700 mb-1">
                          Lecture Notes & Homework Assigned
                        </label>
                        <textarea
                          rows={3}
                          placeholder="Summarize key theorems discussed, derivations, homework problem sets..."
                          value={recordNotes}
                          onChange={(e) => setRecordNotes(e.target.value)}
                          className="w-full px-3 py-1.5 rounded-lg border border-slate-200 bg-white focus:outline-hidden focus:border-indigo-500"
                        ></textarea>
                      </div>

                      <div className="flex items-center justify-end gap-2 pt-1">
                        <button
                          type="button"
                          onClick={() => setIsAddingRecord(false)}
                          className="px-3 py-1.5 rounded-lg font-medium text-slate-600 hover:bg-slate-200/60"
                        >
                          Cancel
                        </button>
                        <button
                          type="submit"
                          disabled={savingRecord}
                          className="px-3.5 py-1.5 rounded-lg font-semibold bg-indigo-600 hover:bg-indigo-500 text-white transition-colors"
                        >
                          {savingRecord ? 'Saving...' : 'Save Academic Record'}
                        </button>
                      </div>
                    </form>
                  )}

                  {/* List of records */}
                  {subjectData?.classRecords.length === 0 ? (
                    <div className="p-8 text-center border border-dashed border-slate-200 rounded-xl text-slate-500">
                      No class sessions recorded for this course yet.
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {subjectData?.classRecords.map((rec) => (
                        <div
                          key={rec.id}
                          className="p-4 rounded-xl border border-slate-200 bg-white flex items-start justify-between gap-4 hover:border-slate-300 transition-all"
                        >
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-slate-100 text-slate-700">
                                {rec.date}
                              </span>
                              <span className="text-[11px] text-slate-400">
                                Instructor: {rec.teacherName || 'Faculty'}
                              </span>
                            </div>
                            <h5 className="font-bold text-slate-900 text-xs mt-1">
                              {rec.topicCovered}
                            </h5>
                            {rec.notes && (
                              <p className="text-slate-600 leading-relaxed mt-1 text-xs">
                                {rec.notes}
                              </p>
                            )}
                          </div>

                          {canEditAcademicRecord && (
                            <button
                              onClick={() => handleDeleteRecord(rec.id)}
                              className="text-slate-400 hover:text-rose-600 p-1 rounded transition-colors"
                              title="Delete record"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </>
          )}
        </div>

        {/* Note Reader Modal */}
        {selectedNote && (
          <div className="fixed inset-0 z-60 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-xl max-h-[85vh] flex flex-col overflow-hidden">
              <div className="p-4 border-b border-slate-100 flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-bold text-indigo-600 uppercase">
                    {subject.code} Note
                  </span>
                  <h3 className="text-sm font-bold text-slate-900">{selectedNote.title}</h3>
                </div>
                <button
                  onClick={() => setSelectedNote(null)}
                  className="text-slate-400 hover:text-slate-600 p-1 rounded-md"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              <div className="p-6 overflow-y-auto flex-1 text-xs whitespace-pre-line leading-relaxed text-slate-700">
                {selectedNote.content}
              </div>
              <div className="p-4 border-t border-slate-100 flex items-center justify-between bg-slate-50">
                <span className="text-[11px] text-slate-400">
                  Uploaded by {selectedNote.createdByName || 'Instructor'}
                </span>
                <button
                  onClick={() => setSelectedNote(null)}
                  className="px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-slate-900 text-white"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
