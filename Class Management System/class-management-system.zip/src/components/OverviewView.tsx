import React from 'react';
import {
  Users,
  BookOpen,
  FileText,
  CalendarCheck,
  Megaphone,
  Database,
  ArrowUpRight,
  ShieldCheck,
  Clock,
  Sparkles,
  UploadCloud,
} from 'lucide-react';
import type { User, Subject, Announcement, Note, AttendanceRecord, Student } from '../types.js';

interface OverviewViewProps {
  currentUser: User;
  subjects: Subject[];
  announcements: Announcement[];
  notes: Note[];
  students: Student[];
  attendanceRecords: AttendanceRecord[];
  onNavigate: (tab: any) => void;
  onOpenIngest: () => void;
  onSeedDemo: () => void;
}

export const OverviewView: React.FC<OverviewViewProps> = ({
  currentUser,
  subjects,
  announcements,
  notes,
  students,
  attendanceRecords,
  onNavigate,
  onOpenIngest,
  onSeedDemo,
}) => {
  const isMainAdmin = currentUser.role === 'main_admin';
  const isTeacher = currentUser.role === 'teacher';
  const isStudent = currentUser.role === 'student';

  // Calculate attendance rate
  const totalAtt = attendanceRecords.length;
  const presentCount = attendanceRecords.filter((a) => a.status === 'present' || a.status === 'late').length;
  const attendanceRate = totalAtt > 0 ? Math.round((presentCount / totalAtt) * 100) : 100;

  const isSchemaEmpty = subjects.length === 0 && students.length === 0 && announcements.length === 0;

  return (
    <div className="space-y-6">
      {/* Empty Database Schema Status Banner */}
      {isSchemaEmpty && (
        <div className="p-5 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-start gap-3.5">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-700 flex items-center justify-center shrink-0">
              <Database className="w-5 h-5 text-amber-600" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                Database Schema Ready & Empty
              </h3>
              <p className="text-xs text-slate-600 mt-0.5 leading-relaxed max-w-2xl">
                The full 11-table relational database schema has been verified and initialized. Tables are ready for data ingestion, bulk uploads, and student profile enrollment.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2.5 w-full md:w-auto">
            {isMainAdmin && (
              <>
                <button
                  id="btn-overview-ingest"
                  onClick={onOpenIngest}
                  className="flex-1 md:flex-initial px-3.5 py-2 rounded-xl text-xs font-semibold bg-white border border-slate-300 hover:bg-slate-50 text-slate-800 shadow-2xs transition-colors flex items-center justify-center gap-1.5"
                >
                  <UploadCloud className="w-3.5 h-3.5 text-slate-600" />
                  <span>Ingest CSV / JSON</span>
                </button>
                <button
                  id="btn-overview-seed"
                  onClick={onSeedDemo}
                  className="flex-1 md:flex-initial px-3.5 py-2 rounded-xl text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-white shadow-xs transition-colors flex items-center justify-center gap-1.5"
                >
                  <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Load Demo Pack</span>
                </button>
              </>
            )}
          </div>
        </div>
      )}

      {/* Welcome Banner */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 text-white shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              {currentUser.role.replace('_', ' ')}
            </span>
            <span className="text-xs text-slate-400">
              Session active &middot; Server authorized
            </span>
          </div>
          <h2 className="text-xl font-bold tracking-tight">
            Welcome back, {currentUser.name}
          </h2>
          <p className="text-xs text-slate-300 mt-1 max-w-xl leading-relaxed">
            {isMainAdmin
              ? 'Central Control Center: Manage student profiles, faculty assignments, granular permissions, and academic records.'
              : isTeacher
              ? 'Academic Faculty Portal: Review your assigned courses, record what was taught in class, upload study notes, and track attendance.'
              : 'Student Learning Workspace: Access course notes, academic syllabus, announcements, and track your attendance percentages.'}
          </p>
        </div>

        <div className="flex items-center gap-2">
          {isMainAdmin && (
            <button
              onClick={() => onNavigate('admin')}
              className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-indigo-600 hover:bg-indigo-500 text-white transition-all shadow-xs flex items-center gap-1.5"
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Admin Center</span>
            </button>
          )}
          <button
            onClick={() => onNavigate('attendance')}
            className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-white/10 hover:bg-white/15 text-white border border-white/10 transition-all flex items-center gap-1.5"
          >
            <CalendarCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Attendance</span>
          </button>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl bg-white border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">Active Students</span>
            <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-bold text-slate-900 mt-2">{students.length}</p>
          <div className="flex items-center justify-between text-[11px] text-slate-500 mt-1">
            <span>Enrolled in directory</span>
            <button
              onClick={() => onNavigate('students')}
              className="text-indigo-600 hover:underline inline-flex items-center gap-0.5 font-medium"
            >
              View <ArrowUpRight className="w-3 h-3" />
            </button>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-white border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">Courses & Subjects</span>
            <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <BookOpen className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-bold text-slate-900 mt-2">{subjects.length}</p>
          <div className="flex items-center justify-between text-[11px] text-slate-500 mt-1">
            <span>Active syllabus units</span>
            <button
              onClick={() => onNavigate('subjects')}
              className="text-indigo-600 hover:underline inline-flex items-center gap-0.5 font-medium"
            >
              View <ArrowUpRight className="w-3 h-3" />
            </button>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-white border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">Notes & Resources</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <FileText className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-bold text-slate-900 mt-2">{notes.length}</p>
          <div className="flex items-center justify-between text-[11px] text-slate-500 mt-1">
            <span>Study materials</span>
            <button
              onClick={() => onNavigate('notes')}
              className="text-indigo-600 hover:underline inline-flex items-center gap-0.5 font-medium"
            >
              View <ArrowUpRight className="w-3 h-3" />
            </button>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-white border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">Attendance Rate</span>
            <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
              <CalendarCheck className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-bold text-slate-900 mt-2">{attendanceRate}%</p>
          <div className="flex items-center justify-between text-[11px] text-slate-500 mt-1">
            <span>{totalAtt} sessions recorded</span>
            <button
              onClick={() => onNavigate('attendance')}
              className="text-indigo-600 hover:underline inline-flex items-center gap-0.5 font-medium"
            >
              Stats <ArrowUpRight className="w-3 h-3" />
            </button>
          </div>
        </div>
      </div>

      {/* Two Column Section: Recent Announcements & Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Announcements */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 p-5 shadow-2xs">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Megaphone className="w-4 h-4 text-indigo-600" />
              <h3 className="text-sm font-bold text-slate-900">Recent Announcements</h3>
            </div>
            <button
              onClick={() => onNavigate('announcements')}
              className="text-xs font-semibold text-indigo-600 hover:underline flex items-center gap-1"
            >
              View All <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {announcements.length === 0 ? (
            <div className="p-8 text-center border border-dashed border-slate-200 rounded-xl">
              <Megaphone className="w-8 h-8 text-slate-300 mx-auto mb-2" />
              <p className="text-xs font-medium text-slate-600">No announcements posted yet.</p>
              <p className="text-[11px] text-slate-400 mt-0.5">
                {isMainAdmin ? 'Click announcements to publish the first notice.' : 'Check back later for updates.'}
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {announcements.slice(0, 3).map((ann) => (
                <div
                  key={ann.id}
                  className="p-3.5 rounded-xl bg-slate-50/70 hover:bg-slate-50 border border-slate-200/80 transition-all flex items-start justify-between gap-4"
                >
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      {ann.priority === 'urgent' && (
                        <span className="px-1.5 py-0.5 rounded text-[10px] font-bold uppercase bg-rose-100 text-rose-700">
                          Urgent
                        </span>
                      )}
                      {ann.priority === 'important' && (
                        <span className="px-1.5 py-0.5 rounded text-[10px] font-bold uppercase bg-amber-100 text-amber-800">
                          Important
                        </span>
                      )}
                      <span className="text-[11px] text-slate-400 flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {new Date(ann.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                    <h4 className="text-xs font-bold text-slate-900 leading-snug">
                      {ann.title}
                    </h4>
                    <p className="text-xs text-slate-600 mt-1 line-clamp-2 leading-relaxed">
                      {ann.description}
                    </p>
                  </div>
                  {ann.fileName && (
                    <span className="shrink-0 text-[10px] font-semibold bg-white border border-slate-200 text-slate-700 px-2 py-1 rounded-md">
                      Attachment
                    </span>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Database & System Architecture Box */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-2xs space-y-4">
          <div className="flex items-center gap-2">
            <Database className="w-4 h-4 text-emerald-600" />
            <h3 className="text-sm font-bold text-slate-900">Database Engine</h3>
          </div>

          <div className="space-y-2.5 text-xs">
            <div className="flex items-center justify-between py-1.5 border-b border-slate-100">
              <span className="text-slate-500">Architecture</span>
              <span className="font-semibold text-slate-800">11 Relational Tables</span>
            </div>
            <div className="flex items-center justify-between py-1.5 border-b border-slate-100">
              <span className="text-slate-500">Security / Hashing</span>
              <span className="font-semibold text-slate-800">Bcrypt Salted + Hex Sessions</span>
            </div>
            <div className="flex items-center justify-between py-1.5 border-b border-slate-100">
              <span className="text-slate-500">Access Control</span>
              <span className="font-semibold text-indigo-600">RBAC + Granular ACL</span>
            </div>
            <div className="flex items-center justify-between py-1.5 border-b border-slate-100">
              <span className="text-slate-500">Audit Trail</span>
              <span className="font-semibold text-emerald-600">Active Logging</span>
            </div>
          </div>

          <div className="pt-2">
            {isMainAdmin ? (
              <button
                onClick={() => onNavigate('database')}
                className="w-full py-2.5 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold transition-colors flex items-center justify-center gap-2 shadow-xs"
              >
                <Database className="w-3.5 h-3.5 text-emerald-400" />
                <span>Open Schema & Ingestion Center</span>
              </button>
            ) : (
              <div className="p-3 bg-slate-50 rounded-xl text-center text-xs text-slate-500">
                Connected to secure institutional database
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
