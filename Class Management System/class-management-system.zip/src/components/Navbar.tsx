import React, { useState } from 'react';
import {
  GraduationCap,
  Shield,
  BookOpen,
  UserCheck,
  LogOut,
  ChevronDown,
  Database,
  Lock,
  User as UserIcon,
} from 'lucide-react';
import type { User } from '../types.js';

interface NavbarProps {
  currentUser: User | null;
  onLogout: () => void;
  onQuickSwitch: (email: string) => void;
  onOpenSettings: () => void;
  onOpenDatabase: () => void;
  schoolName: string;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentUser,
  onLogout,
  onQuickSwitch,
  onOpenSettings,
  onOpenDatabase,
  schoolName,
}) => {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [switchOpen, setSwitchOpen] = useState(false);

  const getRoleBadge = () => {
    if (!currentUser) return null;
    switch (currentUser.role) {
      case 'main_admin':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-500/15 text-amber-600 border border-amber-500/30">
            <Shield className="w-3.5 h-3.5 text-amber-600" />
            Main Admin
          </span>
        );
      case 'teacher':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-indigo-500/15 text-indigo-600 border border-indigo-500/30">
            <BookOpen className="w-3.5 h-3.5 text-indigo-600" />
            Faculty / Teacher
          </span>
        );
      case 'student':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-500/15 text-emerald-600 border border-emerald-500/30">
            <UserCheck className="w-3.5 h-3.5 text-emerald-600" />
            Enrolled Student
          </span>
        );
    }
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-200 bg-white/95 backdrop-blur shadow-xs">
      <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Brand & Institution Info */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-slate-900 text-white flex items-center justify-center shadow-xs">
            <GraduationCap className="w-5 h-5 text-indigo-400" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base font-bold text-slate-900 leading-none tracking-tight">
                Class Management System
              </h1>
              <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded text-[10px] font-medium bg-slate-100 text-slate-600 border border-slate-200">
                v2.6 Enterprise
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5 truncate max-w-xs sm:max-w-sm">
              {schoolName}
            </p>
          </div>
        </div>

        {/* Action Controls & Role Switcher */}
        <div className="flex items-center gap-2 sm:gap-4">
          {currentUser && (
            <>
              {/* Quick Role Tester / Switcher */}
              <div className="relative">
                <button
                  id="btn-quick-role-switch"
                  onClick={() => {
                    setSwitchOpen(!switchOpen);
                    setDropdownOpen(false);
                  }}
                  className="hidden md:flex items-center gap-1.5 text-xs font-medium text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200/80 px-2.5 py-1.5 rounded-lg border border-slate-200 transition-colors"
                  title="Switch between test accounts to verify role permissions"
                >
                  <Lock className="w-3.5 h-3.5 text-slate-500" />
                  <span>Role Switcher</span>
                  <ChevronDown className="w-3 h-3 text-slate-500" />
                </button>

                {switchOpen && (
                  <div className="absolute right-0 mt-2 w-72 bg-white rounded-xl shadow-xl border border-slate-200 p-2 z-50 text-xs animate-in fade-in zoom-in-95 duration-150">
                    <div className="px-3 py-1.5 border-b border-slate-100 mb-1">
                      <p className="font-semibold text-slate-800">Quick Test Accounts</p>
                      <p className="text-[11px] text-slate-500">Test role-based access & permissions</p>
                    </div>
                    <button
                      onClick={() => {
                        onQuickSwitch('admin@school.edu');
                        setSwitchOpen(false);
                      }}
                      className="w-full text-left px-3 py-2 rounded-lg hover:bg-amber-50 hover:text-amber-900 flex items-center justify-between transition-colors"
                    >
                      <div>
                        <p className="font-semibold text-slate-900">Main Admin</p>
                        <p className="text-[11px] text-slate-500">Full control & permissions</p>
                      </div>
                      <span className="text-[10px] bg-amber-100 text-amber-800 font-bold px-1.5 py-0.5 rounded">
                        Full Access
                      </span>
                    </button>
                    <button
                      onClick={() => {
                        onQuickSwitch('sarah.jenkins@school.edu');
                        setSwitchOpen(false);
                      }}
                      className="w-full text-left px-3 py-2 rounded-lg hover:bg-indigo-50 hover:text-indigo-900 flex items-center justify-between transition-colors"
                    >
                      <div>
                        <p className="font-semibold text-slate-900">Teacher: Dr. Jenkins</p>
                        <p className="text-[11px] text-slate-500">Mathematics only</p>
                      </div>
                      <span className="text-[10px] bg-indigo-100 text-indigo-800 font-bold px-1.5 py-0.5 rounded">
                        Scoped
                      </span>
                    </button>
                    <button
                      onClick={() => {
                        onQuickSwitch('marcus.vance@school.edu');
                        setSwitchOpen(false);
                      }}
                      className="w-full text-left px-3 py-2 rounded-lg hover:bg-indigo-50 hover:text-indigo-900 flex items-center justify-between transition-colors"
                    >
                      <div>
                        <p className="font-semibold text-slate-900">Teacher: Prof. Vance</p>
                        <p className="text-[11px] text-slate-500">Physics only</p>
                      </div>
                      <span className="text-[10px] bg-indigo-100 text-indigo-800 font-bold px-1.5 py-0.5 rounded">
                        Scoped
                      </span>
                    </button>
                    <button
                      onClick={() => {
                        onQuickSwitch('alex.rivera@student.edu');
                        setSwitchOpen(false);
                      }}
                      className="w-full text-left px-3 py-2 rounded-lg hover:bg-emerald-50 hover:text-emerald-900 flex items-center justify-between transition-colors"
                    >
                      <div>
                        <p className="font-semibold text-slate-900">Student: Alex Rivera</p>
                        <p className="text-[11px] text-slate-500">View notes & attendance</p>
                      </div>
                      <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.5 rounded">
                        Student
                      </span>
                    </button>
                  </div>
                )}
              </div>

              {/* Database Schema Quick Button for Admins */}
              {currentUser.role === 'main_admin' && (
                <button
                  id="btn-schema-quick"
                  onClick={onOpenDatabase}
                  className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium text-emerald-700 bg-emerald-50 border border-emerald-200 hover:bg-emerald-100 transition-colors"
                  title="View Database Schema & Ingestion Center"
                >
                  <Database className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Schema & Ingestion</span>
                </button>
              )}

              {/* Current Role Badge */}
              <div className="hidden sm:block">{getRoleBadge()}</div>

              {/* User Profile Pill & Dropdown */}
              <div className="relative">
                <button
                  id="btn-user-profile-menu"
                  onClick={() => {
                    setDropdownOpen(!dropdownOpen);
                    setSwitchOpen(false);
                  }}
                  className="flex items-center gap-2 pl-2 pr-1.5 py-1 rounded-full border border-slate-200 hover:border-slate-300 hover:bg-slate-50 transition-all text-left"
                >
                  {currentUser.profileImage ? (
                    <img
                      src={currentUser.profileImage}
                      alt={currentUser.name}
                      referrerPolicy="no-referrer"
                      className="w-7 h-7 rounded-full object-cover border border-slate-200"
                    />
                  ) : (
                    <div className="w-7 h-7 rounded-full bg-slate-800 text-white flex items-center justify-center text-xs font-bold">
                      {currentUser.name.charAt(0)}
                    </div>
                  )}
                  <span className="text-xs font-semibold text-slate-800 hidden md:inline max-w-[120px] truncate">
                    {currentUser.name}
                  </span>
                  <ChevronDown className="w-3.5 h-3.5 text-slate-500" />
                </button>

                {dropdownOpen && (
                  <div className="absolute right-0 mt-2 w-56 bg-white rounded-xl shadow-xl border border-slate-200 p-2 z-50 animate-in fade-in zoom-in-95 duration-150">
                    <div className="px-3 py-2 border-b border-slate-100 mb-1">
                      <p className="text-xs font-bold text-slate-900 truncate">{currentUser.name}</p>
                      <p className="text-[11px] text-slate-500 truncate">{currentUser.email}</p>
                      <div className="mt-1.5 sm:hidden">{getRoleBadge()}</div>
                    </div>
                    <button
                      onClick={() => {
                        onOpenSettings();
                        setDropdownOpen(false);
                      }}
                      className="w-full text-left px-3 py-2 rounded-lg text-xs font-medium text-slate-700 hover:bg-slate-100 flex items-center gap-2 transition-colors"
                    >
                      <UserIcon className="w-3.5 h-3.5 text-slate-500" />
                      Profile & Settings
                    </button>
                    {currentUser.role === 'main_admin' && (
                      <button
                        onClick={() => {
                          onOpenDatabase();
                          setDropdownOpen(false);
                        }}
                        className="w-full text-left px-3 py-2 rounded-lg text-xs font-medium text-slate-700 hover:bg-slate-100 flex items-center gap-2 transition-colors"
                      >
                        <Database className="w-3.5 h-3.5 text-slate-500" />
                        Database Schema & Ingest
                      </button>
                    )}
                    <button
                      onClick={() => {
                        onLogout();
                        setDropdownOpen(false);
                      }}
                      className="w-full text-left px-3 py-2 rounded-lg text-xs font-medium text-rose-600 hover:bg-rose-50 flex items-center gap-2 transition-colors mt-1 border-t border-slate-100"
                    >
                      <LogOut className="w-3.5 h-3.5 text-rose-500" />
                      Sign Out
                    </button>
                  </div>
                )}
              </div>
            </>
          )}
        </div>
      </div>
    </header>
  );
};
