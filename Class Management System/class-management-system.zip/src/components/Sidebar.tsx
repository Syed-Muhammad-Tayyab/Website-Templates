import React from 'react';
import {
  LayoutDashboard,
  Megaphone,
  BookOpen,
  FileText,
  CalendarCheck,
  Users,
  ShieldCheck,
  Settings,
  Database,
} from 'lucide-react';
import type { User, UserPermission } from '../types.js';

export type NavTab =
  | 'overview'
  | 'announcements'
  | 'subjects'
  | 'notes'
  | 'attendance'
  | 'students'
  | 'admin'
  | 'database'
  | 'settings';

interface SidebarProps {
  currentTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  currentUser: User | null;
  permissions: UserPermission[];
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onSelectTab,
  currentUser,
  permissions,
}) => {
  if (!currentUser) return null;

  const isAdmin = currentUser.role === 'main_admin';

  // Helper to test if a section is permitted
  const hasAccess = (section: string) => {
    if (isAdmin) return true;
    const perm = permissions.find((p) => p.section === section);
    // Student & Teacher have default read access to basic sections
    if (!perm) {
      if (section === 'overview' || section === 'settings') return true;
      if (currentUser.role === 'teacher' || currentUser.role === 'student') {
        if (section === 'announcements' || section === 'subjects' || section === 'notes' || section === 'attendance' || section === 'students') {
          return true;
        }
      }
      return false;
    }
    return perm.canRead;
  };

  const navItems = [
    {
      id: 'overview' as NavTab,
      label: 'Dashboard Overview',
      icon: LayoutDashboard,
      visible: true,
    },
    {
      id: 'announcements' as NavTab,
      label: 'Announcements',
      icon: Megaphone,
      visible: hasAccess('announcements'),
    },
    {
      id: 'subjects' as NavTab,
      label: 'Subjects & Classes',
      icon: BookOpen,
      visible: hasAccess('subjects'),
    },
    {
      id: 'notes' as NavTab,
      label: 'Notes & Materials',
      icon: FileText,
      visible: hasAccess('notes'),
    },
    {
      id: 'attendance' as NavTab,
      label: 'Attendance Records',
      icon: CalendarCheck,
      visible: hasAccess('attendance'),
    },
    {
      id: 'students' as NavTab,
      label: 'Students Directory',
      icon: Users,
      visible: hasAccess('students'),
    },
    {
      id: 'admin' as NavTab,
      label: 'Main Admin Panel',
      icon: ShieldCheck,
      visible: isAdmin,
      badge: 'Admin',
    },
    {
      id: 'database' as NavTab,
      label: 'Database & Ingestion',
      icon: Database,
      visible: isAdmin,
      badge: 'Schema',
    },
    {
      id: 'settings' as NavTab,
      label: 'Settings & Security',
      icon: Settings,
      visible: true,
    },
  ];

  return (
    <aside className="w-full lg:w-64 shrink-0 border-r border-slate-200 bg-white/80 backdrop-blur lg:min-h-[calc(100vh-4rem)] p-4 flex flex-col justify-between">
      <div className="space-y-1">
        <div className="px-3 py-2">
          <p className="text-[11px] font-bold tracking-wider uppercase text-slate-400">
            Navigation Menu
          </p>
        </div>

        {navItems
          .filter((item) => item.visible)
          .map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                id={`nav-${item.id}`}
                onClick={() => onSelectTab(item.id)}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all ${
                  isActive
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon className={`w-4 h-4 ${isActive ? 'text-indigo-400' : 'text-slate-500'}`} />
                  <span>{item.label}</span>
                </div>
                {item.badge && (
                  <span
                    className={`text-[10px] px-1.5 py-0.5 rounded font-bold uppercase ${
                      isActive
                        ? 'bg-indigo-500/30 text-indigo-200'
                        : 'bg-amber-100 text-amber-800'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
      </div>

      {/* Role Notice Card */}
      <div className="mt-8 p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs">
        <div className="flex items-center gap-2 mb-1">
          <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
          <p className="font-semibold text-slate-800">RBAC Enforced</p>
        </div>
        <p className="text-[11px] text-slate-500 leading-relaxed">
          {currentUser.role === 'main_admin'
            ? 'You have unrestricted access to manage all users, resources, and database schemas.'
            : currentUser.role === 'teacher'
            ? 'Scoped faculty access: Only authorized subjects and assigned class records are accessible.'
            : 'Enrolled student view: View-only access to academic notes, syllabus, and personal attendance.'}
        </p>
      </div>
    </aside>
  );
};
