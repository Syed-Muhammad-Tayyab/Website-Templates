import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  UserPlus,
  Users,
  Lock,
  FileCheck2,
  Trash2,
  Edit2,
  Check,
  X,
  History,
  Search,
  KeyRound,
  Eye,
  AlertCircle,
} from 'lucide-react';
import type { User, UserPermission, AuditLog, Subject } from '../types.js';
import { api } from '../lib/api.js';

interface AdminViewProps {
  currentUser: User;
  subjects: Subject[];
  onShowToast: (msg: string, type?: 'success' | 'error') => void;
}

export const AdminView: React.FC<AdminViewProps> = ({
  currentUser,
  subjects,
  onShowToast,
}) => {
  const [subTab, setSubTab] = useState<'users' | 'permissions' | 'audit'>('users');
  const [users, setUsers] = useState<User[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [loading, setLoading] = useState(false);

  // User Management Modal
  const [isUserModalOpen, setIsUserModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [userName, setUserName] = useState('');
  const [userEmail, setUserEmail] = useState('');
  const [userPassword, setUserPassword] = useState('');
  const [userRole, setUserRole] = useState<'main_admin' | 'teacher' | 'student'>('teacher');
  const [userPhone, setUserPhone] = useState('');
  const [userImage, setUserImage] = useState('');
  const [savingUser, setSavingUser] = useState(false);

  // Permission Matrix State
  const [selectedUserForPerms, setSelectedUserForPerms] = useState<User | null>(null);
  const [userPerms, setUserPerms] = useState<UserPermission[]>([]);
  const [savingPerms, setSavingPerms] = useState(false);

  // Audit Search
  const [auditSearch, setAuditSearch] = useState('');

  const SECTIONS = [
    { id: 'overview', name: 'Dashboard Overview' },
    { id: 'announcements', name: 'Announcements' },
    { id: 'subjects', name: 'Subjects & Classes' },
    { id: 'notes', name: 'Notes & Materials' },
    { id: 'attendance', name: 'Attendance System' },
    { id: 'students', name: 'Student Directory' },
    { id: 'admin', name: 'Admin Management' },
  ];

  const loadUsers = async () => {
    try {
      setLoading(true);
      const res = await api.getUsers();
      setUsers(res);
      if (!selectedUserForPerms && res.length > 0) {
        // default select the first teacher or non-admin user
        const target = res.find((u) => u.role !== 'main_admin') || res[0];
        setSelectedUserForPerms(target);
      }
    } catch (err: any) {
      onShowToast('Failed to load users list.', 'error');
    } finally {
      setLoading(false);
    }
  };

  const loadAuditLogs = async () => {
    try {
      const logs = await api.getAuditLogs();
      setAuditLogs(logs);
    } catch (err: any) {
      onShowToast('Failed to load security audit logs.', 'error');
    }
  };

  const loadUserPermissions = async (userId: string) => {
    try {
      const perms = await api.getUserPermissions(userId);
      // Ensure all sections exist in state
      const fullPerms = SECTIONS.map((sec) => {
        const found = perms.find((p) => p.section === sec.id);
        return (
          found || {
            userId,
            section: sec.id,
            canRead: true,
            canCreate: false,
            canEdit: false,
            canDelete: false,
          }
        );
      });
      setUserPerms(fullPerms);
    } catch (err: any) {
      onShowToast('Failed to load permissions.', 'error');
    }
  };

  useEffect(() => {
    loadUsers();
  }, []);

  useEffect(() => {
    if (subTab === 'audit') {
      loadAuditLogs();
    }
  }, [subTab]);

  useEffect(() => {
    if (selectedUserForPerms) {
      loadUserPermissions(selectedUserForPerms.id);
    }
  }, [selectedUserForPerms]);

  const openCreateUserModal = () => {
    setEditingUser(null);
    setUserName('');
    setUserEmail('');
    setUserPassword('Password123!');
    setUserRole('teacher');
    setUserPhone('');
    setUserImage('');
    setIsUserModalOpen(true);
  };

  const openEditUserModal = (u: User) => {
    setEditingUser(u);
    setUserName(u.name);
    setUserEmail(u.email);
    setUserPassword('');
    setUserRole(u.role);
    setUserPhone(u.phone || '');
    setUserImage(u.profileImage || '');
    setIsUserModalOpen(true);
  };

  const handleSaveUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userName.trim() || !userEmail.trim()) {
      onShowToast('Please provide name and valid email.', 'error');
      return;
    }

    try {
      setSavingUser(true);
      if (editingUser) {
        await api.updateUser(editingUser.id, {
          name: userName,
          email: userEmail,
          role: userRole,
          phone: userPhone,
          profileImage: userImage.trim() || undefined,
          ...(userPassword ? { password: userPassword } : {}),
        });
        onShowToast('User details updated successfully.');
      } else {
        await api.createUser({
          name: userName,
          email: userEmail,
          password: userPassword,
          role: userRole,
          phone: userPhone,
          profileImage: userImage.trim() || undefined,
        });
        onShowToast('New user account provisioned.');
      }

      setIsUserModalOpen(false);
      loadUsers();
    } catch (err: any) {
      onShowToast(err.message || 'Error saving user account.', 'error');
    } finally {
      setSavingUser(false);
    }
  };

  const handleDeleteUser = async (id: string) => {
    if (id === currentUser.id) {
      onShowToast('You cannot delete your own active administrator account.', 'error');
      return;
    }
    if (!window.confirm('Are you sure you want to permanently delete this user account?')) return;
    try {
      await api.deleteUser(id);
      onShowToast('User account removed.');
      loadUsers();
    } catch (err: any) {
      onShowToast(err.message || 'Failed to delete user.', 'error');
    }
  };

  const handleTogglePerm = (
    sectionId: string,
    field: 'canRead' | 'canCreate' | 'canEdit' | 'canDelete'
  ) => {
    setUserPerms((prev) =>
      prev.map((p) => {
        if (p.section === sectionId) {
          return { ...p, [field]: !p[field] };
        }
        return p;
      })
    );
  };

  const handleToggleRowAll = (sectionId: string) => {
    setUserPerms((prev) =>
      prev.map((p) => {
        if (p.section === sectionId) {
          const allTrue = p.canRead && p.canCreate && p.canEdit && p.canDelete;
          return {
            ...p,
            canRead: !allTrue,
            canCreate: !allTrue,
            canEdit: !allTrue,
            canDelete: !allTrue,
          };
        }
        return p;
      })
    );
  };

  const handleToggleColumnAll = (field: 'canRead' | 'canCreate' | 'canEdit' | 'canDelete') => {
    const allChecked = userPerms.every((p) => p[field]);
    setUserPerms((prev) =>
      prev.map((p) => ({
        ...p,
        [field]: !allChecked,
      }))
    );
  };

  const handleSavePermissions = async () => {
    if (!selectedUserForPerms) return;
    try {
      setSavingPerms(true);
      await api.updateUserPermissions(selectedUserForPerms.id, userPerms);
      onShowToast(`ACL Permissions updated for ${selectedUserForPerms.name}.`);
    } catch (err: any) {
      onShowToast(err.message || 'Failed to save permissions.', 'error');
    } finally {
      setSavingPerms(false);
    }
  };

  // Filter audit logs
  const filteredAudit = auditLogs.filter((log) => {
    const term = auditSearch.toLowerCase();
    return (
      log.action.toLowerCase().includes(term) ||
      log.performedByName?.toLowerCase().includes(term) ||
      log.details?.toLowerCase().includes(term) ||
      log.entity.toLowerCase().includes(term)
    );
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-indigo-600" />
            <span>Main Admin Control & Governance</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            User identity provisioning, Role-Based Access Control (RBAC), and security audit trails.
          </p>
        </div>

        {subTab === 'users' && (
          <button
            id="btn-add-user"
            onClick={openCreateUserModal}
            className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-white shadow-xs transition-colors"
          >
            <UserPlus className="w-3.5 h-3.5" />
            <span>Provision User</span>
          </button>
        )}
      </div>

      {/* Sub Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 text-xs">
        <button
          onClick={() => setSubTab('users')}
          className={`pb-3 px-3 font-semibold border-b-2 transition-colors flex items-center gap-1.5 ${
            subTab === 'users'
              ? 'border-indigo-600 text-indigo-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>User Accounts ({users.length})</span>
        </button>

        <button
          onClick={() => setSubTab('permissions')}
          className={`pb-3 px-3 font-semibold border-b-2 transition-colors flex items-center gap-1.5 ${
            subTab === 'permissions'
              ? 'border-indigo-600 text-indigo-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Lock className="w-4 h-4" />
          <span>Granular ACL Permission Matrix</span>
        </button>

        <button
          onClick={() => setSubTab('audit')}
          className={`pb-3 px-3 font-semibold border-b-2 transition-colors flex items-center gap-1.5 ${
            subTab === 'audit'
              ? 'border-indigo-600 text-indigo-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <History className="w-4 h-4" />
          <span>Security Audit Ledger ({auditLogs.length})</span>
        </button>
      </div>

      {/* TAB 1: USERS LIST */}
      {subTab === 'users' && (
        <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-2xs">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase text-[10px]">
                <tr>
                  <th className="py-3 px-4">User</th>
                  <th className="py-3 px-4">Institutional Role</th>
                  <th className="py-3 px-4">Contact Phone</th>
                  <th className="py-3 px-4">Enrolled Date</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {users.map((u) => {
                  const getBadge = () => {
                    switch (u.role) {
                      case 'main_admin':
                        return (
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 uppercase">
                            Main Admin
                          </span>
                        );
                      case 'teacher':
                        return (
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-100 text-indigo-800 uppercase">
                            Teacher / Faculty
                          </span>
                        );
                      case 'student':
                        return (
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800 uppercase">
                            Student
                          </span>
                        );
                    }
                  };

                  return (
                    <tr key={u.id} className="hover:bg-slate-50/70">
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-3">
                          {u.profileImage ? (
                            <img
                              src={u.profileImage}
                              alt={u.name}
                              referrerPolicy="no-referrer"
                              className="w-8 h-8 rounded-full object-cover border border-slate-200"
                            />
                          ) : (
                            <div className="w-8 h-8 rounded-full bg-slate-800 text-white font-bold flex items-center justify-center text-xs">
                              {u.name.charAt(0)}
                            </div>
                          )}
                          <div>
                            <p className="font-bold text-slate-900">{u.name}</p>
                            <p className="text-[11px] text-slate-400">{u.email}</p>
                          </div>
                        </div>
                      </td>

                      <td className="py-3.5 px-4">{getBadge()}</td>

                      <td className="py-3.5 px-4 text-slate-600">
                        {u.phone || '—'}
                      </td>

                      <td className="py-3.5 px-4 text-slate-400 text-[11px]">
                        {new Date(u.createdAt).toLocaleDateString()}
                      </td>

                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => {
                              setSelectedUserForPerms(u);
                              setSubTab('permissions');
                            }}
                            className="px-2 py-1 rounded text-[11px] font-semibold text-indigo-600 hover:bg-indigo-50 transition-colors"
                            title="Configure granular permissions"
                          >
                            Permissions
                          </button>
                          <button
                            onClick={() => openEditUserModal(u)}
                            className="p-1 text-slate-400 hover:text-indigo-600 rounded transition-colors"
                            title="Edit user"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          {u.id !== currentUser.id && (
                            <button
                              onClick={() => handleDeleteUser(u.id)}
                              className="p-1 text-slate-400 hover:text-rose-600 rounded transition-colors"
                              title="Delete user"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 2: GRANULAR ACL MATRIX */}
      {subTab === 'permissions' && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-2xs space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                Granular Access Control List (ACL)
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Configure section-by-section permissions (Read, Create, Edit, Delete) for any user.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-500 font-medium">Select User:</span>
              <select
                value={selectedUserForPerms?.id || ''}
                onChange={(e) => {
                  const u = users.find((item) => item.id === e.target.value);
                  if (u) setSelectedUserForPerms(u);
                }}
                className="text-xs py-1.5 px-3 rounded-lg border border-slate-200 bg-white font-semibold text-slate-800 focus:outline-hidden focus:border-indigo-500"
              >
                {users.map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.name} ({u.role.replace('_', ' ')})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {selectedUserForPerms?.role === 'main_admin' && (
            <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-800 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
              <span>
                <strong>Main Administrator account:</strong> Main Admins bypass ACL checks with full unrestricted system privileges.
              </span>
            </div>
          )}

          {/* Matrix Table */}
          <div className="border border-slate-200 rounded-xl overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-700 font-semibold">
                <tr>
                  <th className="py-3 px-4">Application Section</th>
                  <th className="py-3 px-4 text-center">
                    <button
                      onClick={() => handleToggleColumnAll('canRead')}
                      className="hover:underline hover:text-indigo-600 font-bold"
                    >
                      Read
                    </button>
                  </th>
                  <th className="py-3 px-4 text-center">
                    <button
                      onClick={() => handleToggleColumnAll('canCreate')}
                      className="hover:underline hover:text-indigo-600 font-bold"
                    >
                      Create
                    </button>
                  </th>
                  <th className="py-3 px-4 text-center">
                    <button
                      onClick={() => handleToggleColumnAll('canEdit')}
                      className="hover:underline hover:text-indigo-600 font-bold"
                    >
                      Edit
                    </button>
                  </th>
                  <th className="py-3 px-4 text-center">
                    <button
                      onClick={() => handleToggleColumnAll('canDelete')}
                      className="hover:underline hover:text-indigo-600 font-bold"
                    >
                      Delete
                    </button>
                  </th>
                  <th className="py-3 px-4 text-right">Quick Select</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {SECTIONS.map((sec) => {
                  const perm = userPerms.find((p) => p.section === sec.id) || {
                    section: sec.id,
                    canRead: false,
                    canCreate: false,
                    canEdit: false,
                    canDelete: false,
                  };

                  return (
                    <tr key={sec.id} className="hover:bg-slate-50/70">
                      <td className="py-3 px-4 font-semibold text-slate-800">
                        {sec.name}
                      </td>

                      {/* Read */}
                      <td className="py-3 px-4 text-center">
                        <input
                          type="checkbox"
                          checked={perm.canRead}
                          onChange={() => handleTogglePerm(sec.id, 'canRead')}
                          className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                        />
                      </td>

                      {/* Create */}
                      <td className="py-3 px-4 text-center">
                        <input
                          type="checkbox"
                          checked={perm.canCreate}
                          onChange={() => handleTogglePerm(sec.id, 'canCreate')}
                          className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                        />
                      </td>

                      {/* Edit */}
                      <td className="py-3 px-4 text-center">
                        <input
                          type="checkbox"
                          checked={perm.canEdit}
                          onChange={() => handleTogglePerm(sec.id, 'canEdit')}
                          className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                        />
                      </td>

                      {/* Delete */}
                      <td className="py-3 px-4 text-center">
                        <input
                          type="checkbox"
                          checked={perm.canDelete}
                          onChange={() => handleTogglePerm(sec.id, 'canDelete')}
                          className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                        />
                      </td>

                      {/* Select All in Row */}
                      <td className="py-3 px-4 text-right">
                        <button
                          type="button"
                          onClick={() => handleToggleRowAll(sec.id)}
                          className="text-[11px] font-semibold text-indigo-600 hover:text-indigo-800"
                        >
                          Toggle Row
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          <div className="flex items-center justify-end">
            <button
              onClick={handleSavePermissions}
              disabled={savingPerms}
              className="px-5 py-2.5 rounded-xl font-semibold bg-indigo-600 hover:bg-indigo-500 text-white shadow-xs transition-colors text-xs flex items-center gap-2"
            >
              <Check className="w-4 h-4" />
              <span>{savingPerms ? 'Applying Permissions...' : 'Save ACL Permissions'}</span>
            </button>
          </div>
        </div>
      )}

      {/* TAB 3: AUDIT LOGS */}
      {subTab === 'audit' && (
        <div className="space-y-4">
          <div className="relative bg-white p-3 rounded-xl border border-slate-200">
            <Search className="w-4 h-4 text-slate-400 absolute left-6 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search audit trail by actor, action type, entity, or details..."
              value={auditSearch}
              onChange={(e) => setAuditSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-1.5 text-xs rounded-lg border border-slate-200 focus:outline-hidden focus:border-indigo-500"
            />
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-2xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase text-[10px]">
                  <tr>
                    <th className="py-3 px-4">Timestamp</th>
                    <th className="py-3 px-4">Actor</th>
                    <th className="py-3 px-4">Action</th>
                    <th className="py-3 px-4">Target Entity</th>
                    <th className="py-3 px-4">Event Details</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredAudit.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="py-8 text-center text-slate-400">
                        No audit events recorded matching search.
                      </td>
                    </tr>
                  ) : (
                    filteredAudit.map((log) => (
                      <tr key={log.id} className="hover:bg-slate-50/70">
                        <td className="py-3 px-4 text-slate-400 text-[11px] whitespace-nowrap">
                          {new Date(log.timestamp).toLocaleString()}
                        </td>
                        <td className="py-3 px-4 font-bold text-slate-800">
                          {log.performedByName || 'System'}
                        </td>
                        <td className="py-3 px-4">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                              log.action.includes('DELETE')
                                ? 'bg-rose-100 text-rose-800'
                                : log.action.includes('CREATE')
                                ? 'bg-emerald-100 text-emerald-800'
                                : log.action.includes('LOGIN')
                                ? 'bg-indigo-100 text-indigo-800'
                                : 'bg-slate-100 text-slate-700'
                            }`}
                          >
                            {log.action}
                          </span>
                        </td>
                        <td className="py-3 px-4 font-mono text-[11px] text-slate-600">
                          {log.entity}
                        </td>
                        <td className="py-3 px-4 text-slate-600 text-[11px]">
                          {log.details}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Provision User Modal */}
      {isUserModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 w-full max-w-lg overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900">
                {editingUser ? 'Edit User Credentials' : 'Provision User Account'}
              </h3>
              <button
                onClick={() => setIsUserModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-md"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveUser} className="p-5 space-y-3.5 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Dr. Jane Doe"
                    value={userName}
                    onChange={(e) => setUserName(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    System Role *
                  </label>
                  <select
                    value={userRole}
                    onChange={(e: any) => setUserRole(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 bg-white focus:outline-hidden focus:border-indigo-500 font-semibold"
                  >
                    <option value="main_admin">Main Admin (Unrestricted)</option>
                    <option value="teacher">Teacher / Faculty</option>
                    <option value="student">Student Account</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Email Address *
                </label>
                <input
                  type="email"
                  required
                  placeholder="faculty@school.edu"
                  value={userEmail}
                  onChange={(e) => setUserEmail(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  {editingUser ? 'Change Password (Leave blank to keep)' : 'Password *'}
                </label>
                <input
                  type="password"
                  required={!editingUser}
                  placeholder="Enter strong password..."
                  value={userPassword}
                  onChange={(e) => setUserPassword(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Phone Contact
                  </label>
                  <input
                    type="tel"
                    placeholder="+1 555-0100"
                    value={userPhone}
                    onChange={(e) => setUserPhone(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Profile Photo URL
                  </label>
                  <input
                    type="url"
                    placeholder="https://..."
                    value={userImage}
                    onChange={(e) => setUserImage(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:border-indigo-500"
                  />
                </div>
              </div>

              <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsUserModalOpen(false)}
                  className="px-3.5 py-2 rounded-lg font-medium text-slate-600 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={savingUser}
                  className="px-4 py-2 rounded-lg font-semibold bg-slate-900 hover:bg-slate-800 text-white transition-colors"
                >
                  {savingUser ? 'Saving...' : editingUser ? 'Update Account' : 'Provision User'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
