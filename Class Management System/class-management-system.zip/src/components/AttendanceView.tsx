import React, { useState, useEffect } from 'react';
import {
  CalendarCheck,
  CheckCircle2,
  XCircle,
  Clock,
  HelpCircle,
  Download,
  Search,
  Filter,
  BarChart3,
  Calendar as CalendarIcon,
  Check,
} from 'lucide-react';
import type { AttendanceRecord, Subject, Student, User } from '../types.js';
import { api } from '../lib/api.js';

interface AttendanceViewProps {
  attendanceRecords: AttendanceRecord[];
  subjects: Subject[];
  students: Student[];
  currentUser: User;
  onRefresh: () => void;
  onShowToast: (msg: string, type?: 'success' | 'error') => void;
}

export const AttendanceView: React.FC<AttendanceViewProps> = ({
  attendanceRecords,
  subjects,
  students,
  currentUser,
  onRefresh,
  onShowToast,
}) => {
  const [tab, setTab] = useState<'records' | 'mark' | 'analytics'>('records');
  const [selectedSubjectId, setSelectedSubjectId] = useState<string>('all');
  const [filterDate, setFilterDate] = useState<string>('');
  const [searchStudent, setSearchStudent] = useState<string>('');

  // Mark Attendance State
  const [markSubjectId, setMarkSubjectId] = useState(subjects[0]?.id || '');
  const [markDate, setMarkDate] = useState(new Date().toISOString().split('T')[0]);
  const [studentStatuses, setStudentStatuses] = useState<Record<string, 'present' | 'absent' | 'late' | 'excused'>>({});
  const [savingAttendance, setSavingAttendance] = useState(false);

  // Analytics Stats
  const [stats, setStats] = useState<any>(null);
  const [loadingStats, setLoadingStats] = useState(false);

  const canMark = currentUser.role === 'main_admin' || currentUser.role === 'teacher';

  // Initialize student statuses when students change or subject changes
  useEffect(() => {
    const initial: Record<string, 'present' | 'absent' | 'late' | 'excused'> = {};
    students.forEach((s) => {
      initial[s.id] = 'present';
    });
    setStudentStatuses(initial);
  }, [students]);

  useEffect(() => {
    if (tab === 'analytics') {
      loadStats();
    }
  }, [tab]);

  const loadStats = async () => {
    try {
      setLoadingStats(true);
      const res = await api.getAttendanceStats();
      setStats(res);
    } catch (err: any) {
      onShowToast('Failed to load attendance metrics.', 'error');
    } finally {
      setLoadingStats(false);
    }
  };

  const handleExportCSV = async () => {
    try {
      const csvData = await api.exportAttendance();
      const blob = new Blob([csvData], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.setAttribute('href', url);
      link.setAttribute('download', `Attendance_Report_${new Date().toISOString().split('T')[0]}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      onShowToast('Attendance report downloaded.');
    } catch (err: any) {
      onShowToast('Failed to export CSV.', 'error');
    }
  };

  const handleSaveAttendance = async () => {
    if (!markSubjectId) {
      onShowToast('Please choose a course subject.', 'error');
      return;
    }
    if (students.length === 0) {
      onShowToast('No students registered to mark attendance for.', 'error');
      return;
    }

    try {
      setSavingAttendance(true);
      const recordsToSubmit = students.map((s) => ({
        studentId: s.id,
        subjectId: markSubjectId,
        date: markDate,
        status: studentStatuses[s.id] || 'present',
      }));

      await api.markAttendance(recordsToSubmit);
      onShowToast(`Attendance recorded for ${recordsToSubmit.length} students.`);
      onRefresh();
      setTab('records');
    } catch (err: any) {
      onShowToast(err.message || 'Error recording attendance.', 'error');
    } finally {
      setSavingAttendance(false);
    }
  };

  const handleMarkAll = (status: 'present' | 'absent' | 'late' | 'excused') => {
    const updated: Record<string, 'present' | 'absent' | 'late' | 'excused'> = {};
    students.forEach((s) => {
      updated[s.id] = status;
    });
    setStudentStatuses(updated);
  };

  // Filter records
  const filteredRecords = attendanceRecords.filter((rec) => {
    const matchesSubject = selectedSubjectId === 'all' || rec.subjectId === selectedSubjectId;
    const matchesDate = !filterDate || rec.date === filterDate;
    const matchesSearch =
      !searchStudent ||
      rec.studentName?.toLowerCase().includes(searchStudent.toLowerCase()) ||
      rec.studentRollNo?.toLowerCase().includes(searchStudent.toLowerCase());
    return matchesSubject && matchesDate && matchesSearch;
  });

  return (
    <div className="space-y-6">
      {/* Header & Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <CalendarCheck className="w-5 h-5 text-indigo-600" />
            <span>Attendance Governance & Records</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Monitor institutional presence rates, record roll registers, and review student percentages.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCSV}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 shadow-2xs transition-colors"
          >
            <Download className="w-3.5 h-3.5 text-slate-500" />
            <span>Export CSV Report</span>
          </button>

          {canMark && (
            <button
              onClick={() => setTab('mark')}
              className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold shadow-xs transition-colors ${
                tab === 'mark'
                  ? 'bg-indigo-600 text-white'
                  : 'bg-slate-900 hover:bg-slate-800 text-white'
              }`}
            >
              <CalendarIcon className="w-3.5 h-3.5 text-indigo-300" />
              <span>Mark Session Attendance</span>
            </button>
          )}
        </div>
      </div>

      {/* Tab Switcher */}
      <div className="flex items-center gap-2 border-b border-slate-200 text-xs">
        <button
          onClick={() => setTab('records')}
          className={`pb-3 px-3 font-semibold border-b-2 transition-colors flex items-center gap-1.5 ${
            tab === 'records'
              ? 'border-indigo-600 text-indigo-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <CalendarCheck className="w-4 h-4" />
          <span>Attendance Ledger ({filteredRecords.length})</span>
        </button>

        <button
          onClick={() => setTab('analytics')}
          className={`pb-3 px-3 font-semibold border-b-2 transition-colors flex items-center gap-1.5 ${
            tab === 'analytics'
              ? 'border-indigo-600 text-indigo-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <BarChart3 className="w-4 h-4" />
          <span>Analytics & Percentages</span>
        </button>

        {canMark && (
          <button
            onClick={() => setTab('mark')}
            className={`pb-3 px-3 font-semibold border-b-2 transition-colors flex items-center gap-1.5 ${
              tab === 'mark'
                ? 'border-indigo-600 text-indigo-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>Mark Daily Roll</span>
          </button>
        )}
      </div>

      {/* TAB 1: ATTENDANCE LEDGER */}
      {tab === 'records' && (
        <div className="space-y-4">
          {/* Filter Bar */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-white p-3 rounded-xl border border-slate-200 text-xs">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search student or roll number..."
                value={searchStudent}
                onChange={(e) => setSearchStudent(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 rounded-lg border border-slate-200 focus:outline-hidden focus:border-indigo-500"
              />
            </div>

            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-slate-400 shrink-0" />
              <select
                value={selectedSubjectId}
                onChange={(e) => setSelectedSubjectId(e.target.value)}
                className="w-full py-1.5 px-3 rounded-lg border border-slate-200 bg-white focus:outline-hidden focus:border-indigo-500 text-slate-700"
              >
                <option value="all">All Subjects</option>
                {subjects.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.code}: {s.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-slate-400 text-xs">Date:</span>
              <input
                type="date"
                value={filterDate}
                onChange={(e) => setFilterDate(e.target.value)}
                className="w-full py-1.5 px-3 rounded-lg border border-slate-200 bg-white focus:outline-hidden focus:border-indigo-500 text-slate-700"
              />
              {filterDate && (
                <button
                  onClick={() => setFilterDate('')}
                  className="text-indigo-600 font-semibold text-[11px] hover:underline"
                >
                  Clear
                </button>
              )}
            </div>
          </div>

          {/* Table */}
          {filteredRecords.length === 0 ? (
            <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center">
              <CalendarCheck className="w-10 h-10 text-slate-300 mx-auto mb-3" />
              <h3 className="text-sm font-bold text-slate-800">No Attendance Records</h3>
              <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                No session roll entries match your current filter. Use "Mark Daily Roll" to log class attendance.
              </p>
            </div>
          ) : (
            <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-2xs">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase text-[10px] tracking-wider">
                    <tr>
                      <th className="py-3 px-4">Student & Roll No</th>
                      <th className="py-3 px-4">Course Subject</th>
                      <th className="py-3 px-4">Class Date</th>
                      <th className="py-3 px-4">Status</th>
                      <th className="py-3 px-4">Recorded By</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredRecords.map((rec) => {
                      const getStatusBadge = () => {
                        switch (rec.status) {
                          case 'present':
                            return (
                              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full font-semibold text-[11px] bg-emerald-100 text-emerald-800">
                                <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                                Present
                              </span>
                            );
                          case 'absent':
                            return (
                              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full font-semibold text-[11px] bg-rose-100 text-rose-800">
                                <XCircle className="w-3 h-3 text-rose-600" />
                                Absent
                              </span>
                            );
                          case 'late':
                            return (
                              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full font-semibold text-[11px] bg-amber-100 text-amber-800">
                                <Clock className="w-3 h-3 text-amber-600" />
                                Late
                              </span>
                            );
                          case 'excused':
                            return (
                              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full font-semibold text-[11px] bg-blue-100 text-blue-800">
                                <HelpCircle className="w-3 h-3 text-blue-600" />
                                Excused
                              </span>
                            );
                        }
                      };

                      return (
                        <tr key={rec.id} className="hover:bg-slate-50/70 transition-colors">
                          <td className="py-3 px-4">
                            <p className="font-bold text-slate-900">{rec.studentName}</p>
                            <p className="text-[11px] text-slate-400">{rec.studentRollNo}</p>
                          </td>
                          <td className="py-3 px-4 text-slate-700 font-medium">
                            {rec.subjectName}
                          </td>
                          <td className="py-3 px-4 text-slate-600">
                            {rec.date}
                          </td>
                          <td className="py-3 px-4">{getStatusBadge()}</td>
                          <td className="py-3 px-4 text-slate-500 text-[11px]">
                            {rec.markedByName || 'System'}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 2: MARK ATTENDANCE */}
      {tab === 'mark' && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-2xs space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                Mark Session Attendance Ledger
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Select the target course and date, then toggle presence for each student.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-500 font-medium">Quick Bulk:</span>
              <button
                onClick={() => handleMarkAll('present')}
                className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200 hover:bg-emerald-100"
              >
                All Present
              </button>
              <button
                onClick={() => handleMarkAll('absent')}
                className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-rose-50 text-rose-700 border border-rose-200 hover:bg-rose-100"
              >
                All Absent
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Course / Subject *
              </label>
              <select
                value={markSubjectId}
                onChange={(e) => setMarkSubjectId(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 bg-white focus:outline-hidden focus:border-indigo-500"
              >
                {subjects.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.code}: {s.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Class Session Date *
              </label>
              <input
                type="date"
                required
                value={markDate}
                onChange={(e) => setMarkDate(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 bg-white focus:outline-hidden focus:border-indigo-500"
              />
            </div>
          </div>

          {/* Student Roll Call List */}
          {students.length === 0 ? (
            <div className="p-8 text-center border border-dashed border-slate-200 rounded-xl text-slate-500 text-xs">
              No students enrolled in directory. Ingest or add students first.
            </div>
          ) : (
            <div className="divide-y divide-slate-100 border border-slate-200 rounded-xl overflow-hidden">
              {students.map((student) => {
                const currentStatus = studentStatuses[student.id] || 'present';

                return (
                  <div
                    key={student.id}
                    className="p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-50/50"
                  >
                    <div className="flex items-center gap-3">
                      {student.profileImage ? (
                        <img
                          src={student.profileImage}
                          alt={student.name}
                          className="w-9 h-9 rounded-full object-cover border border-slate-200"
                        />
                      ) : (
                        <div className="w-9 h-9 rounded-full bg-slate-800 text-white font-bold flex items-center justify-center text-xs">
                          {student.name.charAt(0)}
                        </div>
                      )}
                      <div>
                        <p className="font-bold text-slate-900 text-xs">{student.name}</p>
                        <p className="text-[11px] text-slate-500">
                          {student.rollNo} &middot; {student.classId}
                        </p>
                      </div>
                    </div>

                    {/* Status Toggle Buttons */}
                    <div className="flex items-center gap-1.5 self-end sm:self-auto">
                      {(['present', 'late', 'absent', 'excused'] as const).map((status) => {
                        const isSelected = currentStatus === status;
                        const colors = {
                          present: isSelected
                            ? 'bg-emerald-600 text-white font-bold'
                            : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100',
                          late: isSelected
                            ? 'bg-amber-500 text-white font-bold'
                            : 'bg-amber-50 text-amber-700 hover:bg-amber-100',
                          absent: isSelected
                            ? 'bg-rose-600 text-white font-bold'
                            : 'bg-rose-50 text-rose-700 hover:bg-rose-100',
                          excused: isSelected
                            ? 'bg-blue-600 text-white font-bold'
                            : 'bg-blue-50 text-blue-700 hover:bg-blue-100',
                        };

                        return (
                          <button
                            key={status}
                            type="button"
                            onClick={() =>
                              setStudentStatuses({
                                ...studentStatuses,
                                [student.id]: status,
                              })
                            }
                            className={`px-3 py-1.5 rounded-lg text-xs capitalize transition-all ${colors[status]}`}
                          >
                            {status}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          <div className="pt-2 flex items-center justify-end">
            <button
              onClick={handleSaveAttendance}
              disabled={savingAttendance || students.length === 0}
              className="px-5 py-2.5 rounded-xl font-semibold bg-indigo-600 hover:bg-indigo-500 text-white shadow-xs transition-colors text-xs flex items-center gap-2"
            >
              <Check className="w-4 h-4" />
              <span>{savingAttendance ? 'Submitting Roll...' : 'Submit Attendance Register'}</span>
            </button>
          </div>
        </div>
      )}

      {/* TAB 3: ANALYTICS & PERCENTAGE REPORTS */}
      {tab === 'analytics' && (
        <div className="space-y-6">
          {loadingStats ? (
            <div className="py-16 text-center text-slate-400 text-xs">
              Calculating institutional attendance analytics...
            </div>
          ) : stats ? (
            <>
              {/* Top Overall Metric */}
              <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-2xs flex flex-col md:flex-row items-center justify-between gap-6">
                <div>
                  <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                    Institutional Attendance Rate
                  </span>
                  <div className="flex items-baseline gap-3 mt-1">
                    <span className="text-3xl font-extrabold text-slate-900">
                      {stats.overallPercentage}%
                    </span>
                    <span className="text-xs text-slate-500">
                      across {stats.totalRecords} registered roll entries
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 mt-2 max-w-md">
                    Target baseline is 85%. Students falling below this threshold are flagged for academic counselor review.
                  </p>
                </div>

                <div className="w-full md:w-64 bg-slate-100 h-3.5 rounded-full overflow-hidden">
                  <div
                    className="bg-indigo-600 h-full rounded-full transition-all duration-500"
                    style={{ width: `${stats.overallPercentage}%` }}
                  ></div>
                </div>
              </div>

              {/* Subject-Wise Attendance Breakdown */}
              <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-2xs">
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-4">
                  Course Subject Attendance Percentages
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  {stats.subjectStats.map((sub: any) => (
                    <div key={sub.subjectId} className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-bold text-indigo-700 bg-indigo-100 px-2 py-0.5 rounded">
                          {sub.subjectCode}
                        </span>
                        <span className="text-xs font-bold text-slate-900">
                          {sub.percentage}%
                        </span>
                      </div>
                      <h5 className="font-bold text-slate-900 text-xs mt-2 truncate">
                        {sub.subjectName}
                      </h5>
                      <div className="w-full bg-slate-200 h-1.5 rounded-full mt-2 overflow-hidden">
                        <div
                          className="bg-emerald-500 h-full rounded-full"
                          style={{ width: `${sub.percentage}%` }}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Student-Wise Performance Table */}
              <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-2xs">
                <div className="p-4 border-b border-slate-100">
                  <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                    Student-by-Student Attendance Summary
                  </h4>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase text-[10px]">
                      <tr>
                        <th className="py-3 px-4">Student & Roll No</th>
                        <th className="py-3 px-4">Total Sessions</th>
                        <th className="py-3 px-4 text-emerald-700">Present</th>
                        <th className="py-3 px-4 text-amber-700">Late</th>
                        <th className="py-3 px-4 text-rose-700">Absent</th>
                        <th className="py-3 px-4">Rate (%)</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {stats.studentStats.map((st: any) => (
                        <tr key={st.studentId} className="hover:bg-slate-50/70">
                          <td className="py-3 px-4">
                            <span className="font-bold text-slate-900">{st.name}</span>
                            <span className="text-[11px] text-slate-400 block">{st.rollNo}</span>
                          </td>
                          <td className="py-3 px-4 text-slate-700 font-medium">
                            {st.totalClasses}
                          </td>
                          <td className="py-3 px-4 text-emerald-700 font-medium">
                            {st.presentCount}
                          </td>
                          <td className="py-3 px-4 text-amber-700 font-medium">
                            {st.lateCount}
                          </td>
                          <td className="py-3 px-4 text-rose-700 font-medium">
                            {st.absentCount}
                          </td>
                          <td className="py-3 px-4">
                            <span
                              className={`font-bold px-2 py-0.5 rounded text-[11px] ${
                                st.percentage >= 85
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : st.percentage >= 70
                                  ? 'bg-amber-100 text-amber-800'
                                  : 'bg-rose-100 text-rose-800'
                              }`}
                            >
                              {st.percentage}%
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </>
          ) : null}
        </div>
      )}
    </div>
  );
};
