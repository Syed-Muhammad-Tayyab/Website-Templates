import React, { useState } from 'react';
import {
  BookOpen,
  Plus,
  Search,
  Users,
  FileText,
  Trash2,
  Edit2,
  Calendar,
  X,
  Upload,
} from 'lucide-react';
import type { Subject, User } from '../types.js';
import { api } from '../lib/api.js';
import { SubjectDetailModal } from './SubjectDetailModal.js';

interface SubjectsViewProps {
  subjects: Subject[];
  currentUser: User;
  onRefresh: () => void;
  onShowToast: (msg: string, type?: 'success' | 'error') => void;
}

export const SubjectsView: React.FC<SubjectsViewProps> = ({
  subjects,
  currentUser,
  onRefresh,
  onShowToast,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSubject, setSelectedSubject] = useState<Subject | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingSubject, setEditingSubject] = useState<Subject | null>(null);

  // Form State
  const [name, setName] = useState('');
  const [code, setCode] = useState('');
  const [department, setDepartment] = useState('');
  const [description, setDescription] = useState('');
  const [thumbnail, setThumbnail] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [saving, setSaving] = useState(false);

  const canManageSubjects = currentUser.role === 'main_admin';

  const filtered = subjects.filter(
    (s) =>
      s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.department?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const openCreateModal = () => {
    setEditingSubject(null);
    setName('');
    setCode('');
    setDepartment('Academics');
    setDescription('');
    setThumbnail('');
    setSelectedFile(null);
    setIsModalOpen(true);
  };

  const openEditModal = (subject: Subject, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingSubject(subject);
    setName(subject.name);
    setCode(subject.code);
    setDepartment(subject.department || '');
    setDescription(subject.description);
    setThumbnail(subject.thumbnail || '');
    setSelectedFile(null);
    setIsModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !code.trim()) {
      onShowToast('Please fill in subject name and course code.', 'error');
      return;
    }

    try {
      setSaving(true);
      let filePath = editingSubject?.filePath || '';

      if (selectedFile) {
        const uploadRes = await api.uploadFile(selectedFile);
        filePath = uploadRes.url;
      }

      if (editingSubject) {
        await api.updateSubject(editingSubject.id, {
          name,
          code,
          department,
          description,
          thumbnail: thumbnail.trim() || undefined,
          filePath: filePath || undefined,
        });
        onShowToast('Subject course updated successfully.');
      } else {
        await api.createSubject({
          name,
          code,
          department,
          description,
          thumbnail: thumbnail.trim() || undefined,
          filePath: filePath || undefined,
          teacherIds: [],
        });
        onShowToast('Subject course created successfully.');
      }

      setIsModalOpen(false);
      onRefresh();
    } catch (err: any) {
      onShowToast(err.message || 'Error saving subject.', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!window.confirm('Are you sure you want to delete this subject and its associated class records?')) return;
    try {
      await api.deleteSubject(id);
      onShowToast('Subject deleted.');
      onRefresh();
    } catch (err: any) {
      onShowToast(err.message || 'Failed to delete subject.', 'error');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-indigo-600" />
            <span>Academic Subjects & Courses</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Access course syllabi, assigned faculty, lecture notes, and class attendance ledgers.
          </p>
        </div>

        {canManageSubjects && (
          <button
            id="btn-add-subject"
            onClick={openCreateModal}
            className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-white shadow-xs transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Course / Subject</span>
          </button>
        )}
      </div>

      {/* Search Bar */}
      <div className="relative bg-white p-3 rounded-xl border border-slate-200">
        <Search className="w-4 h-4 text-slate-400 absolute left-6 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          placeholder="Search courses by code, title, or department..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full pl-10 pr-4 py-1.5 text-xs rounded-lg border border-slate-200 focus:outline-hidden focus:border-indigo-500"
        />
      </div>

      {/* Grid of Subjects */}
      {filtered.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center">
          <BookOpen className="w-10 h-10 text-slate-300 mx-auto mb-3" />
          <h3 className="text-sm font-bold text-slate-800">No Subjects Available</h3>
          <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
            {canManageSubjects
              ? 'Click "Add Course / Subject" to set up your curriculum or ingest from database center.'
              : 'You do not have access to any subjects currently.'}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((sub) => (
            <div
              key={sub.id}
              onClick={() => setSelectedSubject(sub)}
              className="group bg-white rounded-2xl border border-slate-200 hover:border-indigo-300 hover:shadow-md transition-all cursor-pointer overflow-hidden flex flex-col justify-between"
            >
              <div>
                {/* Course Header Banner */}
                <div className="h-32 bg-slate-100 relative overflow-hidden">
                  {sub.thumbnail ? (
                    <img
                      src={sub.thumbnail}
                      alt={sub.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  ) : (
                    <div className="w-full h-full bg-gradient-to-br from-indigo-900 to-slate-900 flex items-center justify-center text-white">
                      <span className="text-2xl font-bold tracking-wider opacity-60">
                        {sub.code}
                      </span>
                    </div>
                  )}

                  <div className="absolute top-3 left-3">
                    <span className="px-2.5 py-1 rounded-md text-[10px] font-bold tracking-wide uppercase bg-slate-900/80 text-white backdrop-blur-xs border border-white/20">
                      {sub.code}
                    </span>
                  </div>

                  {canManageSubjects && (
                    <div className="absolute top-3 right-3 flex items-center gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity bg-white/90 backdrop-blur-xs rounded-lg p-1 shadow-xs">
                      <button
                        onClick={(e) => openEditModal(sub, e)}
                        className="p-1 text-slate-600 hover:text-indigo-600 rounded transition-colors"
                        title="Edit course"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={(e) => handleDelete(sub.id, e)}
                        className="p-1 text-slate-600 hover:text-rose-600 rounded transition-colors"
                        title="Delete course"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}
                </div>

                {/* Course Details */}
                <div className="p-4">
                  <span className="text-[11px] font-semibold text-indigo-600">
                    {sub.department || 'Academic Department'}
                  </span>
                  <h3 className="text-sm font-bold text-slate-900 mt-1 leading-snug group-hover:text-indigo-600 transition-colors">
                    {sub.name}
                  </h3>
                  <p className="text-xs text-slate-500 mt-1.5 line-clamp-2 leading-relaxed">
                    {sub.description}
                  </p>
                </div>
              </div>

              {/* Course Footer Info */}
              <div className="px-4 py-3 bg-slate-50/70 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                <span className="flex items-center gap-1">
                  <Users className="w-3.5 h-3.5 text-slate-400" />
                  {sub.teacherIds?.length || 0} Faculty
                </span>
                <span className="font-semibold text-indigo-600 flex items-center gap-1">
                  View Syllabus & Record &rarr;
                </span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Course Detail Modal */}
      {selectedSubject && (
        <SubjectDetailModal
          subject={selectedSubject}
          currentUser={currentUser}
          onClose={() => setSelectedSubject(null)}
          onShowToast={onShowToast}
        />
      )}

      {/* Add/Edit Subject Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-lg overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900">
                {editingSubject ? 'Edit Subject Course' : 'Create New Subject Course'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-md"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-5 space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Course Code *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. MTH-301"
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Department
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Mathematics & Computing"
                    value={department}
                    onChange={(e) => setDepartment(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:border-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Subject Course Name *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Advanced Calculus & Analytical Geometry"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Course Thumbnail Image URL
                </label>
                <input
                  type="url"
                  placeholder="https://images.unsplash.com/..."
                  value={thumbnail}
                  onChange={(e) => setThumbnail(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Syllabus / Course Description
                </label>
                <textarea
                  rows={3}
                  placeholder="Overview of core objectives, prerequisite concepts, grading criteria..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:border-indigo-500"
                ></textarea>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Attach Official Syllabus PDF
                </label>
                <div className="border border-dashed border-slate-200 rounded-lg p-3 text-center hover:bg-slate-50 transition-colors">
                  <input
                    type="file"
                    id="sub-file-input"
                    className="hidden"
                    onChange={(e) => {
                      if (e.target.files?.[0]) setSelectedFile(e.target.files[0]);
                    }}
                  />
                  <label htmlFor="sub-file-input" className="cursor-pointer flex flex-col items-center">
                    <Upload className="w-5 h-5 text-slate-400 mb-1" />
                    <span className="text-slate-600 font-medium">
                      {selectedFile ? selectedFile.name : 'Upload course syllabus / guidelines'}
                    </span>
                  </label>
                </div>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-3.5 py-2 rounded-lg font-medium text-slate-600 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="px-4 py-2 rounded-lg font-semibold bg-slate-900 hover:bg-slate-800 text-white transition-colors"
                >
                  {saving ? 'Saving...' : editingSubject ? 'Save Changes' : 'Create Course'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
