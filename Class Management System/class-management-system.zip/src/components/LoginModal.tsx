import React, { useState } from 'react';
import {
  GraduationCap,
  Lock,
  Mail,
  ArrowRight,
  Shield,
  BookOpen,
  UserCheck,
  Database,
  CheckCircle2,
} from 'lucide-react';
import { api } from '../lib/api.js';
import type { User } from '../types.js';

interface LoginModalProps {
  onLoginSuccess: (user: User) => void;
  onShowToast: (msg: string, type?: 'success' | 'error') => void;
}

export const LoginModal: React.FC<LoginModalProps> = ({
  onLoginSuccess,
  onShowToast,
}) => {
  const [email, setEmail] = useState('admin@school.edu');
  const [password, setPassword] = useState('AdminPass123!');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setLoading(true);
      const res = await api.login(email, password);
      onLoginSuccess(res.user);
      onShowToast(`Signed in as ${res.user.name} (${res.user.role.replace('_', ' ')})`);
    } catch (err: any) {
      onShowToast(err.message || 'Invalid email or password.', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleQuickLogin = async (userEmail: string, userPass: string) => {
    setEmail(userEmail);
    setPassword(userPass);
    try {
      setLoading(true);
      const res = await api.login(userEmail, userPass);
      onLoginSuccess(res.user);
      onShowToast(`Signed in as ${res.user.name} (${res.user.role.replace('_', ' ')})`);
    } catch (err: any) {
      onShowToast(err.message || 'Login failed.', 'error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background Subtle Highlights */}
      <div className="absolute -top-40 -left-40 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute -bottom-40 -right-40 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none"></div>

      <div className="w-full max-w-4xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden grid grid-cols-1 md:grid-cols-2 relative z-10">
        {/* Left Side: Brand & Feature Highlights */}
        <div className="p-8 sm:p-10 bg-slate-950 text-white flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-indigo-600 flex items-center justify-center shadow-lg shadow-indigo-600/30">
                <GraduationCap className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-lg font-bold tracking-tight">Class Management System</h1>
                <p className="text-xs text-indigo-300">Enterprise Academic Suite</p>
              </div>
            </div>

            <div className="mt-8 space-y-4">
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-lg bg-emerald-500/15 text-emerald-400 flex items-center justify-center shrink-0 mt-0.5">
                  <Database className="w-3.5 h-3.5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-100">Empty Database Schema Ready</h4>
                  <p className="text-[11px] text-slate-400 mt-0.5 leading-relaxed">
                    11-table relational database architecture ready for institutional data ingestion and student profile management.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-lg bg-indigo-500/15 text-indigo-400 flex items-center justify-center shrink-0 mt-0.5">
                  <Shield className="w-3.5 h-3.5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-100">Role-Based Access Control (RBAC)</h4>
                  <p className="text-[11px] text-slate-400 mt-0.5 leading-relaxed">
                    Granular permission matrices for Main Admin, Faculty Teachers, and Students.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-lg bg-amber-500/15 text-amber-400 flex items-center justify-center shrink-0 mt-0.5">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-100">Audit Trail & Attendance Analytics</h4>
                  <p className="text-[11px] text-slate-400 mt-0.5 leading-relaxed">
                    Automatic security logs, class records, and institutional attendance reports.
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-8 pt-6 border-t border-slate-800 text-[11px] text-slate-500 flex items-center justify-between">
            <span>Enterprise Edition v2.6</span>
            <span>REST API Verified</span>
          </div>
        </div>

        {/* Right Side: Login Form & One-Click Demos */}
        <div className="p-8 sm:p-10 flex flex-col justify-between bg-white">
          <div>
            <div className="mb-6">
              <h2 className="text-xl font-bold text-slate-900 tracking-tight">System Sign In</h2>
              <p className="text-xs text-slate-500 mt-1">
                Enter your authorized credentials or use a one-click role profile below.
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Institutional Email
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    required
                    placeholder="name@school.edu"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-200 focus:outline-hidden focus:border-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Account Password
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="password"
                    required
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-200 focus:outline-hidden focus:border-indigo-500"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 rounded-xl font-semibold bg-slate-900 hover:bg-slate-800 text-white shadow-xs transition-colors flex items-center justify-center gap-2"
              >
                <span>{loading ? 'Authenticating...' : 'Sign In to Workspace'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>

            {/* Quick Demo Switcher */}
            <div className="mt-6 pt-5 border-t border-slate-100">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-2.5">
                Instant Role Switch Demo Accounts:
              </span>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <button
                  type="button"
                  onClick={() => handleQuickLogin('admin@school.edu', 'AdminPass123!')}
                  className="p-2.5 rounded-xl border border-amber-200 bg-amber-50/50 hover:bg-amber-100/60 text-left transition-colors"
                >
                  <div className="flex items-center gap-1.5 font-bold text-amber-900 text-[11px]">
                    <Shield className="w-3 h-3 text-amber-600" />
                    <span>Main Admin</span>
                  </div>
                  <p className="text-[10px] text-amber-700 mt-0.5">Full System Rights</p>
                </button>

                <button
                  type="button"
                  onClick={() => handleQuickLogin('sarah.jenkins@school.edu', 'TeacherPass123!')}
                  className="p-2.5 rounded-xl border border-indigo-200 bg-indigo-50/50 hover:bg-indigo-100/60 text-left transition-colors"
                >
                  <div className="flex items-center gap-1.5 font-bold text-indigo-900 text-[11px]">
                    <BookOpen className="w-3 h-3 text-indigo-600" />
                    <span>Faculty (Math)</span>
                  </div>
                  <p className="text-[10px] text-indigo-700 mt-0.5">Assigned Courses</p>
                </button>

                <button
                  type="button"
                  onClick={() => handleQuickLogin('marcus.vance@school.edu', 'TeacherPass123!')}
                  className="p-2.5 rounded-xl border border-indigo-200 bg-indigo-50/50 hover:bg-indigo-100/60 text-left transition-colors"
                >
                  <div className="flex items-center gap-1.5 font-bold text-indigo-900 text-[11px]">
                    <BookOpen className="w-3 h-3 text-indigo-600" />
                    <span>Faculty (Physics)</span>
                  </div>
                  <p className="text-[10px] text-indigo-700 mt-0.5">Assigned Courses</p>
                </button>

                <button
                  type="button"
                  onClick={() => handleQuickLogin('alex.rivera@student.edu', 'StudentPass123!')}
                  className="p-2.5 rounded-xl border border-emerald-200 bg-emerald-50/50 hover:bg-emerald-100/60 text-left transition-colors"
                >
                  <div className="flex items-center gap-1.5 font-bold text-emerald-900 text-[11px]">
                    <UserCheck className="w-3 h-3 text-emerald-600" />
                    <span>Student Profile</span>
                  </div>
                  <p className="text-[10px] text-emerald-700 mt-0.5">View Notes & Roll</p>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
