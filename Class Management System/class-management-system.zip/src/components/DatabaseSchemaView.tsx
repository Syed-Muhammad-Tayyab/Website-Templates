import React, { useState, useEffect } from 'react';
import {
  Database,
  UploadCloud,
  FileCode,
  Table,
  CheckCircle2,
  Trash2,
  RotateCcw,
  Sparkles,
  Copy,
  Check,
  AlertCircle,
  FileSpreadsheet,
  Download,
} from 'lucide-react';
import { api } from '../lib/api.js';

interface DatabaseSchemaViewProps {
  onRefreshAll: () => void;
  onShowToast: (msg: string, type?: 'success' | 'error') => void;
}

export const DatabaseSchemaView: React.FC<DatabaseSchemaViewProps> = ({
  onRefreshAll,
  onShowToast,
}) => {
  const [schemaStats, setSchemaStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [copiedSql, setCopiedSql] = useState(false);

  // Ingestion State
  const [targetEntity, setTargetEntity] = useState<
    'students' | 'subjects' | 'users' | 'announcements' | 'notes'
  >('students');
  const [jsonInput, setJsonInput] = useState('');
  const [ingesting, setIngesting] = useState(false);
  const [ingestSummary, setIngestSummary] = useState<any>(null);

  const loadSchema = async () => {
    try {
      setLoading(true);
      const res = await api.getDatabaseSchema();
      setSchemaStats(res);
    } catch (err: any) {
      onShowToast('Failed to inspect database schema.', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadSchema();
  }, []);

  const handleResetToEmpty = async () => {
    if (
      !window.confirm(
        'WARNING: This will purge all existing data records and reset the database to a clean, empty schema ready for future data ingestion. Proceed?'
      )
    ) {
      return;
    }

    try {
      setLoading(true);
      await api.resetDatabaseToEmpty();
      onShowToast('Database reset to empty schema successfully.');
      await loadSchema();
      onRefreshAll();
    } catch (err: any) {
      onShowToast(err.message || 'Failed to reset database.', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleSeedDemo = async () => {
    try {
      setLoading(true);
      await api.seedDemoData();
      onShowToast('Academic demo dataset loaded successfully.');
      await loadSchema();
      onRefreshAll();
    } catch (err: any) {
      onShowToast(err.message || 'Failed to seed demo data.', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleRunIngestion = async () => {
    if (!jsonInput.trim()) {
      onShowToast('Please provide a JSON array or CSV payload for ingestion.', 'error');
      return;
    }

    try {
      setIngesting(true);
      let parsedData: any[] = [];

      // If JSON format
      if (jsonInput.trim().startsWith('[') || jsonInput.trim().startsWith('{')) {
        const raw = JSON.parse(jsonInput);
        parsedData = Array.isArray(raw) ? raw : [raw];
      } else {
        // Parse CSV format
        const lines = jsonInput.trim().split('\n').filter(Boolean);
        if (lines.length < 2) {
          throw new Error('CSV must contain a header row and at least one data row.');
        }
        const headers = lines[0].split(',').map((h) => h.trim().replace(/^"|"$/g, ''));
        parsedData = lines.slice(1).map((line) => {
          const values = line.split(',').map((v) => v.trim().replace(/^"|"$/g, ''));
          const item: any = {};
          headers.forEach((h, idx) => {
            item[h] = values[idx] ?? '';
          });
          return item;
        });
      }

      const res = await api.ingestData(targetEntity, parsedData);
      setIngestSummary(res);
      onShowToast(`Successfully ingested ${res.insertedCount} ${targetEntity} records!`);
      setJsonInput('');
      await loadSchema();
      onRefreshAll();
    } catch (err: any) {
      onShowToast(err.message || 'Ingestion error. Check format.', 'error');
    } finally {
      setIngesting(false);
    }
  };

  const fillSamplePayload = () => {
    if (targetEntity === 'students') {
      setJsonInput(
        JSON.stringify(
          [
            {
              name: 'Lucas Davenport',
              rollNo: 'STD-2090',
              classId: 'Grade 10-B',
              email: 'lucas.d@student.edu',
              phone: '+1 555-0811',
              guardianName: 'Robert Davenport',
              guardianPhone: '+1 555-0812',
              bloodGroup: 'B+',
              address: '742 Evergreen Terrace',
            },
            {
              name: 'Clara Oswald',
              rollNo: 'STD-2091',
              classId: 'Grade 10-B',
              email: 'clara.o@student.edu',
              phone: '+1 555-0813',
              guardianName: 'George Oswald',
              guardianPhone: '+1 555-0814',
              bloodGroup: 'A-',
              address: '10 Downing Way',
            },
          ],
          null,
          2
        )
      );
    } else if (targetEntity === 'subjects') {
      setJsonInput(
        JSON.stringify(
          [
            {
              code: 'BIO-201',
              name: 'Cellular Biology & Genetics',
              department: 'Life Sciences',
              description: 'Mechanisms of cellular replication, gene editing, and metabolism.',
            },
          ],
          null,
          2
        )
      );
    }
  };

  const handleCopySql = () => {
    if (schemaStats?.sqlSchema) {
      navigator.clipboard.writeText(schemaStats.sqlSchema);
      setCopiedSql(true);
      setTimeout(() => setCopiedSql(false), 2000);
      onShowToast('DDL SQL schema copied to clipboard.');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Database className="w-5 h-5 text-emerald-600" />
            <span>Relational Database Engine & Ingestion Portal</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            11-table schema architecture ready for future institutional ingestion and student profile management.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleSeedDemo}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200 hover:bg-indigo-100 transition-colors shadow-2xs"
          >
            <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
            <span>Load Demo Pack</span>
          </button>

          <button
            onClick={handleResetToEmpty}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold bg-rose-50 text-rose-700 border border-rose-200 hover:bg-rose-100 transition-colors shadow-2xs"
            title="Wipe records and set schema to empty state ready for fresh ingestion"
          >
            <RotateCcw className="w-3.5 h-3.5 text-rose-600" />
            <span>Reset to Empty Schema</span>
          </button>
        </div>
      </div>

      {/* Schema Status Cards */}
      {loading ? (
        <div className="py-16 text-center text-slate-400 text-xs">
          Inspecting database tables and indexes...
        </div>
      ) : (
        <>
          {/* Status Box */}
          <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-2xs">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-600 flex items-center justify-center font-bold">
                  <CheckCircle2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">
                    Database Schema Status: Ready for Ingestion
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Storage engine: Persistent Institutional Datastore &middot; {schemaStats?.tables?.length || 11} relational tables verified
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleCopySql}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors"
                >
                  {copiedSql ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Copied SQL</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy DDL (SQL)</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Table Matrix */}
            <div className="mt-5 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
              {schemaStats?.tables?.map((table: any) => (
                <div
                  key={table.tableName}
                  className="p-3 rounded-xl border border-slate-200 bg-slate-50/60 flex items-center justify-between"
                >
                  <div>
                    <span className="font-mono font-bold text-slate-900 text-xs block">
                      {table.tableName}
                    </span>
                    <span className="text-[10px] text-slate-400">
                      {table.fields?.length || 0} fields
                    </span>
                  </div>
                  <span
                    className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                      table.recordCount > 0
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-slate-200 text-slate-600'
                    }`}
                  >
                    {table.recordCount} rows
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Ingestion Console Section */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-2xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <UploadCloud className="w-4 h-4 text-indigo-600" />
                <h3 className="text-sm font-bold text-slate-900">
                  Data Ingestion Portal (JSON / CSV)
                </h3>
              </div>

              <div className="flex items-center gap-2 text-xs">
                <span className="text-slate-500 font-medium">Target Table:</span>
                <select
                  value={targetEntity}
                  onChange={(e: any) => setTargetEntity(e.target.value)}
                  className="py-1 px-3 rounded-lg border border-slate-200 bg-white font-semibold text-slate-800 focus:outline-hidden focus:border-indigo-500"
                >
                  <option value="students">students (Student Profiles)</option>
                  <option value="subjects">subjects (Curriculum)</option>
                  <option value="users">users (Faculty / Admins)</option>
                  <option value="notes">notes (Study Materials)</option>
                  <option value="announcements">announcements (Bulletins)</option>
                </select>

                <button
                  onClick={fillSamplePayload}
                  className="text-indigo-600 font-semibold text-[11px] hover:underline"
                >
                  Fill Sample
                </button>
              </div>
            </div>

            <p className="text-xs text-slate-500">
              Paste structured JSON array or standard CSV data with column headers matching the table schema. The server will sanitize, validate unique keys, and ingest records into the persistent datastore.
            </p>

            <div>
              <textarea
                rows={7}
                placeholder={`Paste JSON or CSV data here... e.g.:\n[\n  { "name": "Maya Lin", "rollNo": "STD-9901", "classId": "Grade 10-A" }\n]`}
                value={jsonInput}
                onChange={(e) => setJsonInput(e.target.value)}
                className="w-full p-3 font-mono text-xs rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-hidden focus:border-indigo-500"
              ></textarea>
            </div>

            {ingestSummary && (
              <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-800 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>
                    Ingestion successful: <strong>{ingestSummary.insertedCount}</strong> records inserted into <code>{ingestSummary.entity}</code> table.
                  </span>
                </div>
                <button
                  onClick={() => setIngestSummary(null)}
                  className="text-emerald-700 hover:text-emerald-900 font-bold"
                >
                  &times;
                </button>
              </div>
            )}

            <div className="flex items-center justify-end">
              <button
                onClick={handleRunIngestion}
                disabled={ingesting || !jsonInput.trim()}
                className="px-5 py-2.5 rounded-xl font-semibold bg-slate-900 hover:bg-slate-800 text-white shadow-xs transition-colors text-xs flex items-center gap-2"
              >
                <UploadCloud className="w-4 h-4 text-indigo-400" />
                <span>{ingesting ? 'Processing Ingestion...' : 'Execute Data Ingestion'}</span>
              </button>
            </div>
          </div>

          {/* DDL SQL Schema Preview */}
          <div className="bg-slate-900 rounded-2xl p-5 text-white shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <FileCode className="w-4 h-4 text-indigo-400" />
                <h4 className="text-xs font-bold text-slate-200">
                  Relational SQL DDL Definition (`schema.sql`)
                </h4>
              </div>
              <span className="text-[10px] text-slate-400">PostgreSQL / SQLite 3 Standard Compliant</span>
            </div>

            <pre className="max-h-60 overflow-y-auto font-mono text-[11px] text-indigo-200/80 bg-slate-950 p-4 rounded-xl leading-relaxed">
              {schemaStats?.sqlSchema || '-- SQL Schema definition'}
            </pre>
          </div>
        </>
      )}
    </div>
  );
};
