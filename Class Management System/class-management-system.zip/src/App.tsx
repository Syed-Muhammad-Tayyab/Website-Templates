import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar.js';
import { Sidebar, type NavTab } from './components/Sidebar.js';
import { OverviewView } from './components/OverviewView.js';
import { AnnouncementsView } from './components/AnnouncementsView.js';
import { SubjectsView } from './components/SubjectsView.js';
import { NotesView } from './components/NotesView.js';
import { AttendanceView } from './components/AttendanceView.js';
import { StudentsView } from './components/StudentsView.js';
import { AdminView } from './components/AdminView.js';
import { DatabaseSchemaView } from './components/DatabaseSchemaView.js';
import { SettingsView } from './components/SettingsView.js';
import { LoginModal } from './components/LoginModal.js';
import { api } from './lib/api.js';
import type {
  User,
  Subject,
  Announcement,
  Note,
  AttendanceRecord,
  Student,
  UserPermission,
} from './types.js';
import { CheckCircle2, AlertCircle } from 'lucide-react';

export function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [userPermissions, setUserPermissions] = useState<UserPermission[]>([]);
  const [authLoading, setAuthLoading] = useState(true);

  // App Data
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [notes, setNotes] = useState<Note[]>([]);
  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>([]);
  const [students, setStudents] = useState<Student[]>([]);
  const [currentTab, setCurrentTab] = useState<NavTab>('overview');
  const [schoolName, setSchoolName] = useState('Saint Jude Academy & Technological Institute');

  // Toast Notification
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

  const showToast = (message: string, type: 'success' | 'error' = 'success') => {
    setToast({ message, type });
    setTimeout(() => {
      setToast(null);
    }, 3500);
  };

  // Check current session
  const checkAuth = async () => {
    try {
      setAuthLoading(true);
      const authRes = await api.getMe();
      if (authRes && authRes.user) {
        setCurrentUser(authRes.user);
        const perms = authRes.permissions || (await api.getUserPermissions(authRes.user.id));
        setUserPermissions(perms);
        await loadAllData();
      } else {
        setCurrentUser(null);
      }
    } catch (err) {
      setCurrentUser(null);
    } finally {
      setAuthLoading(false);
    }
  };

  const loadAllData = async () => {
    try {
      const [subs, anns, nts, atts, stds] = await Promise.all([
        api.getSubjects().catch(() => []),
        api.getAnnouncements().catch(() => []),
        api.getNotes().catch(() => []),
        api.getAttendance().catch(() => []),
        api.getStudents().catch(() => []),
      ]);
      setSubjects(subs);
      setAnnouncements(anns);
      setNotes(nts);
      setAttendanceRecords(atts);
      setStudents(stds);
    } catch (err) {
      console.error('Error fetching data:', err);
    }
  };

  useEffect(() => {
    checkAuth();
  }, []);

  const handleLogout = async () => {
    try {
      await api.logout();
      setCurrentUser(null);
      setUserPermissions([]);
      showToast('You have been logged out.');
    } catch (err) {
      setCurrentUser(null);
    }
  };

  const handleQuickSwitch = async (targetEmail: string) => {
    const passwordMap: Record<string, string> = {
      'admin@school.edu': 'AdminPass123!',
      'sarah.jenkins@school.edu': 'TeacherPass123!',
      'marcus.vance@school.edu': 'TeacherPass123!',
      'alex.rivera@student.edu': 'StudentPass123!',
    };
    const pass = passwordMap[targetEmail] || 'Password123!';
    try {
      const res = await api.login(targetEmail, pass);
      setCurrentUser(res.user);
      const perms = await api.getUserPermissions(res.user.id);
      setUserPermissions(perms);
      await loadAllData();
      setCurrentTab('overview');
      showToast(`Switched account to ${res.user.name} (${res.user.role.replace('_', ' ')})`);
    } catch (err: any) {
      showToast(err.message || 'Failed to switch user.', 'error');
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center text-white text-xs">
        <div className="flex flex-col items-center gap-3">
          <div className="w-8 h-8 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
          <span className="text-slate-400">Loading institutional workspace...</span>
        </div>
      </div>
    );
  }

  if (!currentUser) {
    return (
      <LoginModal
        onLoginSuccess={async (user) => {
          setCurrentUser(user);
          const perms = await api.getUserPermissions(user.id);
          setUserPermissions(perms);
          await loadAllData();
        }}
        onShowToast={showToast}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans selection:bg-indigo-500 selection:text-white">
      {/* Top Navigation */}
      <Navbar
        currentUser={currentUser}
        onLogout={handleLogout}
        onQuickSwitch={handleQuickSwitch}
        onOpenSettings={() => setCurrentTab('settings')}
        onOpenDatabase={() => setCurrentTab('database')}
        schoolName={schoolName}
      />

      {/* Main Body */}
      <div className="flex-1 w-full max-w-7xl mx-auto flex flex-col lg:flex-row">
        {/* Sidebar */}
        <Sidebar
          currentTab={currentTab}
          onSelectTab={setCurrentTab}
          currentUser={currentUser}
          permissions={userPermissions}
        />

        {/* Viewport Area */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 min-w-0 overflow-x-hidden">
          {currentTab === 'overview' && (
            <OverviewView
              currentUser={currentUser}
              subjects={subjects}
              announcements={announcements}
              notes={notes}
              students={students}
              attendanceRecords={attendanceRecords}
              onNavigate={(tab) => setCurrentTab(tab)}
              onOpenIngest={() => setCurrentTab('database')}
              onSeedDemo={async () => {
                try {
                  await api.seedDemoData();
                  showToast('Demo dataset initialized.');
                  await loadAllData();
                } catch (err: any) {
                  showToast(err.message || 'Error seeding demo data', 'error');
                }
              }}
            />
          )}

          {currentTab === 'announcements' && (
            <AnnouncementsView
              announcements={announcements}
              currentUser={currentUser}
              onRefresh={loadAllData}
              onShowToast={showToast}
            />
          )}

          {currentTab === 'subjects' && (
            <SubjectsView
              subjects={subjects}
              currentUser={currentUser}
              onRefresh={loadAllData}
              onShowToast={showToast}
            />
          )}

          {currentTab === 'notes' && (
            <NotesView
              notes={notes}
              subjects={subjects}
              currentUser={currentUser}
              onRefresh={loadAllData}
              onShowToast={showToast}
            />
          )}

          {currentTab === 'attendance' && (
            <AttendanceView
              attendanceRecords={attendanceRecords}
              subjects={subjects}
              students={students}
              currentUser={currentUser}
              onRefresh={loadAllData}
              onShowToast={showToast}
            />
          )}

          {currentTab === 'students' && (
            <StudentsView
              students={students}
              subjects={subjects}
              currentUser={currentUser}
              onRefresh={loadAllData}
              onShowToast={showToast}
            />
          )}

          {currentTab === 'admin' && currentUser.role === 'main_admin' && (
            <AdminView
              currentUser={currentUser}
              subjects={subjects}
              onShowToast={showToast}
            />
          )}

          {currentTab === 'database' && (
            <DatabaseSchemaView
              onRefreshAll={loadAllData}
              onShowToast={showToast}
            />
          )}

          {currentTab === 'settings' && (
            <SettingsView
              currentUser={currentUser}
              onRefreshUser={(user) => setCurrentUser(user)}
              onShowToast={showToast}
              schoolName={schoolName}
              onUpdateSchoolName={setSchoolName}
            />
          )}
        </main>
      </div>

      {/* Floating Toast Notification */}
      {toast && (
        <div className="fixed bottom-5 right-5 z-50 animate-in slide-in-from-bottom-3 duration-200">
          <div
            className={`px-4 py-3 rounded-2xl shadow-xl border flex items-center gap-2.5 text-xs font-semibold ${
              toast.type === 'error'
                ? 'bg-rose-900 text-white border-rose-800'
                : 'bg-slate-900 text-white border-slate-800'
            }`}
          >
            {toast.type === 'error' ? (
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            ) : (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            )}
            <span>{toast.message}</span>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
