import type {
  User,
  UserPermission,
  Subject,
  ClassRecord,
  Note,
  Announcement,
  AttendanceRecord,
  Student,
  AuditLog,
  SystemSettings,
  SchemaTableDefinition,
} from '../types.js';

const TOKEN_KEY = 'cms_auth_token';

export function getStoredToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function setStoredToken(token: string | null) {
  if (token) {
    localStorage.setItem(TOKEN_KEY, token);
  } else {
    localStorage.removeItem(TOKEN_KEY);
  }
}

async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const token = getStoredToken();
  const headers = new Headers(options.headers || {});

  if (token && !headers.has('Authorization')) {
    headers.set('Authorization', `Bearer ${token}`);
  }

  if (!headers.has('Content-Type') && !(options.body instanceof FormData)) {
    headers.set('Content-Type', 'application/json');
  }

  const response = await fetch(endpoint, {
    ...options,
    headers,
  });

  if (!response.ok) {
    let errorMsg = `HTTP Error ${response.status}`;
    try {
      const json = await response.json();
      errorMsg = json.error || json.message || errorMsg;
    } catch {
      // ignore
    }
    throw new Error(errorMsg);
  }

  // Handle CSV/text downloads
  const contentType = response.headers.get('content-type');
  if (contentType && contentType.includes('text/csv')) {
    return (await response.text()) as unknown as T;
  }

  return response.json() as Promise<T>;
}

export const api = {
  // Auth
  async login(email: string, password: string) {
    const data = await request<{ token: string; user: User; permissions: UserPermission[] }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
    setStoredToken(data.token);
    return data;
  },

  async logout() {
    try {
      await request('/api/auth/logout', { method: 'POST' });
    } finally {
      setStoredToken(null);
    }
  },

  async getMe() {
    return request<{ user: User; permissions: UserPermission[] }>('/api/auth/me');
  },

  async updateProfile(data: { name?: string; email?: string; phone?: string; profileImage?: string }) {
    return request<User>('/api/auth/profile', {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  },

  async changePassword(
    currentPasswordOrPayload: string | { currentPassword: string; newPassword: string; confirmAdminKey?: boolean },
    newPassword?: string,
    confirmAdminKey = true
  ) {
    const payload =
      typeof currentPasswordOrPayload === 'string'
        ? { currentPassword: currentPasswordOrPayload, newPassword: newPassword || '', confirmAdminKey }
        : currentPasswordOrPayload;

    return request<{ success: boolean; message: string }>('/api/auth/change-password', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  async initAdmin(data: { name: string; email: string; password: string; phone?: string }) {
    const res = await request<{ token: string; user: User; permissions: UserPermission[] }>('/api/auth/init-admin', {
      method: 'POST',
      body: JSON.stringify(data),
    });
    setStoredToken(res.token);
    return res;
  },

  // Users & Permissions
  async getUsers() {
    return request<User[]>('/api/users');
  },

  async createUser(data: any) {
    return request<User>('/api/users', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  async updateUser(id: string, data: any) {
    return request<User>(`/api/users/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  },

  async deleteUser(id: string) {
    return request<{ success: boolean }>(`/api/users/${id}`, {
      method: 'DELETE',
    });
  },

  async getUserPermissions(userId: string) {
    return request<UserPermission[]>(`/api/users/${userId}/permissions`);
  },

  async setUserPermissions(userId: string, permissions: Omit<UserPermission, 'id' | 'userId'>[]) {
    return request<UserPermission[]>(`/api/users/${userId}/permissions`, {
      method: 'POST',
      body: JSON.stringify({ permissions }),
    });
  },

  async updateUserPermissions(userId: string, permissions: Omit<UserPermission, 'id' | 'userId'>[]) {
    return this.setUserPermissions(userId, permissions);
  },

  // Subjects
  async getSubjects() {
    return request<Subject[]>('/api/subjects');
  },

  async getSubject(id: string) {
    return request<Subject & { teachers: User[]; notes: Note[]; classRecords: ClassRecord[] }>(`/api/subjects/${id}`);
  },

  async createSubject(data: any) {
    return request<Subject>('/api/subjects', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  async updateSubject(id: string, data: any) {
    return request<Subject>(`/api/subjects/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  },

  async deleteSubject(id: string) {
    return request<{ success: boolean }>(`/api/subjects/${id}`, {
      method: 'DELETE',
    });
  },

  // Class Records (Academic Logs)
  async getClassRecords(subjectId?: string) {
    const q = subjectId ? `?subjectId=${subjectId}` : '';
    return request<ClassRecord[]>(`/api/subjects/${subjectId}/records${q}`);
  },

  async createClassRecord(subjectId: string, data: { date: string; topicCovered: string; notes?: string }) {
    return request<ClassRecord>(`/api/subjects/${subjectId}/records`, {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  async deleteClassRecord(id: string) {
    return request<{ success: boolean }>(`/api/class-records/${id}`, {
      method: 'DELETE',
    });
  },

  // Notes
  async getNotes(params?: { subjectId?: string; search?: string }) {
    const q = new URLSearchParams();
    if (params?.subjectId) q.set('subjectId', params.subjectId);
    if (params?.search) q.set('search', params.search);
    return request<Note[]>(`/api/notes?${q.toString()}`);
  },

  async createNote(data: any) {
    return request<Note>('/api/notes', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  async updateNote(id: string, data: any) {
    return request<Note>(`/api/notes/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  },

  async deleteNote(id: string) {
    return request<{ success: boolean }>(`/api/notes/${id}`, {
      method: 'DELETE',
    });
  },

  // Announcements
  async getAnnouncements(search?: string) {
    const q = search ? `?search=${encodeURIComponent(search)}` : '';
    return request<Announcement[]>(`/api/announcements${q}`);
  },

  async createAnnouncement(data: any) {
    return request<Announcement>('/api/announcements', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  async deleteAnnouncement(id: string) {
    return request<{ success: boolean }>(`/api/announcements/${id}`, {
      method: 'DELETE',
    });
  },

  // Attendance
  async getAttendance(params?: { subjectId?: string; date?: string; studentId?: string }) {
    const q = new URLSearchParams();
    if (params?.subjectId) q.set('subjectId', params.subjectId);
    if (params?.date) q.set('date', params.date);
    if (params?.studentId) q.set('studentId', params.studentId);
    return request<AttendanceRecord[]>(`/api/attendance?${q.toString()}`);
  },

  async markAttendance(records: { studentId: string; subjectId: string; date: string; status: string }[]) {
    return request<{ success: boolean; count: number }>('/api/attendance/mark', {
      method: 'POST',
      body: JSON.stringify({ records }),
    });
  },

  async getAttendanceStats() {
    return request<{
      overallPercentage: number;
      totalRecords: number;
      studentStats: any[];
      subjectStats: any[];
    }>('/api/attendance/stats');
  },

  async exportAttendance() {
    return request<string>('/api/attendance/export');
  },

  // Students
  async getStudents(search?: string) {
    const q = search ? `?search=${encodeURIComponent(search)}` : '';
    return request<Student[]>(`/api/students${q}`);
  },

  async getStudent(id: string) {
    return request<Student & { attendance: AttendanceRecord[]; subjects: Subject[] }>(`/api/students/${id}`);
  },

  async createStudent(data: any) {
    return request<Student>('/api/students', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  async updateStudent(id: string, data: any) {
    return request<Student>(`/api/students/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  },

  async deleteStudent(id: string) {
    return request<{ success: boolean }>(`/api/students/${id}`, {
      method: 'DELETE',
    });
  },

  // Audit Logs
  async getAuditLogs(limit = 100) {
    return request<AuditLog[]>(`/api/audit-logs?limit=${limit}`);
  },

  // Database Management
  async getDatabaseSchema() {
    return request<SchemaTableDefinition[]>('/api/database/schema');
  },

  async exportSqlDDL() {
    const token = getStoredToken();
    const res = await fetch('/api/database/export-ddl', {
      headers: token ? { Authorization: `Bearer ${token}` } : {},
    });
    return res.text();
  },

  async ingestData(table: string, records: any[]) {
    return request<{ success: boolean; message: string; insertedCount: number; table: string }>('/api/database/ingest', {
      method: 'POST',
      body: JSON.stringify({ table, records }),
    });
  },

  async seedDemoData() {
    return request<{ success: boolean; message: string }>('/api/database/seed-demo', {
      method: 'POST',
    });
  },

  async resetEmptyDatabase(keepAdmin = true) {
    return request<{ success: boolean; message: string }>('/api/database/reset-empty', {
      method: 'POST',
      body: JSON.stringify({ keepAdmin }),
    });
  },

  async resetDatabaseToEmpty(keepAdmin = true) {
    return this.resetEmptyDatabase(keepAdmin);
  },

  // System Settings
  async getSettings() {
    return request<SystemSettings>('/api/settings');
  },

  async updateSettings(data: Partial<SystemSettings>) {
    return request<SystemSettings>('/api/settings', {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  },

  // File Upload
  async uploadFile(file: File) {
    const formData = new FormData();
    formData.append('file', file);
    return request<{ url: string; fileName: string; fileSize: string; mimeType: string }>('/api/upload', {
      method: 'POST',
      body: formData,
    });
  },
};
