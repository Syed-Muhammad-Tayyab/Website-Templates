import crypto from 'crypto';
import type { Request, Response, NextFunction } from 'express';
import bcrypt from 'bcryptjs';
import { db } from './db.js';
import type { User, UserRole } from '../src/types.js';

export interface AuthenticatedUser extends User {
  token: string;
}

declare global {
  namespace Express {
    interface Request {
      user?: AuthenticatedUser;
    }
  }
}

interface Session {
  token: string;
  userId: string;
  expiresAt: number;
}

// In-memory token sessions
const sessions = new Map<string, Session>();
// Rate limiting tracker: IP -> { count, resetTime }
const rateLimitMap = new Map<string, { count: number; resetTime: number }>();

const SESSION_TTL_MS = 24 * 60 * 60 * 1000; // 24 hours

export function createSession(userId: string): string {
  const token = crypto.randomBytes(32).toString('hex');
  sessions.set(token, {
    token,
    userId,
    expiresAt: Date.now() + SESSION_TTL_MS,
  });
  return token;
}

export function removeSession(token: string): boolean {
  return sessions.delete(token);
}

export function getSessionUser(token: string): AuthenticatedUser | null {
  const session = sessions.get(token);
  if (!session) return null;
  if (Date.now() > session.expiresAt) {
    sessions.delete(token);
    return null;
  }
  const user = db.findUserById(session.userId);
  if (!user || user.status === 'inactive') return null;
  const { passwordHash: _, ...safeUser } = user;
  return { ...safeUser, token };
}

// Rate Limiter Middleware
export function rateLimiter(maxAttempts = 15, windowMs = 60 * 1000) {
  return (req: Request, res: Response, next: NextFunction) => {
    const ip = req.ip || req.socket.remoteAddress || '127.0.0.1';
    const now = Date.now();
    const entry = rateLimitMap.get(ip);

    if (!entry || now > entry.resetTime) {
      rateLimitMap.set(ip, { count: 1, resetTime: now + windowMs });
      return next();
    }

    if (entry.count >= maxAttempts) {
      return res.status(429).json({
        error: 'Too many authentication attempts. Please try again after 60 seconds.',
        retryAfter: Math.ceil((entry.resetTime - now) / 1000),
      });
    }

    entry.count++;
    next();
  };
}

// Authentication Middleware
export function requireAuth(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization || req.headers['x-auth-token'];
  if (!authHeader) {
    return res.status(401).json({ error: 'Authentication required: missing token.' });
  }

  const token = typeof authHeader === 'string' && authHeader.startsWith('Bearer ')
    ? authHeader.slice(7)
    : String(authHeader);

  const user = getSessionUser(token);
  if (!user) {
    return res.status(401).json({ error: 'Session expired or invalid token. Please log in again.' });
  }

  req.user = user;
  next();
}

// Role Middleware
export function requireRole(allowedRoles: UserRole[]) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Unauthorized.' });
    }
    if (req.user.role === 'main_admin' || allowedRoles.includes(req.user.role)) {
      return next();
    }
    return res.status(403).json({
      error: `Access denied. Requires one of roles: ${allowedRoles.join(', ')}.`,
    });
  };
}

// Granular Permission Middleware
export function checkPermission(
  section: 'announcements' | 'subjects' | 'notes' | 'attendance' | 'students' | 'admin',
  action: 'read' | 'create' | 'edit' | 'delete' = 'read',
  getSubjectId?: (req: Request) => string | undefined
) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Unauthorized.' });
    }

    // Main Admin has unrestricted bypass on all resources
    if (req.user.role === 'main_admin') {
      return next();
    }

    const perms = db.getUserPermissions(req.user.id);
    const subjectId = getSubjectId ? getSubjectId(req) : req.params.subjectId || req.query.subjectId as string | undefined;

    // Look for matching permission
    const match = perms.find((p) => {
      if (p.section !== section) return false;
      if (subjectId && p.subjectId && p.subjectId !== subjectId) return false;
      return true;
    });

    if (!match) {
      // Teachers have default read access to announcements and general subjects unless explicitly restricted
      if (action === 'read' && (section === 'announcements' || section === 'subjects' || section === 'students')) {
        return next();
      }
      return res.status(403).json({
        error: `Permission denied: User does not have access to ${section} (${action}).`,
      });
    }

    let allowed = false;
    if (action === 'read') allowed = match.canRead;
    else if (action === 'create') allowed = match.canCreate;
    else if (action === 'edit') allowed = match.canEdit;
    else if (action === 'delete') allowed = match.canDelete;

    if (!allowed) {
      return res.status(403).json({
        error: `Action forbidden: ${action.toUpperCase()} not allowed on ${section} for your user permissions.`,
      });
    }

    next();
  };
}
