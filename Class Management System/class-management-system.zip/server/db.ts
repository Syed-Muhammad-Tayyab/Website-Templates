import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import bcrypt from 'bcryptjs';
import type {
  User,
  UserPermission,
  Subject,
  ClassRecord,
  Note,
  Announcement,
  AttendanceRecord,
  Student,
  AuditLog,
  SystemSettings,
  SchemaTableDefinition,
} from '../src/types.js';

interface UserRecord extends User {
  passwordHash: string;
}

interface DatabaseSchema {
  users: UserRecord[];
  user_permissions: UserPermission[];
  subjects: Subject[];
  class_records: ClassRecord[];
  notes: Note[];
  announcements: Announcement[];
  attendance: AttendanceRecord[];
  students: Student[];
  audit_logs: AuditLog[];
  system_settings: SystemSettings;
}

const DATA_DIR = path.join(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'database.json');
const UPLOADS_DIR = path.join(process.cwd(), 'uploads');

// Ensure directories exist
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

const DEFAULT_SETTINGS: SystemSettings = {
  schoolName: 'Apex Collegiate Institute',
  schoolTagline: 'Class Management & Academic Governance System',
  academicTerm: 'Fall 2026 / Term 1',
  allowStudentRegistration: false,
  theme: 'light',
  customAnnouncementBanner: 'Welcome to the new academic session. All schedules have been published.',
};

function getEmptyDatabase(): DatabaseSchema {
  return {
    users: [],
    user_permissions: [],
    subjects: [],
    class_records: [],
    notes: [],
    announcements: [],
    attendance: [],
    students: [],
    audit_logs: [],
    system_settings: { ...DEFAULT_SETTINGS },
  };
}

class Database {
  private data: DatabaseSchema;

  constructor() {
    this.data = this.load();
    if (this.data.users.length === 0) {
      // Auto-provision initial Main Admin if none exists so administrator can authenticate
      this.initDefaultAdmin();
    }
  }

  private load(): DatabaseSchema {
    try {
      if (fs.existsSync(DB_FILE)) {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        return JSON.parse(raw);
      }
    } catch (err) {
      console.error('Error reading database file, initializing empty:', err);
    }
    const empty = getEmptyDatabase();
    this.save(empty);
    return empty;
  }

  private save(dataToSave?: DatabaseSchema) {
    try {
      const payload = dataToSave || this.data;
      fs.writeFileSync(DB_FILE, JSON.stringify(payload, null, 2), 'utf-8');
    } catch (err) {
      console.error('Error saving database:', err);
    }
  }

  private initDefaultAdmin() {
    const adminId = 'usr_admin_001';
    const passwordHash = bcrypt.hashSync('Admin@123456', 10);
    const mainAdmin: UserRecord = {
      id: adminId,
      name: 'System Main Admin',
      email: 'admin@school.edu',
      role: 'main_admin',
      status: 'active',
      profileImage: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
      phone: '+1 (555) 019-2831',
      passwordHash,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    this.data.users.push(mainAdmin);

    // Initial audit log
    this.data.audit_logs.unshift({
      id: 'log_' + crypto.randomUUID().slice(0, 8),
      userId: adminId,
      userName: 'System Initialization',
      userRole: 'main_admin',
      action: 'SYSTEM_BOOTSTRAP',
      entityType: 'database',
      entityId: 'schema_v1',
      details: 'Initialized empty database schema ready for data ingestion and user profile management.',
      timestamp: new Date().toISOString(),
    });

    this.save();
  }

  // Schema and metadata inspection
  public getSchemaDefinitions(): SchemaTableDefinition[] {
    return [
      {
        name: 'users',
        description: 'System user accounts, credentials hashes, roles, and profile information',
        rowCount: this.data.users.length,
        columns: [
          { name: 'id', type: 'VARCHAR(36)', primaryKey: true, description: 'Unique user identifier' },
          { name: 'name', type: 'VARCHAR(120)', description: 'Full name' },
          { name: 'email', type: 'VARCHAR(180)', description: 'Unique email address / username' },
          { name: 'role', type: 'VARCHAR(20)', description: 'Role: main_admin | teacher | student' },
          { name: 'status', type: 'VARCHAR(20)', description: 'Account status: active | inactive' },
          { name: 'password_hash', type: 'VARCHAR(255)', description: 'Bcrypt salted password hash' },
          { name: 'profile_image', type: 'TEXT', nullable: true, description: 'Avatar URL or file path' },
          { name: 'phone', type: 'VARCHAR(30)', nullable: true, description: 'Contact phone' },
          { name: 'created_at', type: 'TIMESTAMP', description: 'Account creation date' },
        ],
      },
      {
        name: 'user_permissions',
        description: 'Granular Access Control List (ACL) mapping user to sections and subject resources',
        rowCount: this.data.user_permissions.length,
        columns: [
          { name: 'id', type: 'VARCHAR(36)', primaryKey: true, description: 'Permission rule ID' },
          { name: 'user_id', type: 'VARCHAR(36)', foreignKey: 'users.id', description: 'Target user ID' },
          { name: 'section', type: 'VARCHAR(40)', description: 'Section: announcements | subjects | notes | attendance | students' },
          { name: 'subject_id', type: 'VARCHAR(36)', foreignKey: 'subjects.id', nullable: true, description: 'Specific subject scope or NULL for all' },
          { name: 'can_read', type: 'BOOLEAN', description: 'Read/view permission' },
          { name: 'can_create', type: 'BOOLEAN', description: 'Create/post permission' },
          { name: 'can_edit', type: 'BOOLEAN', description: 'Update/modify permission' },
          { name: 'can_delete', type: 'BOOLEAN', description: 'Deletion permission' },
        ],
      },
      {
        name: 'subjects',
        description: 'Academic courses/subjects with syllabus details, department, and media',
        rowCount: this.data.subjects.length,
        columns: [
          { name: 'id', type: 'VARCHAR(36)', primaryKey: true, description: 'Subject ID' },
          { name: 'name', type: 'VARCHAR(150)', description: 'Course name' },
          { name: 'code', type: 'VARCHAR(30)', description: 'Course code (e.g. CS101, MTH204)' },
          { name: 'department', type: 'VARCHAR(100)', nullable: true, description: 'Academic department' },
          { name: 'description', type: 'TEXT', description: 'Syllabus and description' },
          { name: 'thumbnail', type: 'TEXT', nullable: true, description: 'Course thumbnail image' },
          { name: 'file_path', type: 'TEXT', nullable: true, description: 'Attached syllabus file' },
          { name: 'created_at', type: 'TIMESTAMP', description: 'Creation date' },
        ],
      },
      {
        name: 'class_records',
        description: 'Academic class logs recording date, topic covered, and what was taught',
        rowCount: this.data.class_records.length,
        columns: [
          { name: 'id', type: 'VARCHAR(36)', primaryKey: true, description: 'Record ID' },
          { name: 'subject_id', type: 'VARCHAR(36)', foreignKey: 'subjects.id', description: 'Subject course' },
          { name: 'teacher_id', type: 'VARCHAR(36)', foreignKey: 'users.id', description: 'Teacher who conducted class' },
          { name: 'date', type: 'DATE', description: 'Class date' },
          { name: 'topic_covered', type: 'VARCHAR(255)', description: 'Topic or lesson title' },
          { name: 'notes', type: 'TEXT', description: 'Notes taught & homework summary' },
          { name: 'created_at', type: 'TIMESTAMP', description: 'Logged timestamp' },
        ],
      },
      {
        name: 'notes',
        description: 'Subject study materials and notes with file attachments',
        rowCount: this.data.notes.length,
        columns: [
          { name: 'id', type: 'VARCHAR(36)', primaryKey: true, description: 'Note ID' },
          { name: 'subject_id', type: 'VARCHAR(36)', foreignKey: 'subjects.id', description: 'Associated course' },
          { name: 'title', type: 'VARCHAR(200)', description: 'Note title' },
          { name: 'content', type: 'TEXT', description: 'Study notes markdown / body' },
          { name: 'file_path', type: 'TEXT', nullable: true, description: 'Attachment file URL / path' },
          { name: 'file_name', type: 'VARCHAR(255)', nullable: true, description: 'Original file name' },
          { name: 'created_by', type: 'VARCHAR(36)', foreignKey: 'users.id', description: 'Uploader user' },
          { name: 'created_at', type: 'TIMESTAMP', description: 'Creation date' },
        ],
      },
      {
        name: 'announcements',
        description: 'School-wide and departmental notices with attachments and priority',
        rowCount: this.data.announcements.length,
        columns: [
          { name: 'id', type: 'VARCHAR(36)', primaryKey: true, description: 'Notice ID' },
          { name: 'title', type: 'VARCHAR(255)', description: 'Notice headline' },
          { name: 'description', type: 'TEXT', description: 'Announcement body' },
          { name: 'priority', type: 'VARCHAR(20)', description: 'Priority: normal | important | urgent' },
          { name: 'thumbnail', type: 'TEXT', nullable: true, description: 'Banner image' },
          { name: 'file_path', type: 'TEXT', nullable: true, description: 'Attachment doc/PDF/sheet' },
          { name: 'posted_by', type: 'VARCHAR(36)', foreignKey: 'users.id', description: 'Author' },
          { name: 'created_at', type: 'TIMESTAMP', description: 'Posted timestamp' },
        ],
      },
      {
        name: 'students',
        description: 'Student profiles, registration roll numbers, class IDs, and enrollments',
        rowCount: this.data.students.length,
        columns: [
          { name: 'id', type: 'VARCHAR(36)', primaryKey: true, description: 'Student record ID' },
          { name: 'user_id', type: 'VARCHAR(36)', foreignKey: 'users.id', nullable: true, description: 'Associated login account' },
          { name: 'name', type: 'VARCHAR(120)', description: 'Full name' },
          { name: 'roll_no', type: 'VARCHAR(40)', description: 'Official Roll / Matriculation Number' },
          { name: 'email', type: 'VARCHAR(180)', description: 'Student email' },
          { name: 'phone', type: 'VARCHAR(30)', nullable: true, description: 'Emergency contact' },
          { name: 'class_id', type: 'VARCHAR(50)', description: 'Assigned Grade/Cohort' },
          { name: 'section', type: 'VARCHAR(20)', nullable: true, description: 'Section (e.g. A, B)' },
          { name: 'enrolled_subject_ids', type: 'JSONB', description: 'List of subject IDs enrolled' },
          { name: 'created_at', type: 'TIMESTAMP', description: 'Enrollment timestamp' },
        ],
      },
      {
        name: 'attendance',
        description: 'Daily subject attendance logs with statuses (present, absent, late, excused)',
        rowCount: this.data.attendance.length,
        columns: [
          { name: 'id', type: 'VARCHAR(36)', primaryKey: true, description: 'Attendance entry ID' },
          { name: 'student_id', type: 'VARCHAR(36)', foreignKey: 'students.id', description: 'Target student' },
          { name: 'subject_id', type: 'VARCHAR(36)', foreignKey: 'subjects.id', description: 'Course' },
          { name: 'date', type: 'DATE', description: 'Session date' },
          { name: 'status', type: 'VARCHAR(20)', description: 'Status: present | absent | late | excused' },
          { name: 'marked_by', type: 'VARCHAR(36)', foreignKey: 'users.id', description: 'Instructor/Admin who recorded' },
          { name: 'created_at', type: 'TIMESTAMP', description: 'Entry timestamp' },
        ],
      },
      {
        name: 'audit_logs',
        description: 'Complete immutable security trail of all administrative and data modifications',
        rowCount: this.data.audit_logs.length,
        columns: [
          { name: 'id', type: 'VARCHAR(36)', primaryKey: true, description: 'Log ID' },
          { name: 'user_id', type: 'VARCHAR(36)', foreignKey: 'users.id', nullable: true, description: 'Actor user ID' },
          { name: 'user_name', type: 'VARCHAR(120)', description: 'Actor full name' },
          { name: 'user_role', type: 'VARCHAR(20)', description: 'Actor role' },
          { name: 'action', type: 'VARCHAR(100)', description: 'Action code' },
          { name: 'entity_type', type: 'VARCHAR(50)', description: 'Entity affected' },
          { name: 'entity_id', type: 'VARCHAR(36)', nullable: true, description: 'Resource ID' },
          { name: 'details', type: 'TEXT', nullable: true, description: 'Detailed context' },
          { name: 'timestamp', type: 'TIMESTAMP', description: 'Event time' },
        ],
      },
      {
        name: 'system_settings',
        description: 'System-wide configuration, branding, and academic term settings',
        rowCount: 1,
        columns: [
          { name: 'school_name', type: 'VARCHAR(150)', description: 'Institution name' },
          { name: 'school_tagline', type: 'VARCHAR(255)', description: 'System subtitle / tagline' },
          { name: 'academic_term', type: 'VARCHAR(100)', description: 'Current active term' },
          { name: 'theme', type: 'VARCHAR(20)', description: 'UI theme mode' },
        ],
      },
    ];
  }

  // Audit Logging
  public logAudit(
    userId: string,
    userName: string,
    userRole: string,
    action: string,
    entityType: string,
    entityId?: string,
    details?: string,
    ipAddress?: string
  ) {
    const log: AuditLog = {
      id: 'log_' + crypto.randomUUID().slice(0, 8),
      userId,
      userName,
      userRole,
      action,
      entityType,
      entityId,
      details,
      ipAddress,
      timestamp: new Date().toISOString(),
    };
    this.data.audit_logs.unshift(log);
    // Keep max 500 logs
    if (this.data.audit_logs.length > 500) {
      this.data.audit_logs = this.data.audit_logs.slice(0, 500);
    }
    this.save();
    return log;
  }

  public getAuditLogs(limit = 100): AuditLog[] {
    return this.data.audit_logs.slice(0, limit);
  }

  // Users CRUD
  public getUsers(): User[] {
    return this.data.users.map(({ passwordHash, ...rest }) => rest);
  }

  public findUserById(id: string): UserRecord | undefined {
    return this.data.users.find((u) => u.id === id);
  }

  public findUserByEmail(email: string): UserRecord | undefined {
    return this.data.users.find((u) => u.email.toLowerCase() === email.toLowerCase());
  }

  public createUser(userData: {
    name: string;
    email: string;
    role: 'main_admin' | 'teacher' | 'student';
    password: string;
    phone?: string;
    profileImage?: string;
    status?: 'active' | 'inactive';
  }): User {
    const id = 'usr_' + crypto.randomUUID().slice(0, 8);
    const passwordHash = bcrypt.hashSync(userData.password, 10);
    const user: UserRecord = {
      id,
      name: userData.name,
      email: userData.email.toLowerCase(),
      role: userData.role,
      status: userData.status || 'active',
      profileImage: userData.profileImage || '',
      phone: userData.phone || '',
      passwordHash,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    this.data.users.push(user);
    this.save();
    const { passwordHash: _, ...safeUser } = user;
    return safeUser;
  }

  public updateUser(
    id: string,
    updates: Partial<User> & { password?: string }
  ): User | null {
    const index = this.data.users.findIndex((u) => u.id === id);
    if (index === -1) return null;

    const user = this.data.users[index];
    if (updates.name) user.name = updates.name;
    if (updates.email) user.email = updates.email.toLowerCase();
    if (updates.role) user.role = updates.role;
    if (updates.status) user.status = updates.status;
    if (updates.phone !== undefined) user.phone = updates.phone;
    if (updates.profileImage !== undefined) user.profileImage = updates.profileImage;
    if (updates.password) {
      user.passwordHash = bcrypt.hashSync(updates.password, 10);
    }
    user.updatedAt = new Date().toISOString();
    this.data.users[index] = user;
    this.save();
    const { passwordHash: _, ...safeUser } = user;
    return safeUser;
  }

  public deleteUser(id: string): boolean {
    const user = this.findUserById(id);
    if (!user) return false;
    // Protect Main Admin
    if (user.role === 'main_admin' && this.data.users.filter((u) => u.role === 'main_admin').length <= 1) {
      throw new Error('Cannot delete the primary Main Admin account.');
    }
    this.data.users = this.data.users.filter((u) => u.id !== id);
    this.data.user_permissions = this.data.user_permissions.filter((p) => p.userId !== id);
    this.save();
    return true;
  }

  // Permissions
  public getUserPermissions(userId: string): UserPermission[] {
    return this.data.user_permissions.filter((p) => p.userId === userId);
  }

  public getAllPermissions(): UserPermission[] {
    return this.data.user_permissions;
  }

  public setUserPermissions(userId: string, permissions: Omit<UserPermission, 'id' | 'userId'>[]): UserPermission[] {
    // Remove old permissions for this user
    this.data.user_permissions = this.data.user_permissions.filter((p) => p.userId !== userId);
    const newPerms: UserPermission[] = permissions.map((p) => ({
      id: 'perm_' + crypto.randomUUID().slice(0, 8),
      userId,
      subjectId: p.subjectId || null,
      section: p.section,
      canRead: p.canRead ?? true,
      canCreate: p.canCreate ?? false,
      canEdit: p.canEdit ?? false,
      canDelete: p.canDelete ?? false,
    }));
    this.data.user_permissions.push(...newPerms);
    this.save();
    return newPerms;
  }

  // Subjects
  public getSubjects(): Subject[] {
    return this.data.subjects;
  }

  public getSubjectById(id: string): Subject | undefined {
    return this.data.subjects.find((s) => s.id === id);
  }

  public createSubject(data: Omit<Subject, 'id' | 'createdAt'>): Subject {
    const id = 'sub_' + crypto.randomUUID().slice(0, 8);
    const subject: Subject = {
      ...data,
      id,
      createdAt: new Date().toISOString(),
    };
    this.data.subjects.push(subject);
    this.save();
    return subject;
  }

  public updateSubject(id: string, updates: Partial<Subject>): Subject | null {
    const index = this.data.subjects.findIndex((s) => s.id === id);
    if (index === -1) return null;
    this.data.subjects[index] = { ...this.data.subjects[index], ...updates };
    this.save();
    return this.data.subjects[index];
  }

  public deleteSubject(id: string): boolean {
    const exists = this.data.subjects.some((s) => s.id === id);
    if (!exists) return false;
    this.data.subjects = this.data.subjects.filter((s) => s.id !== id);
    this.data.notes = this.data.notes.filter((n) => n.subjectId !== id);
    this.data.class_records = this.data.class_records.filter((c) => c.subjectId !== id);
    this.data.attendance = this.data.attendance.filter((a) => a.subjectId !== id);
    this.save();
    return true;
  }

  // Class Records (Subject Academic Logs)
  public getClassRecords(subjectId?: string): ClassRecord[] {
    let records = this.data.class_records;
    if (subjectId) {
      records = records.filter((r) => r.subjectId === subjectId);
    }
    return records.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }

  public createClassRecord(data: Omit<ClassRecord, 'id' | 'createdAt'>): ClassRecord {
    const id = 'rec_' + crypto.randomUUID().slice(0, 8);
    const record: ClassRecord = {
      ...data,
      id,
      createdAt: new Date().toISOString(),
    };
    this.data.class_records.unshift(record);
    this.save();
    return record;
  }

  public deleteClassRecord(id: string): boolean {
    const prev = this.data.class_records.length;
    this.data.class_records = this.data.class_records.filter((r) => r.id !== id);
    this.save();
    return this.data.class_records.length < prev;
  }

  // Notes
  public getNotes(subjectId?: string): Note[] {
    let notes = this.data.notes;
    if (subjectId) {
      notes = notes.filter((n) => n.subjectId === subjectId);
    }
    // Attach subject names
    const subjectsMap = new Map(this.data.subjects.map((s) => [s.id, s.name]));
    return notes.map((n) => ({
      ...n,
      subjectName: subjectsMap.get(n.subjectId) || 'General',
    })).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  public createNote(data: Omit<Note, 'id' | 'createdAt'>): Note {
    const id = 'not_' + crypto.randomUUID().slice(0, 8);
    const note: Note = {
      ...data,
      id,
      createdAt: new Date().toISOString(),
    };
    this.data.notes.unshift(note);
    this.save();
    return note;
  }

  public updateNote(id: string, updates: Partial<Note>): Note | null {
    const index = this.data.notes.findIndex((n) => n.id === id);
    if (index === -1) return null;
    this.data.notes[index] = { ...this.data.notes[index], ...updates };
    this.save();
    return this.data.notes[index];
  }

  public deleteNote(id: string): boolean {
    const prev = this.data.notes.length;
    this.data.notes = this.data.notes.filter((n) => n.id !== id);
    this.save();
    return this.data.notes.length < prev;
  }

  // Announcements
  public getAnnouncements(): Announcement[] {
    return [...this.data.announcements].sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  public createAnnouncement(data: Omit<Announcement, 'id' | 'createdAt'>): Announcement {
    const id = 'ann_' + crypto.randomUUID().slice(0, 8);
    const ann: Announcement = {
      ...data,
      id,
      createdAt: new Date().toISOString(),
    };
    this.data.announcements.unshift(ann);
    this.save();
    return ann;
  }

  public deleteAnnouncement(id: string): boolean {
    const prev = this.data.announcements.length;
    this.data.announcements = this.data.announcements.filter((a) => a.id !== id);
    this.save();
    return this.data.announcements.length < prev;
  }

  // Students
  public getStudents(): Student[] {
    return this.data.students;
  }

  public getStudentById(id: string): Student | undefined {
    return this.data.students.find((s) => s.id === id);
  }

  public createStudent(data: Omit<Student, 'id' | 'createdAt'>): Student {
    const id = 'stu_' + crypto.randomUUID().slice(0, 8);
    const student: Student = {
      ...data,
      id,
      createdAt: new Date().toISOString(),
    };
    this.data.students.push(student);
    this.save();
    return student;
  }

  public updateStudent(id: string, updates: Partial<Student>): Student | null {
    const index = this.data.students.findIndex((s) => s.id === id);
    if (index === -1) return null;
    this.data.students[index] = { ...this.data.students[index], ...updates };
    this.save();
    return this.data.students[index];
  }

  public deleteStudent(id: string): boolean {
    const prev = this.data.students.length;
    this.data.students = this.data.students.filter((s) => s.id !== id);
    this.data.attendance = this.data.attendance.filter((a) => a.studentId !== id);
    this.save();
    return this.data.students.length < prev;
  }

  // Attendance
  public getAttendance(filters?: { subjectId?: string; studentId?: string; date?: string }): AttendanceRecord[] {
    let list = this.data.attendance;
    if (filters?.subjectId) list = list.filter((a) => a.subjectId === filters.subjectId);
    if (filters?.studentId) list = list.filter((a) => a.studentId === filters.studentId);
    if (filters?.date) list = list.filter((a) => a.date === filters.date);

    const studentsMap = new Map(this.data.students.map((s) => [s.id, s]));
    const subjectsMap = new Map(this.data.subjects.map((s) => [s.id, s.name]));

    return list.map((a) => {
      const student = studentsMap.get(a.studentId);
      return {
        ...a,
        studentName: student ? student.name : 'Unknown Student',
        studentRollNo: student ? student.rollNo : 'N/A',
        subjectName: subjectsMap.get(a.subjectId) || 'Subject',
      };
    }).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }

  public markAttendance(records: {
    studentId: string;
    subjectId: string;
    date: string;
    status: 'present' | 'absent' | 'late' | 'excused';
    markedBy: string;
    markedByName?: string;
  }[]): AttendanceRecord[] {
    const updated: AttendanceRecord[] = [];
    for (const rec of records) {
      // Check if entry already exists for student, subject, and date
      const existingIndex = this.data.attendance.findIndex(
        (a) => a.studentId === rec.studentId && a.subjectId === rec.subjectId && a.date === rec.date
      );
      if (existingIndex >= 0) {
        this.data.attendance[existingIndex].status = rec.status;
        this.data.attendance[existingIndex].markedBy = rec.markedBy;
        this.data.attendance[existingIndex].markedByName = rec.markedByName;
        updated.push(this.data.attendance[existingIndex]);
      } else {
        const newRecord: AttendanceRecord = {
          id: 'att_' + crypto.randomUUID().slice(0, 8),
          ...rec,
          createdAt: new Date().toISOString(),
        };
        this.data.attendance.push(newRecord);
        updated.push(newRecord);
      }
    }
    this.save();
    return updated;
  }

  // System Settings
  public getSettings(): SystemSettings {
    return this.data.system_settings;
  }

  public updateSettings(updates: Partial<SystemSettings>): SystemSettings {
    this.data.system_settings = { ...this.data.system_settings, ...updates };
    this.save();
    return this.data.system_settings;
  }

  // Database Management: Reset to Empty Schema
  public resetToEmpty(keepMainAdmin = true) {
    const admin = keepMainAdmin ? this.data.users.find((u) => u.role === 'main_admin') : null;
    this.data = getEmptyDatabase();
    if (admin) {
      this.data.users.push(admin);
    } else {
      this.initDefaultAdmin();
    }
    this.data.audit_logs.unshift({
      id: 'log_' + crypto.randomUUID().slice(0, 8),
      userId: admin ? admin.id : 'system',
      userName: admin ? admin.name : 'System Admin',
      userRole: 'main_admin',
      action: 'DATABASE_RESET_EMPTY',
      entityType: 'database',
      details: 'All tables emptied. Clean relational database schema ready for data ingestion.',
      timestamp: new Date().toISOString(),
    });
    this.save();
    return { success: true, message: 'Database reset to empty schema successfully.' };
  }

  // Database Management: Bulk Data Ingestion Engine
  public ingestData(table: string, records: any[]): { insertedCount: number; table: string } {
    if (!Array.isArray(records) || records.length === 0) {
      throw new Error('Records must be a non-empty array of objects.');
    }

    let insertedCount = 0;
    const now = new Date().toISOString();

    switch (table) {
      case 'users':
        for (const item of records) {
          if (!item.name || !item.email) continue;
          const passwordHash = item.password
            ? bcrypt.hashSync(String(item.password), 10)
            : bcrypt.hashSync('ChangeMe@2026', 10);
          this.data.users.push({
            id: item.id || 'usr_' + crypto.randomUUID().slice(0, 8),
            name: String(item.name),
            email: String(item.email).toLowerCase(),
            role: item.role === 'teacher' || item.role === 'student' ? item.role : 'student',
            status: item.status || 'active',
            passwordHash,
            phone: item.phone || '',
            profileImage: item.profileImage || item.profile_image || '',
            createdAt: item.createdAt || item.created_at || now,
            updatedAt: now,
          });
          insertedCount++;
        }
        break;

      case 'subjects':
        for (const item of records) {
          if (!item.name || !item.code) continue;
          this.data.subjects.push({
            id: item.id || 'sub_' + crypto.randomUUID().slice(0, 8),
            name: String(item.name),
            code: String(item.code).toUpperCase(),
            description: item.description || '',
            department: item.department || 'General Academics',
            thumbnail: item.thumbnail || '',
            filePath: item.filePath || item.file_path || '',
            teacherIds: Array.isArray(item.teacherIds) ? item.teacherIds : [],
            createdAt: item.createdAt || now,
          });
          insertedCount++;
        }
        break;

      case 'students':
        for (const item of records) {
          if (!item.name || !item.rollNo) continue;
          this.data.students.push({
            id: item.id || 'stu_' + crypto.randomUUID().slice(0, 8),
            name: String(item.name),
            rollNo: String(item.rollNo || item.roll_no),
            email: item.email || `${String(item.name).toLowerCase().replace(/\s+/g, '.')}@student.edu`,
            phone: item.phone || '',
            classId: item.classId || item.class_id || 'Grade 11-A',
            section: item.section || 'A',
            profileImage: item.profileImage || item.profile_image || '',
            enrolledSubjectIds: Array.isArray(item.enrolledSubjectIds) ? item.enrolledSubjectIds : [],
            createdAt: item.createdAt || now,
          });
          insertedCount++;
        }
        break;

      case 'notes':
        for (const item of records) {
          if (!item.title || !item.subjectId) continue;
          this.data.notes.push({
            id: item.id || 'not_' + crypto.randomUUID().slice(0, 8),
            subjectId: item.subjectId || item.subject_id,
            title: String(item.title),
            content: item.content || '',
            filePath: item.filePath || item.file_path || '',
            fileName: item.fileName || item.file_name || 'NoteDocument.pdf',
            createdBy: item.createdBy || 'usr_admin_001',
            createdAt: item.createdAt || now,
          });
          insertedCount++;
        }
        break;

      case 'announcements':
        for (const item of records) {
          if (!item.title || !item.description) continue;
          this.data.announcements.push({
            id: item.id || 'ann_' + crypto.randomUUID().slice(0, 8),
            title: String(item.title),
            description: String(item.description),
            priority: item.priority || 'normal',
            thumbnail: item.thumbnail || '',
            imagePath: item.imagePath || item.image_path || '',
            filePath: item.filePath || item.file_path || '',
            fileName: item.fileName || item.file_name || '',
            postedBy: item.postedBy || 'usr_admin_001',
            createdAt: item.createdAt || now,
          });
          insertedCount++;
        }
        break;

      case 'attendance':
        for (const item of records) {
          if (!item.studentId || !item.subjectId || !item.date) continue;
          this.data.attendance.push({
            id: item.id || 'att_' + crypto.randomUUID().slice(0, 8),
            studentId: item.studentId || item.student_id,
            subjectId: item.subjectId || item.subject_id,
            date: item.date,
            status: item.status || 'present',
            markedBy: item.markedBy || item.marked_by || 'usr_admin_001',
            createdAt: item.createdAt || now,
          });
          insertedCount++;
        }
        break;

      default:
        throw new Error(`Unsupported ingestion table: ${table}. Supported: users, subjects, students, notes, announcements, attendance.`);
    }

    this.data.audit_logs.unshift({
      id: 'log_' + crypto.randomUUID().slice(0, 8),
      userId: 'admin',
      userName: 'Data Ingestion Service',
      userRole: 'main_admin',
      action: 'DATA_INGESTION_BULK',
      entityType: table,
      details: `Successfully ingested ${insertedCount} records into ${table} table.`,
      timestamp: now,
    });

    this.save();
    return { insertedCount, table };
  }

  // Seed Demo Pack (Optional for live testing)
  public seedDemoPack() {
    const now = new Date().toISOString();
    const today = new Date().toISOString().split('T')[0];
    const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
    const twoDaysAgo = new Date(Date.now() - 86400000 * 2).toISOString().split('T')[0];

    // 1. Teachers & Students Users
    const teacherMath: UserRecord = {
      id: 'usr_t_math',
      name: 'Dr. Sarah Jenkins',
      email: 'sarah.jenkins@school.edu',
      role: 'teacher',
      status: 'active',
      profileImage: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
      phone: '+1 (555) 234-5678',
      passwordHash: bcrypt.hashSync('Teacher@123', 10),
      createdAt: now,
      updatedAt: now,
    };

    const teacherPhysics: UserRecord = {
      id: 'usr_t_phys',
      name: 'Prof. Marcus Vance',
      email: 'marcus.vance@school.edu',
      role: 'teacher',
      status: 'active',
      profileImage: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=150&auto=format&fit=crop&q=80',
      phone: '+1 (555) 345-6789',
      passwordHash: bcrypt.hashSync('Teacher@123', 10),
      createdAt: now,
      updatedAt: now,
    };

    const studentAlex: UserRecord = {
      id: 'usr_s_alex',
      name: 'Alex Rivera',
      email: 'alex.rivera@student.edu',
      role: 'student',
      status: 'active',
      profileImage: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80',
      phone: '+1 (555) 456-7890',
      passwordHash: bcrypt.hashSync('Student@123', 10),
      createdAt: now,
      updatedAt: now,
    };

    const studentEmma: UserRecord = {
      id: 'usr_s_emma',
      name: 'Emma Watson',
      email: 'emma.watson@student.edu',
      role: 'student',
      status: 'active',
      profileImage: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
      phone: '+1 (555) 567-8901',
      passwordHash: bcrypt.hashSync('Student@123', 10),
      createdAt: now,
      updatedAt: now,
    };

    // Ensure we keep existing main admin if present
    const mainAdmin = this.data.users.find((u) => u.role === 'main_admin') || {
      id: 'usr_admin_001',
      name: 'System Main Admin',
      email: 'admin@school.edu',
      role: 'main_admin' as const,
      status: 'active' as const,
      profileImage: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
      phone: '+1 (555) 019-2831',
      passwordHash: bcrypt.hashSync('Admin@123456', 10),
      createdAt: now,
      updatedAt: now,
    };

    this.data.users = [mainAdmin, teacherMath, teacherPhysics, studentAlex, studentEmma];

    // 2. Subjects
    const subMath: Subject = {
      id: 'sub_math101',
      name: 'Advanced Calculus & Analytical Geometry',
      code: 'MTH-301',
      department: 'Mathematics & Computing',
      description: 'Rigorous study of multivariable limits, directional derivatives, Stokes theorem, and series approximations.',
      thumbnail: 'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=400&auto=format&fit=crop&q=80',
      filePath: '/assets/syllabus_math301.pdf',
      teacherIds: [teacherMath.id],
      createdAt: now,
    };

    const subPhysics: Subject = {
      id: 'sub_phys201',
      name: 'Classical Mechanics & Thermodynamics',
      code: 'PHY-201',
      department: 'Natural Sciences',
      description: 'Explores Lagrangian mechanics, harmonic oscillation systems, entropy gradients, and kinetic theory.',
      thumbnail: 'https://images.unsplash.com/photo-1636466497217-26a8cbeaf0aa?w=400&auto=format&fit=crop&q=80',
      filePath: '/assets/syllabus_phy201.pdf',
      teacherIds: [teacherPhysics.id],
      createdAt: now,
    };

    const subCS: Subject = {
      id: 'sub_cs105',
      name: 'Data Structures & Algorithms',
      code: 'CS-105',
      department: 'Computer Science',
      description: 'Analysis of algorithmic complexity, balanced search trees, graph traversals, and dynamic programming paradigms.',
      thumbnail: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=400&auto=format&fit=crop&q=80',
      filePath: '/assets/syllabus_cs105.pdf',
      teacherIds: [teacherMath.id],
      createdAt: now,
    };

    this.data.subjects = [subMath, subPhysics, subCS];

    // 3. User Permissions (Granular ACL: Dr. Sarah Jenkins gets Math & CS; Marcus Vance gets Physics; Alex gets student access)
    this.data.user_permissions = [
      // Teacher Sarah: Mathematics access
      {
        id: 'perm_t1_math',
        userId: teacherMath.id,
        section: 'subjects',
        subjectId: subMath.id,
        canRead: true,
        canCreate: true,
        canEdit: true,
        canDelete: false,
      },
      {
        id: 'perm_t1_notes',
        userId: teacherMath.id,
        section: 'notes',
        subjectId: subMath.id,
        canRead: true,
        canCreate: true,
        canEdit: true,
        canDelete: true,
      },
      {
        id: 'perm_t1_att',
        userId: teacherMath.id,
        section: 'attendance',
        subjectId: subMath.id,
        canRead: true,
        canCreate: true,
        canEdit: true,
        canDelete: false,
      },
      {
        id: 'perm_t1_ann',
        userId: teacherMath.id,
        section: 'announcements',
        subjectId: null,
        canRead: true,
        canCreate: false,
        canEdit: false,
        canDelete: false,
      },
      {
        id: 'perm_t1_stu',
        userId: teacherMath.id,
        section: 'students',
        subjectId: null,
        canRead: true,
        canCreate: false,
        canEdit: false,
        canDelete: false,
      },
      // Teacher Marcus: Physics only
      {
        id: 'perm_t2_phys',
        userId: teacherPhysics.id,
        section: 'subjects',
        subjectId: subPhysics.id,
        canRead: true,
        canCreate: true,
        canEdit: true,
        canDelete: false,
      },
      {
        id: 'perm_t2_notes',
        userId: teacherPhysics.id,
        section: 'notes',
        subjectId: subPhysics.id,
        canRead: true,
        canCreate: true,
        canEdit: true,
        canDelete: true,
      },
      {
        id: 'perm_t2_att',
        userId: teacherPhysics.id,
        section: 'attendance',
        subjectId: subPhysics.id,
        canRead: true,
        canCreate: true,
        canEdit: true,
        canDelete: false,
      },
      {
        id: 'perm_t2_ann',
        userId: teacherPhysics.id,
        section: 'announcements',
        subjectId: null,
        canRead: true,
        canCreate: false,
        canEdit: false,
        canDelete: false,
      },
      // Student Alex: read-only access to enrolled subjects
      {
        id: 'perm_s1_sub',
        userId: studentAlex.id,
        section: 'subjects',
        subjectId: null,
        canRead: true,
        canCreate: false,
        canEdit: false,
        canDelete: false,
      },
      {
        id: 'perm_s1_not',
        userId: studentAlex.id,
        section: 'notes',
        subjectId: null,
        canRead: true,
        canCreate: false,
        canEdit: false,
        canDelete: false,
      },
      {
        id: 'perm_s1_att',
        userId: studentAlex.id,
        section: 'attendance',
        subjectId: null,
        canRead: true,
        canCreate: false,
        canEdit: false,
        canDelete: false,
      },
      {
        id: 'perm_s1_ann',
        userId: studentAlex.id,
        section: 'announcements',
        subjectId: null,
        canRead: true,
        canCreate: false,
        canEdit: false,
        canDelete: false,
      },
    ];

    // 4. Students
    const stu1: Student = {
      id: 'stu_alex_001',
      userId: studentAlex.id,
      name: 'Alex Rivera',
      rollNo: '2026-CS-041',
      email: 'alex.rivera@student.edu',
      phone: '+1 (555) 456-7890',
      classId: 'Year 3 - Software & Data',
      section: 'A',
      profileImage: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80',
      enrolledSubjectIds: [subMath.id, subPhysics.id, subCS.id],
      createdAt: now,
    };

    const stu2: Student = {
      id: 'stu_emma_002',
      userId: studentEmma.id,
      name: 'Emma Watson',
      rollNo: '2026-CS-042',
      email: 'emma.watson@student.edu',
      phone: '+1 (555) 567-8901',
      classId: 'Year 3 - Software & Data',
      section: 'A',
      profileImage: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
      enrolledSubjectIds: [subMath.id, subCS.id],
      createdAt: now,
    };

    const stu3: Student = {
      id: 'stu_david_003',
      name: 'David Zhao',
      rollNo: '2026-CS-043',
      email: 'david.zhao@student.edu',
      phone: '+1 (555) 678-9012',
      classId: 'Year 3 - Software & Data',
      section: 'B',
      profileImage: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
      enrolledSubjectIds: [subMath.id, subPhysics.id],
      createdAt: now,
    };

    this.data.students = [stu1, stu2, stu3];

    // 5. Class Records (Academic Logs)
    this.data.class_records = [
      {
        id: 'rec_m1',
        subjectId: subMath.id,
        date: today,
        topicCovered: 'Green & Stokes Theorem Applications in Vector Fields',
        notes: 'Derived surface line integrals vs curl flux; assigned textbook exercises 14.7 #4-#18.',
        teacherId: teacherMath.id,
        teacherName: teacherMath.name,
        createdAt: now,
      },
      {
        id: 'rec_m2',
        subjectId: subMath.id,
        date: yesterday,
        topicCovered: 'Double Integrals in Polar Coordinates',
        notes: 'Explored Jacobian transformations. Demonstrated volume under paraboloid z = 9 - x^2 - y^2.',
        teacherId: teacherMath.id,
        teacherName: teacherMath.name,
        createdAt: now,
      },
      {
        id: 'rec_p1',
        subjectId: subPhysics.id,
        date: today,
        topicCovered: 'Carnot Cycles & Second Law of Thermodynamics',
        notes: 'Calculated theoretical peak efficiency of heat engine; reviewed lab apparatus safety protocols.',
        teacherId: teacherPhysics.id,
        teacherName: teacherPhysics.name,
        createdAt: now,
      },
      {
        id: 'rec_c1',
        subjectId: subCS.id,
        date: twoDaysAgo,
        topicCovered: 'Red-Black Tree Self-Balancing Rotations',
        notes: 'Demonstrated Left and Right Rotations following node insertion. Big-O proof of O(log n) height invariant.',
        teacherId: teacherMath.id,
        teacherName: teacherMath.name,
        createdAt: now,
      },
    ];

    // 6. Notes with Attachments
    this.data.notes = [
      {
        id: 'not_m1',
        subjectId: subMath.id,
        subjectName: subMath.name,
        title: 'Lecture 12: Multivariable Gradient Vectors & Tangent Planes',
        content: `### Core Concept Review\n- The gradient $\\nabla f(x,y,z)$ points in the direction of steepest rate of ascent.\n- Tangent plane equation at point $(x_0, y_0, z_0)$:\n$$f_x(x_0, y_0)(x - x_0) + f_y(x_0, y_0)(y - y_0) = z - z_0$$\n\n**Key takeaways:**\n1. Directional derivative maximum equals $|\\nabla f|$\n2. Perpendicular to contour lines at all smooth points.`,
        fileName: 'Math301_Lecture12_Gradient_Planes.pdf',
        fileSize: '2.4 MB',
        filePath: 'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=800',
        fileMimeType: 'application/pdf',
        createdBy: teacherMath.id,
        createdByName: teacherMath.name,
        createdAt: now,
      },
      {
        id: 'not_p1',
        subjectId: subPhysics.id,
        subjectName: subPhysics.name,
        title: 'Thermodynamic Potentials & Maxwell Relations Cheat Sheet',
        content: `Summary of internal energy $U$, enthalpy $H$, Helmholtz free energy $F$, and Gibbs free energy $G$.\n\nIncludes the differential identities and experimental measurement cross-derivatives.`,
        fileName: 'Physics201_Maxwell_Relations.pdf',
        fileSize: '1.8 MB',
        filePath: 'https://images.unsplash.com/photo-1636466497217-26a8cbeaf0aa?w=800',
        fileMimeType: 'application/pdf',
        createdBy: teacherPhysics.id,
        createdByName: teacherPhysics.name,
        createdAt: now,
      },
      {
        id: 'not_c1',
        subjectId: subCS.id,
        subjectName: subCS.name,
        title: 'Dynamic Programming Patterns: 0/1 Knapsack to Matrix Chain',
        content: `Comprehensive guide breaking down bottom-up tabulation vs top-down memoization.\n\nCode implementations in Python and C++ with asymptotic time-space analysis table.`,
        fileName: 'CS105_Dynamic_Programming_Guide.docx',
        fileSize: '950 KB',
        filePath: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=800',
        fileMimeType: 'application/msword',
        createdBy: teacherMath.id,
        createdByName: teacherMath.name,
        createdAt: now,
      },
    ];

    // 7. Announcements
    this.data.announcements = [
      {
        id: 'ann_midterm',
        title: 'Mid-Semester Examinations Schedule & Room Allocation',
        description: 'Midterm assessments commence on Monday, October 12th. All students must bring physical student identification cards. Calculators are permitted only for courses explicitly listed in the exam guideline handbook.',
        priority: 'urgent',
        thumbnail: 'https://images.unsplash.com/photo-1434030216411-0b793f4b4173?w=600&auto=format&fit=crop&q=80',
        fileName: 'Midterm_Assessment_Schedule_2026.pdf',
        filePath: '/assets/exam_schedule.pdf',
        fileMimeType: 'application/pdf',
        postedBy: mainAdmin.id,
        postedByName: mainAdmin.name,
        createdAt: now,
      },
      {
        id: 'ann_lab',
        title: 'Annual STEM Research Symposium Submissions Open',
        description: 'Undergraduate and faculty research abstracts for the Autumn STEM Symposium are now accepting submissions. Selected projects will receive department grant sponsorships and presentation slots in the main auditorium.',
        priority: 'important',
        thumbnail: 'https://images.unsplash.com/photo-1507668077129-56e32842fceb?w=600&auto=format&fit=crop&q=80',
        fileName: 'Symposium_Abstract_Guidelines.docx',
        filePath: '/assets/symposium.docx',
        fileMimeType: 'application/msword',
        postedBy: mainAdmin.id,
        postedByName: mainAdmin.name,
        createdAt: new Date(Date.now() - 86400000).toISOString(),
      },
      {
        id: 'ann_library',
        title: 'Extended Digital Library Hours & Cloud Workspace Access',
        description: 'Starting this week, the digital research lab and physical study rooms in Building C will remain accessible until 11:30 PM on weekdays. Remote VPN access to academic journals has been updated.',
        priority: 'normal',
        postedBy: mainAdmin.id,
        postedByName: mainAdmin.name,
        createdAt: new Date(Date.now() - 86400000 * 3).toISOString(),
      },
    ];

    // 8. Attendance Records
    this.data.attendance = [
      {
        id: 'att_1',
        studentId: stu1.id,
        subjectId: subMath.id,
        date: today,
        status: 'present',
        markedBy: teacherMath.id,
        markedByName: teacherMath.name,
        createdAt: now,
      },
      {
        id: 'att_2',
        studentId: stu2.id,
        subjectId: subMath.id,
        date: today,
        status: 'present',
        markedBy: teacherMath.id,
        markedByName: teacherMath.name,
        createdAt: now,
      },
      {
        id: 'att_3',
        studentId: stu3.id,
        subjectId: subMath.id,
        date: today,
        status: 'absent',
        markedBy: teacherMath.id,
        markedByName: teacherMath.name,
        createdAt: now,
      },
      {
        id: 'att_4',
        studentId: stu1.id,
        subjectId: subMath.id,
        date: yesterday,
        status: 'present',
        markedBy: teacherMath.id,
        markedByName: teacherMath.name,
        createdAt: now,
      },
      {
        id: 'att_5',
        studentId: stu2.id,
        subjectId: subMath.id,
        date: yesterday,
        status: 'late',
        markedBy: teacherMath.id,
        markedByName: teacherMath.name,
        createdAt: now,
      },
      {
        id: 'att_6',
        studentId: stu1.id,
        subjectId: subPhysics.id,
        date: today,
        status: 'present',
        markedBy: teacherPhysics.id,
        markedByName: teacherPhysics.name,
        createdAt: now,
      },
      {
        id: 'att_7',
        studentId: stu3.id,
        subjectId: subPhysics.id,
        date: today,
        status: 'excused',
        markedBy: teacherPhysics.id,
        markedByName: teacherPhysics.name,
        createdAt: now,
      },
    ];

    // 9. Audit Logs
    this.data.audit_logs.unshift({
      id: 'log_' + crypto.randomUUID().slice(0, 8),
      userId: mainAdmin.id,
      userName: mainAdmin.name,
      userRole: 'main_admin',
      action: 'SAMPLE_DATA_SEEDED',
      entityType: 'database',
      details: 'Populated academic sample pack with 3 subjects, 2 teachers, 3 students, notes, and attendance.',
      timestamp: now,
    });

    this.save();
    return { success: true, message: 'Academic sample pack loaded successfully.' };
  }
}

export const db = new Database();
