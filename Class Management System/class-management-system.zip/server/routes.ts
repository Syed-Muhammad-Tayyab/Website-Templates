import express from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import bcrypt from 'bcryptjs';
import { db } from './db.js';
import {
  requireAuth,
  requireRole,
  checkPermission,
  createSession,
  removeSession,
  rateLimiter,
} from './auth.js';

export const apiRouter = express.Router();

// Configure Multer for File Uploads
const uploadsDir = path.join(process.cwd(), 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadsDir),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname);
    const base = path.basename(file.originalname, ext).replace(/[^a-zA-Z0-9_-]/g, '_');
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
    cb(null, `${base}-${uniqueSuffix}${ext}`);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 25 * 1024 * 1024 }, // 25MB max
  fileFilter: (_req, file, cb) => {
    const allowedExts = ['.pdf', '.doc', '.docx', '.xls', '.xlsx', '.csv', '.png', '.jpg', '.jpeg', '.webp', '.txt'];
    const ext = path.extname(file.originalname).toLowerCase();
    if (allowedExts.includes(ext)) {
      cb(null, true);
    } else {
      cb(new Error(`File type ${ext} not allowed. Supported: PDF, DOC, DOCX, XLS, XLSX, CSV, Images.`));
    }
  },
});

// ----------------------------------------------------
// 1. Authentication & Profile Routes
// ----------------------------------------------------

apiRouter.post('/auth/login', rateLimiter(20, 60000), async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required.' });
    }

    const user = db.findUserByEmail(String(email).trim());
    if (!user) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    if (user.status !== 'active') {
      return res.status(403).json({ error: 'Account is deactivated. Contact system administrator.' });
    }

    const isMatch = bcrypt.compareSync(password, user.passwordHash);
    if (!isMatch) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    const token = createSession(user.id);
    const { passwordHash: _, ...safeUser } = user;
    const permissions = db.getUserPermissions(user.id);

    db.logAudit(
      user.id,
      user.name,
      user.role,
      'USER_LOGIN',
      'user',
      user.id,
      `User ${user.email} logged in successfully`,
      req.ip
    );

    return res.json({
      token,
      user: safeUser,
      permissions,
    });
  } catch (err: any) {
    console.error('Login error:', err);
    return res.status(500).json({ error: 'Internal server error during login.' });
  }
});

apiRouter.post('/auth/logout', requireAuth, (req, res) => {
  const token = req.user?.token;
  if (token) removeSession(token);
  if (req.user) {
    db.logAudit(req.user.id, req.user.name, req.user.role, 'USER_LOGOUT', 'user', req.user.id, 'User signed out', req.ip);
  }
  return res.json({ success: true, message: 'Logged out successfully.' });
});

apiRouter.get('/auth/me', requireAuth, (req, res) => {
  if (!req.user) return res.status(401).json({ error: 'Not authenticated.' });
  const permissions = db.getUserPermissions(req.user.id);
  return res.json({
    user: req.user,
    permissions,
  });
});

apiRouter.post('/auth/change-password', requireAuth, (req, res) => {
  try {
    const { currentPassword, newPassword, confirmAdminKey } = req.body;
    if (!currentPassword || !newPassword) {
      return res.status(400).json({ error: 'Current password and new password are required.' });
    }
    if (newPassword.length < 6) {
      return res.status(400).json({ error: 'New password must be at least 6 characters long.' });
    }

    const fullUser = db.findUserById(req.user!.id);
    if (!fullUser) return res.status(404).json({ error: 'User not found.' });

    const isMatch = bcrypt.compareSync(currentPassword, fullUser.passwordHash);
    if (!isMatch) {
      return res.status(400).json({ error: 'Current password does not match.' });
    }

    // Special protection for Main Admin: explicitly require confirmation token/flag
    if (fullUser.role === 'main_admin' && !confirmAdminKey) {
      return res.status(400).json({
        error: 'Main Admin credentials protection: Confirmation flag required to change root credentials.',
      });
    }

    db.updateUser(fullUser.id, { password: newPassword });
    db.logAudit(
      fullUser.id,
      fullUser.name,
      fullUser.role,
      'PASSWORD_CHANGED',
      'user',
      fullUser.id,
      'Password updated securely',
      req.ip
    );

    return res.json({ success: true, message: 'Password changed successfully.' });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Error updating password.' });
  }
});

apiRouter.put('/auth/profile', requireAuth, (req, res) => {
  try {
    const { name, email, phone, profileImage } = req.body;
    const updated = db.updateUser(req.user!.id, {
      name,
      email,
      phone,
      profileImage,
    });
    if (!updated) return res.status(404).json({ error: 'User not found.' });

    db.logAudit(
      req.user!.id,
      req.user!.name,
      req.user!.role,
      'PROFILE_UPDATED',
      'user',
      req.user!.id,
      `User ${req.user!.name} updated their personal profile`,
      req.ip
    );

    const { passwordHash: _, ...safeUser } = updated as any;
    return res.json(safeUser);
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Failed to update profile.' });
  }
});

// First-time or empty schema bootstrap admin
apiRouter.post('/auth/init-admin', (req, res) => {
  try {
    const users = db.getUsers();
    const hasAdmin = users.some((u) => u.role === 'main_admin');
    if (hasAdmin) {
      return res.status(400).json({ error: 'Main Admin already exists. Use the login screen or admin panel.' });
    }

    const { name, email, password, phone } = req.body;
    if (!name || !email || !password) {
      return res.status(400).json({ error: 'Name, email, and password are required.' });
    }

    const admin = db.createUser({
      name,
      email,
      role: 'main_admin',
      password,
      phone,
      status: 'active',
    });

    const token = createSession(admin.id);
    return res.json({
      success: true,
      message: 'Primary Main Admin account configured.',
      user: admin,
      token,
      permissions: [],
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// ----------------------------------------------------
// 2. User Management & Permissions (Admin Control Center)
// ----------------------------------------------------

apiRouter.get('/users', requireAuth, requireRole(['main_admin']), (_req, res) => {
  const users = db.getUsers();
  return res.json(users);
});

apiRouter.post('/users', requireAuth, requireRole(['main_admin']), (req, res) => {
  try {
    const { name, email, role, password, phone, status, profileImage } = req.body;
    if (!name || !email || !role || !password) {
      return res.status(400).json({ error: 'Name, email, role, and password are required.' });
    }

    const existing = db.findUserByEmail(email);
    if (existing) {
      return res.status(409).json({ error: 'A user with this email already exists.' });
    }

    const user = db.createUser({
      name,
      email,
      role,
      password,
      phone,
      status: status || 'active',
      profileImage,
    });

    db.logAudit(
      req.user!.id,
      req.user!.name,
      req.user!.role,
      'USER_CREATED',
      'user',
      user.id,
      `Created user ${user.name} (${user.role})`,
      req.ip
    );

    return res.status(201).json(user);
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

apiRouter.put('/users/:id', requireAuth, requireRole(['main_admin']), (req, res) => {
  try {
    const { name, email, role, password, phone, status, profileImage } = req.body;
    const updated = db.updateUser(req.params.id, {
      name,
      email,
      role,
      password: password || undefined,
      phone,
      status,
      profileImage,
    });

    if (!updated) return res.status(404).json({ error: 'User not found.' });

    db.logAudit(
      req.user!.id,
      req.user!.name,
      req.user!.role,
      'USER_UPDATED',
      'user',
      updated.id,
      `Updated user ${updated.name}`,
      req.ip
    );

    return res.json(updated);
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

apiRouter.delete('/users/:id', requireAuth, requireRole(['main_admin']), (req, res) => {
  try {
    if (req.user!.id === req.params.id) {
      return res.status(400).json({ error: 'You cannot delete your own logged-in account.' });
    }
    const success = db.deleteUser(req.params.id);
    if (!success) return res.status(404).json({ error: 'User not found.' });

    db.logAudit(
      req.user!.id,
      req.user!.name,
      req.user!.role,
      'USER_DELETED',
      'user',
      req.params.id,
      'Deleted user account',
      req.ip
    );

    return res.json({ success: true, message: 'User deleted.' });
  } catch (err: any) {
    return res.status(400).json({ error: err.message });
  }
});

apiRouter.get('/users/:id/permissions', requireAuth, requireRole(['main_admin']), (req, res) => {
  const perms = db.getUserPermissions(req.params.id);
  return res.json(perms);
});

apiRouter.post('/users/:id/permissions', requireAuth, requireRole(['main_admin']), (req, res) => {
  try {
    const { permissions } = req.body;
    if (!Array.isArray(permissions)) {
      return res.status(400).json({ error: 'Permissions must be an array.' });
    }

    const updated = db.setUserPermissions(req.params.id, permissions);
    db.logAudit(
      req.user!.id,
      req.user!.name,
      req.user!.role,
      'PERMISSIONS_UPDATED',
      'user',
      req.params.id,
      `Configured ${updated.length} granular permission rules`,
      req.ip
    );

    return res.json(updated);
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// ----------------------------------------------------
// 3. Subjects & Class Academic Records
// ----------------------------------------------------

apiRouter.get('/subjects', requireAuth, (req, res) => {
  const allSubjects = db.getSubjects();

  // If Main Admin, return all
  if (req.user!.role === 'main_admin') {
    return res.json(allSubjects);
  }

  // Filter based on user permissions
  const perms = db.getUserPermissions(req.user!.id);
  const subjectPerms = perms.filter((p) => p.section === 'subjects' && p.canRead);

  // If user has a wildcard subjects permission (subjectId == null) or role is student with enrollments
  const hasGlobalRead = subjectPerms.some((p) => p.subjectId === null);
  if (hasGlobalRead) {
    return res.json(allSubjects);
  }

  const allowedIds = new Set(subjectPerms.map((p) => p.subjectId).filter(Boolean));
  // If student, also include enrolled subjects
  if (req.user!.role === 'student') {
    const students = db.getStudents();
    const studentProfile = students.find((s) => s.userId === req.user!.id || s.email === req.user!.email);
    if (studentProfile) {
      studentProfile.enrolledSubjectIds.forEach((id) => allowedIds.add(id));
    }
  }

  // If teacher, also include subjects where they are assigned in teacherIds
  if (req.user!.role === 'teacher') {
    allSubjects.forEach((s) => {
      if (s.teacherIds?.includes(req.user!.id)) {
        allowedIds.add(s.id);
      }
    });
  }

  const filtered = allSubjects.filter((s) => allowedIds.has(s.id));
  return res.json(filtered);
});

apiRouter.get('/subjects/:id', requireAuth, (req, res) => {
  const subject = db.getSubjectById(req.params.id);
  if (!subject) return res.status(404).json({ error: 'Subject not found.' });

  // Attach teachers info, notes, and class records
  const allUsers = db.getUsers();
  const teachers = allUsers.filter((u) => subject.teacherIds?.includes(u.id));
  const notes = db.getNotes(subject.id);
  const classRecords = db.getClassRecords(subject.id);

  return res.json({
    ...subject,
    teachers,
    notes,
    classRecords,
  });
});

apiRouter.post('/subjects', requireAuth, checkPermission('subjects', 'create'), (req, res) => {
  try {
    const { name, code, department, description, thumbnail, filePath, teacherIds } = req.body;
    if (!name || !code) {
      return res.status(400).json({ error: 'Subject name and course code are required.' });
    }

    const created = db.createSubject({
      name,
      code,
      department: department || 'Academics',
      description: description || '',
      thumbnail,
      filePath,
      teacherIds: Array.isArray(teacherIds) ? teacherIds : [],
    });

    db.logAudit(
      req.user!.id,
      req.user!.name,
      req.user!.role,
      'SUBJECT_CREATED',
      'subject',
      created.id,
      `Created course ${created.code}: ${created.name}`,
      req.ip
    );

    return res.status(201).json(created);
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

apiRouter.put('/subjects/:id', requireAuth, checkPermission('subjects', 'edit'), (req, res) => {
  try {
    const updated = db.updateSubject(req.params.id, req.body);
    if (!updated) return res.status(404).json({ error: 'Subject not found.' });

    db.logAudit(
      req.user!.id,
      req.user!.name,
      req.user!.role,
      'SUBJECT_UPDATED',
      'subject',
      updated.id,
      `Updated course ${updated.name}`,
      req.ip
    );

    return res.json(updated);
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

apiRouter.delete('/subjects/:id', requireAuth, checkPermission('subjects', 'delete'), (req, res) => {
  try {
    const success = db.deleteSubject(req.params.id);
    if (!success) return res.status(404).json({ error: 'Subject not found.' });

    db.logAudit(
      req.user!.id,
      req.user!.name,
      req.user!.role,
      'SUBJECT_DELETED',
      'subject',
      req.params.id,
      'Deleted subject and associated records',
      req.ip
    );

    return res.json({ success: true, message: 'Subject deleted.' });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// Class Records (Academic Log)
apiRouter.get('/subjects/:id/records', requireAuth, (req, res) => {
  const records = db.getClassRecords(req.params.id);
  return res.json(records);
});

apiRouter.post('/subjects/:id/records', requireAuth, (req, res) => {
  try {
    // Only Admin or assigned Teacher may post academic logs
    const subject = db.getSubjectById(req.params.id);
    if (!subject) return res.status(404).json({ error: 'Subject not found.' });

    if (req.user!.role !== 'main_admin' && !subject.teacherIds.includes(req.user!.id)) {
      return res.status(403).json({ error: 'Only authorized course instructors or admins can log academic records.' });
    }

    const { date, topicCovered, notes } = req.body;
    if (!date || !topicCovered) {
      return res.status(400).json({ error: 'Date and topic covered are required.' });
    }

    const record = db.createClassRecord({
      subjectId: req.params.id,
      date,
      topicCovered,
      notes: notes || '',
      teacherId: req.user!.id,
      teacherName: req.user!.name,
    });

    db.logAudit(
      req.user!.id,
      req.user!.name,
      req.user!.role,
      'CLASS_RECORD_ADDED',
      'class_record',
      record.id,
      `Logged class for ${subject.code}: ${topicCovered}`,
      req.ip
    );

    return res.status(201).json(record);
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

apiRouter.delete('/class-records/:id', requireAuth, requireRole(['main_admin', 'teacher']), (req, res) => {
  const success = db.deleteClassRecord(req.params.id);
  if (!success) return res.status(404).json({ error: 'Record not found.' });
  return res.json({ success: true });
});

// ----------------------------------------------------
// 4. Notes & Study Materials
// ----------------------------------------------------

apiRouter.get('/notes', requireAuth, (req, res) => {
  const subjectId = req.query.subjectId as string | undefined;
  const search = req.query.search as string | undefined;
  let notes = db.getNotes(subjectId);

  if (search) {
    const q = search.toLowerCase();
    notes = notes.filter(
      (n) =>
        n.title.toLowerCase().includes(q) ||
        n.content.toLowerCase().includes(q) ||
        n.subjectName?.toLowerCase().includes(q)
    );
  }

  // Permission filtering if not admin
  if (req.user!.role !== 'main_admin') {
    const perms = db.getUserPermissions(req.user!.id);
    const notesPerms = perms.filter((p) => p.section === 'notes' && p.canRead);
    const hasGlobalRead = notesPerms.some((p) => p.subjectId === null);
    if (!hasGlobalRead) {
      const allowedSubjectIds = new Set(notesPerms.map((p) => p.subjectId).filter(Boolean));
      notes = notes.filter((n) => allowedSubjectIds.has(n.subjectId));
    }
  }

  return res.json(notes);
});

apiRouter.post('/notes', requireAuth, checkPermission('notes', 'create'), (req, res) => {
  try {
    const { subjectId, title, content, filePath, fileName, fileSize, fileMimeType } = req.body;
    if (!subjectId || !title) {
      return res.status(400).json({ error: 'Subject and title are required.' });
    }

    const note = db.createNote({
      subjectId,
      title,
      content: content || '',
      filePath,
      fileName,
      fileSize,
      fileMimeType,
      createdBy: req.user!.id,
      createdByName: req.user!.name,
    });

    db.logAudit(
      req.user!.id,
      req.user!.name,
      req.user!.role,
      'NOTE_CREATED',
      'note',
      note.id,
      `Uploaded note: ${note.title}`,
      req.ip
    );

    return res.status(201).json(note);
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

apiRouter.put('/notes/:id', requireAuth, checkPermission('notes', 'edit'), (req, res) => {
  const updated = db.updateNote(req.params.id, req.body);
  if (!updated) return res.status(404).json({ error: 'Note not found.' });
  return res.json(updated);
});

apiRouter.delete('/notes/:id', requireAuth, checkPermission('notes', 'delete'), (req, res) => {
  const success = db.deleteNote(req.params.id);
  if (!success) return res.status(404).json({ error: 'Note not found.' });
  return res.json({ success: true });
});

// ----------------------------------------------------
// 5. Announcements
// ----------------------------------------------------

apiRouter.get('/announcements', requireAuth, (req, res) => {
  const search = req.query.search as string | undefined;
  let list = db.getAnnouncements();

  if (search) {
    const q = search.toLowerCase();
    list = list.filter(
      (a) => a.title.toLowerCase().includes(q) || a.description.toLowerCase().includes(q)
    );
  }

  return res.json(list);
});

apiRouter.post('/announcements', requireAuth, requireRole(['main_admin']), (req, res) => {
  try {
    const { title, description, priority, thumbnail, imagePath, filePath, fileName, fileMimeType } = req.body;
    if (!title || !description) {
      return res.status(400).json({ error: 'Title and description are required.' });
    }

    const ann = db.createAnnouncement({
      title,
      description,
      priority: priority || 'normal',
      thumbnail,
      imagePath,
      filePath,
      fileName,
      fileMimeType,
      postedBy: req.user!.id,
      postedByName: req.user!.name,
    });

    db.logAudit(
      req.user!.id,
      req.user!.name,
      req.user!.role,
      'ANNOUNCEMENT_POSTED',
      'announcement',
      ann.id,
      `Posted announcement: ${ann.title}`,
      req.ip
    );

    return res.status(201).json(ann);
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

apiRouter.delete('/announcements/:id', requireAuth, requireRole(['main_admin']), (req, res) => {
  const success = db.deleteAnnouncement(req.params.id);
  if (!success) return res.status(404).json({ error: 'Announcement not found.' });
  return res.json({ success: true });
});

// ----------------------------------------------------
// 6. Attendance Tracking & Reporting
// ----------------------------------------------------

apiRouter.get('/attendance', requireAuth, (req, res) => {
  const subjectId = req.query.subjectId as string | undefined;
  const date = req.query.date as string | undefined;
  let studentId = req.query.studentId as string | undefined;

  // If user is student, restrict to their own student profile
  if (req.user!.role === 'student') {
    const students = db.getStudents();
    const student = students.find((s) => s.userId === req.user!.id || s.email === req.user!.email);
    if (student) {
      studentId = student.id;
    }
  }

  const records = db.getAttendance({ subjectId, date, studentId });
  return res.json(records);
});

apiRouter.post('/attendance/mark', requireAuth, checkPermission('attendance', 'create'), (req, res) => {
  try {
    const { records } = req.body;
    if (!Array.isArray(records) || records.length === 0) {
      return res.status(400).json({ error: 'Attendance records must be a non-empty array.' });
    }

    const prepared = records.map((r: any) => ({
      studentId: r.studentId,
      subjectId: r.subjectId,
      date: r.date,
      status: r.status,
      markedBy: req.user!.id,
      markedByName: req.user!.name,
    }));

    const saved = db.markAttendance(prepared);
    db.logAudit(
      req.user!.id,
      req.user!.name,
      req.user!.role,
      'ATTENDANCE_MARKED',
      'attendance',
      saved[0]?.subjectId,
      `Marked attendance for ${saved.length} students on ${saved[0]?.date}`,
      req.ip
    );

    return res.json({ success: true, count: saved.length, records: saved });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

apiRouter.get('/attendance/stats', requireAuth, (req, res) => {
  const records = db.getAttendance();
  const students = db.getStudents();
  const subjects = db.getSubjects();

  // Calculate per student percentage
  const studentStats = students.map((s) => {
    const studentRecs = records.filter((r) => r.studentId === s.id);
    const total = studentRecs.length;
    const presentCount = studentRecs.filter((r) => r.status === 'present').length;
    const lateCount = studentRecs.filter((r) => r.status === 'late').length;
    // Late counted as 0.5 attendance
    const effectivePresent = presentCount + lateCount * 0.5;
    const percentage = total > 0 ? Math.round((effectivePresent / total) * 100) : 100;

    return {
      studentId: s.id,
      name: s.name,
      rollNo: s.rollNo,
      totalClasses: total,
      presentCount,
      lateCount,
      absentCount: studentRecs.filter((r) => r.status === 'absent').length,
      excusedCount: studentRecs.filter((r) => r.status === 'excused').length,
      percentage,
    };
  });

  // Calculate per subject percentage
  const subjectStats = subjects.map((sub) => {
    const subRecs = records.filter((r) => r.subjectId === sub.id);
    const total = subRecs.length;
    const present = subRecs.filter((r) => r.status === 'present' || r.status === 'late').length;
    const percentage = total > 0 ? Math.round((present / total) * 100) : 100;
    return {
      subjectId: sub.id,
      subjectName: sub.name,
      subjectCode: sub.code,
      totalEntries: total,
      percentage,
    };
  });

  const overallTotal = records.length;
  const overallPresent = records.filter((r) => r.status === 'present' || r.status === 'late').length;
  const overallPercentage = overallTotal > 0 ? Math.round((overallPresent / overallTotal) * 100) : 100;

  return res.json({
    overallPercentage,
    totalRecords: overallTotal,
    studentStats,
    subjectStats,
  });
});

apiRouter.get('/attendance/export', requireAuth, (_req, res) => {
  const records = db.getAttendance();
  let csv = 'Record ID,Student Name,Roll No,Subject,Date,Status,Marked By\n';
  for (const r of records) {
    csv += `"${r.id}","${r.studentName}","${r.studentRollNo}","${r.subjectName}","${r.date}","${r.status}","${r.markedByName || ''}"\n`;
  }
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename="attendance_report.csv"');
  return res.send(csv);
});

// ----------------------------------------------------
// 7. Students Management
// ----------------------------------------------------

apiRouter.get('/students', requireAuth, (req, res) => {
  const search = req.query.search as string | undefined;
  let list = db.getStudents();
  if (search) {
    const q = search.toLowerCase();
    list = list.filter((s) => s.name.toLowerCase().includes(q) || s.rollNo.toLowerCase().includes(q));
  }
  return res.json(list);
});

apiRouter.get('/students/:id', requireAuth, (req, res) => {
  const student = db.getStudentById(req.params.id);
  if (!student) return res.status(404).json({ error: 'Student not found.' });

  const attendance = db.getAttendance({ studentId: student.id });
  const subjects = db.getSubjects().filter((s) => student.enrolledSubjectIds?.includes(s.id));

  return res.json({
    ...student,
    attendance,
    subjects,
  });
});

apiRouter.post('/students', requireAuth, checkPermission('students', 'create'), (req, res) => {
  try {
    const { name, rollNo, email, phone, classId, section, enrolledSubjectIds, profileImage } = req.body;
    if (!name || !rollNo || !email) {
      return res.status(400).json({ error: 'Name, Roll No, and email are required.' });
    }

    const created = db.createStudent({
      name,
      rollNo,
      email,
      phone,
      classId: classId || 'General',
      section: section || 'A',
      profileImage,
      enrolledSubjectIds: Array.isArray(enrolledSubjectIds) ? enrolledSubjectIds : [],
    });

    db.logAudit(
      req.user!.id,
      req.user!.name,
      req.user!.role,
      'STUDENT_REGISTERED',
      'student',
      created.id,
      `Registered student ${created.name} (${created.rollNo})`,
      req.ip
    );

    return res.status(201).json(created);
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

apiRouter.put('/students/:id', requireAuth, checkPermission('students', 'edit'), (req, res) => {
  const updated = db.updateStudent(req.params.id, req.body);
  if (!updated) return res.status(404).json({ error: 'Student not found.' });
  return res.json(updated);
});

apiRouter.delete('/students/:id', requireAuth, checkPermission('students', 'delete'), (req, res) => {
  const success = db.deleteStudent(req.params.id);
  if (!success) return res.status(404).json({ error: 'Student not found.' });
  return res.json({ success: true });
});

// ----------------------------------------------------
// 8. Audit Logs
// ----------------------------------------------------

apiRouter.get('/audit-logs', requireAuth, requireRole(['main_admin']), (req, res) => {
  const limit = req.query.limit ? parseInt(String(req.query.limit), 10) : 100;
  const logs = db.getAuditLogs(limit);
  return res.json(logs);
});

// ----------------------------------------------------
// 9. Database Management & Ingestion Center
// ----------------------------------------------------

apiRouter.get('/database/schema', requireAuth, requireRole(['main_admin']), (_req, res) => {
  const schema = db.getSchemaDefinitions();
  return res.json(schema);
});

apiRouter.get('/database/export-ddl', requireAuth, requireRole(['main_admin']), (_req, res) => {
  const sqlPath = path.join(process.cwd(), 'server', 'schema.sql');
  if (fs.existsSync(sqlPath)) {
    const ddl = fs.readFileSync(sqlPath, 'utf-8');
    return res.type('text/plain').send(ddl);
  }
  return res.status(404).send('-- Schema file not found');
});

apiRouter.post('/database/ingest', requireAuth, requireRole(['main_admin']), (req, res) => {
  try {
    const { table, records } = req.body;
    if (!table || !records) {
      return res.status(400).json({ error: 'Table name and records array are required.' });
    }

    const result = db.ingestData(table, records);
    return res.json({
      success: true,
      message: `Successfully ingested ${result.insertedCount} records into ${result.table}.`,
      ...result,
    });
  } catch (err: any) {
    return res.status(400).json({ error: err.message });
  }
});

apiRouter.post('/database/seed-demo', requireAuth, requireRole(['main_admin']), (_req, res) => {
  try {
    const result = db.seedDemoPack();
    return res.json(result);
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

apiRouter.post('/database/reset-empty', requireAuth, requireRole(['main_admin']), (req, res) => {
  try {
    const keepAdmin = req.body.keepAdmin !== false;
    const result = db.resetToEmpty(keepAdmin);
    return res.json(result);
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// ----------------------------------------------------
// 10. System Settings & File Upload
// ----------------------------------------------------

apiRouter.get('/settings', (_req, res) => {
  return res.json(db.getSettings());
});

apiRouter.put('/settings', requireAuth, requireRole(['main_admin']), (req, res) => {
  const updated = db.updateSettings(req.body);
  return res.json(updated);
});

apiRouter.post('/upload', requireAuth, upload.single('file'), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'No file uploaded.' });
  }
  const fileUrl = `/uploads/${req.file.filename}`;
  return res.json({
    url: fileUrl,
    fileName: req.file.originalname,
    fileSize: (req.file.size / (1024 * 1024)).toFixed(2) + ' MB',
    mimeType: req.file.mimetype,
  });
});
